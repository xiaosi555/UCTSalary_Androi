package com.uct.salary

import com.uct.salary.core.Calc
import com.uct.salary.core.CsvIo
import com.uct.salary.core.Fmt
import com.uct.salary.model.QuickRecord
import com.uct.salary.model.User
import com.uct.salary.model.UserData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CsvTest {
    private val fx = CalcTest()
    private val data = UserData(records = fx.records, history = fx.history)
    private val user = User("u1", "我")

    @Test
    fun exportIsOneFileOneHeader52Columns() {
        assertEquals(52, CsvIo.FLAT_COLS.size)
        val csv = CsvIo.buildCsv(CsvIo.collectSections(user, data, "2026/10/17 12:00:00"))
        val lines = csv.split("\r\n")
        assertEquals(CsvIo.FLAT_COLS.joinToString(","), lines[0])
        assertFalse(lines.any { it.startsWith("#") })
        val rows = CsvIo.parseCsv(csv)
        assertEquals(1, rows.count { it[0] == "类型" })
        assertTrue(rows.all { it.size == 52 })
    }

    @Test
    fun roundTripPreservesSettingsRecordsAndResults() {
        val csv = CsvIo.buildCsv(CsvIo.collectSections(user, data, "now"))
        val plan = CsvIo.buildPlan(csv, UserData())
        assertEquals(11, plan.records.size)
        assertEquals(2, plan.history!!.size)
        assertEquals(2, plan.subsidyCycles)
        assertEquals(6, plan.subsidyCount)
        val back = CsvIo.applyPlan(plan, UserData())
        for (key in listOf("202610", "202611")) {
            val a = Calc.cycleStats(data.records, data.history, key)
            val b = Calc.cycleStats(back.records, back.history, key)
            assertEquals(Fmt.money(a.net), Fmt.money(b.net))
            assertEquals(Fmt.money(a.otIncome), Fmt.money(b.otIncome))
            assertEquals(Fmt.money(a.subTotal), Fmt.money(b.subTotal))
        }
        val seg = back.records.getValue("2026-09-20").otSegments
        assertNotNull(seg)
        assertEquals(2, seg!!.size)
        assertEquals(5.0, seg[0].hours, 1e-9)
        assertEquals(1.5, seg[1].rate, 1e-9)
    }

    @Test
    fun legacyRecordsOnlyCsvStillImports() {
        val text = "日期,星期,班次,日夜班,基础工时,加班小时,加班倍数,备注,当日工资\r\n" +
                "2026-10-01,周四,夜班,夜班,8,3,1.5,加班3小时,\r\n" +
                "2026-10-02,周五,周末加班,白班,0,11,2.0,,\r\n" +
                "坏行,,,,,,,,\r\n"
        val plan = CsvIo.buildPlan(text, UserData())
        assertTrue(plan.legacy)
        assertEquals(2, plan.records.size)
        assertEquals(1, plan.skippedRecords)
    }

    @Test
    fun importNormalisesDatesAndRejectsBadShift() {
        assertEquals("2026-10-01", CsvIo.normDate("2026/10/1"))
        assertEquals("2026-10-01", CsvIo.normDate("2026年10月1日"))
        assertEquals("2026-10-01", CsvIo.normDate("20261001"))
        assertNull(CsvIo.normDate("2026-02-30"))
        val plan = CsvIo.buildPlan("日期,班次\r\n2026-10-01,未知班\r\n", UserData())
        assertEquals(0, plan.records.size)
    }

    @Test
    fun quickSettingsRoundTrip() {
        val d = data.copy(quick = data.quick.copy(show = false, dayNight = "白班", records = listOf(QuickRecord("加班2h", "blue", 2.0, 1.5))))
        val plan = CsvIo.buildPlan(CsvIo.buildCsv(CsvIo.collectSections(user, d, "now")), UserData())
        val back = CsvIo.applyPlan(plan, UserData())
        assertEquals(false, back.quick.show)
        assertEquals("白班", back.quick.dayNight)
        assertEquals(1, back.quick.records.size)
    }
}
