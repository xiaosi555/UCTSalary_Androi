package com.uct.salary

import com.uct.salary.core.Calc
import com.uct.salary.core.Fmt
import com.uct.salary.model.DailyRecord
import com.uct.salary.model.DeductionCfg
import com.uct.salary.model.OtSegment
import com.uct.salary.model.Rates
import com.uct.salary.model.SalaryCfg
import com.uct.salary.model.SettingsVersion
import com.uct.salary.model.SheetItem
import com.uct.salary.model.SubsidyItem
import org.junit.Assert.assertEquals
import org.junit.Test

/** 黄金用例：数值全部来自基线 Web 版（docs/golden_cases.json）在同一份数据上的实测结果 */
class CalcTest {
    private val sub1 = listOf(
        SubsidyItem("夜班补贴", 5.0, true, "daily", 15),
        SubsidyItem("伙食补贴", 700.0, true, "monthly", 0),
        SubsidyItem("全勤奖", 200.0, false, "monthly", 0)
    )
    private val sub2 = listOf(
        SubsidyItem("夜班补贴", 8.0, true, "daily", 0),
        SubsidyItem("伙食补贴", 900.0, true, "monthly", 0),
        SubsidyItem("全勤奖", 300.0, true, "monthly", 0)
    )

    private fun ver(from: String, base: String, sb: String, tax: String, rates: Rates, sub: List<SubsidyItem>, hb: String = "2690", hr: String = "5"): SettingsVersion {
        val hs = (base.toDouble() / 21.75 / 8.0).toString()
        return SettingsVersion(from, SalaryCfg(base, hs, hs, "1.5", "2.0", "3.0"), DeductionCfg(sb, hb, hr, tax, rates), sub, 15)
    }

    val history = listOf(
        ver("000000", "3730", "7546", "102.16", Rates(), sub1),
        ver("202611", "5000", "8000", "200", Rates(pensionPersonalRate = "10", medPersonalRate = "2.5"), sub2, "3000", "6")
    )

    val records: Map<String, DailyRecord> = mapOf(
        "2026-09-16" to DailyRecord("夜班", "夜班", "8", "3", "1.5", null, "", ""),
        "2026-09-18" to DailyRecord("夜班", "夜班", "8", "3", "2.0", null, "", ""),
        "2026-09-20" to DailyRecord("夜班", "夜班", "0", "11", "2.0", listOf(OtSegment(5.0, 2.0), OtSegment(6.0, 1.5)), "", ""),
        "2026-09-21" to DailyRecord("白班", "白班", "8", "3", "1.5", null, "", ""),
        "2026-09-22" to DailyRecord("中班", "白班", "8", "0", "1.5", null, "", ""),
        "2026-09-26" to DailyRecord("周末加班", "白班", "0", "11", "2.0", null, "", ""),
        "2026-10-01" to DailyRecord("节假日加班", "白班", "0", "8", "3.0", null, "", ""),
        "2026-10-02" to DailyRecord("休息", "夜班", "休", "0", "1.5", null, "", ""),
        "2026-10-05" to DailyRecord("夜班", "夜班", "8", "3", "1.5", null, "", ""),
        "2026-10-20" to DailyRecord("夜班", "夜班", "8", "3", "1.5", null, "", ""),
        "2026-11-06" to DailyRecord("周末加班", "白班", "0", "11", "2.0", null, "", "")
    )

    private fun check(date: String, base: Double, ot: Double, total: Double, disp: String) {
        val rec = records.getValue(date)
        val p = Calc.recPayAt(history, date, rec)
        assertEquals("base $date", base, p.base, 1e-9)
        assertEquals("ot $date", ot, p.ot, 1e-9)
        assertEquals("total $date", total, p.total, 1e-9)
        assertEquals("disp $date", disp, Fmt.money(p.total))
    }

    @Test
    fun hourSalary() {
        assertEquals(21.436781609195403, Calc.settingsAt(history, "202610").hs, 1e-12)
        assertEquals(28.735632183908045, Calc.settingsAt(history, "202611").hs, 1e-12)
        val c = Calc.settingsAt(history, "202610")
        assertEquals("792.33", Fmt.fixed2(c.social))
        assertEquals("134.5", Fmt.jsNum(c.housing))
        assertEquals(102.16, c.tax, 1e-9)
    }

    @Test
    fun perRecordPay() {
        check("2026-09-16", 171.49425287356323, 96.4655172413793, 267.95977011494256, "267.96")
        check("2026-09-18", 171.49425287356323, 128.6206896551724, 300.11494252873564, "300.11")
        check("2026-09-20", 0.0, 407.2988505747127, 407.2988505747127, "407.30")
        check("2026-09-21", 171.49425287356323, 96.4655172413793, 267.95977011494256, "267.96")
        check("2026-09-22", 171.49425287356323, 0.0, 171.49425287356323, "171.49")
        check("2026-09-26", 0.0, 471.6091954022989, 471.6091954022989, "471.61")
        check("2026-10-01", 0.0, 514.4827586206897, 514.4827586206897, "514.48")
        check("2026-10-02", 0.0, 0.0, 0.0, "0")
        check("2026-10-05", 171.49425287356323, 96.4655172413793, 267.95977011494256, "267.96")
        check("2026-10-20", 229.88505747126436, 129.3103448275862, 359.1954022988506, "359.20")
        check("2026-11-06", 0.0, 632.183908045977, 632.183908045977, "632.18")
    }

    @Test
    fun cycle_202610() {
        val st = Calc.cycleStats(records, history, "202610")
        assertEquals("1811.41", Fmt.money(st.otIncome))
        assertEquals(7, st.otDays)
        assertEquals("42", Fmt.hour(st.otHours))
        assertEquals("5541.41", Fmt.money(st.basicTotal))
        assertEquals("775", Fmt.money(st.subTotal))
        assertEquals("1028.99", Fmt.money(st.totalDeduct))
        assertEquals("6316.41", Fmt.money(st.gross))
        assertEquals("5287.42", Fmt.money(st.net))
        assertEquals("15", Fmt.hour(st.verify.normalOt))
        assertEquals("19", Fmt.hour(st.verify.doubleOt))
        assertEquals("8", Fmt.hour(st.verify.holidayOt))
        assertEquals("1", st.verify.midCount.toString())
        assertEquals("3", st.verify.nightCount.toString())
        val sm = Calc.summary(records, history, "202610")
        assertEquals(3730.0, sm.base, 1e-6)
        assertEquals(1811.4080459770114, sm.ot, 1e-6)
        assertEquals(75.0, sm.night, 1e-6)
        assertEquals(700.0, sm.meal, 1e-6)
        assertEquals(102.16, sm.taxable, 1e-6)
        assertEquals(792.33, sm.social, 1e-6)
        assertEquals("2026.09-2026.10", Calc.sheetValue(SheetItem("ym", ""), st))
        assertEquals("22", Calc.sheetValue(SheetItem("std_days", ""), st))
        assertEquals("15", Calc.sheetValue(SheetItem("norm_ot", ""), st))
        assertEquals("27", Calc.sheetValue(SheetItem("dbl_ot", ""), st))
        assertEquals("1", Calc.sheetValue(SheetItem("mid_cnt", ""), st))
        assertEquals("3", Calc.sheetValue(SheetItem("night_cnt", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("annual_leave", ""), st))
        assertEquals("3730", Calc.sheetValue(SheetItem("base_sal", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("other_adj", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("holidays", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("shift_allowance", ""), st))
        assertEquals("1811.41", Calc.sheetValue(SheetItem("overtime", ""), st))
        assertEquals("700", Calc.sheetValue(SheetItem("meal_sub", ""), st))
        assertEquals("6316.41", Calc.sheetValue(SheetItem("income", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("accom", ""), st))
        assertEquals("926.83", Calc.sheetValue(SheetItem("social", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("borrow", ""), st))
        assertEquals("102.16", Calc.sheetValue(SheetItem("tax", ""), st))
        assertEquals("5287.42", Calc.sheetValue(SheetItem("net", ""), st))
    }

    @Test
    fun cycle_202611() {
        val st = Calc.cycleStats(records, history, "202611")
        assertEquals("761.49", Fmt.money(st.otIncome))
        assertEquals(2, st.otDays)
        assertEquals("14", Fmt.hour(st.otHours))
        assertEquals("5761.49", Fmt.money(st.basicTotal))
        assertEquals("1440", Fmt.money(st.subTotal))
        assertEquals("1420", Fmt.money(st.totalDeduct))
        assertEquals("7201.49", Fmt.money(st.gross))
        assertEquals("5781.49", Fmt.money(st.net))
        assertEquals("3", Fmt.hour(st.verify.normalOt))
        assertEquals("11", Fmt.hour(st.verify.doubleOt))
        assertEquals("0", Fmt.hour(st.verify.holidayOt))
        assertEquals("0", st.verify.midCount.toString())
        assertEquals("1", st.verify.nightCount.toString())
        val sm = Calc.summary(records, history, "202611")
        assertEquals(5000.0, sm.base, 1e-6)
        assertEquals(761.4942528735631, sm.ot, 1e-6)
        assertEquals(240.0, sm.night, 1e-6)
        assertEquals(900.0, sm.meal, 1e-6)
        assertEquals(200.0, sm.taxable, 1e-6)
        assertEquals(1040.0, sm.social, 1e-6)
        assertEquals("2026.10-2026.11", Calc.sheetValue(SheetItem("ym", ""), st))
        assertEquals("22", Calc.sheetValue(SheetItem("std_days", ""), st))
        assertEquals("3", Calc.sheetValue(SheetItem("norm_ot", ""), st))
        assertEquals("11", Calc.sheetValue(SheetItem("dbl_ot", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("mid_cnt", ""), st))
        assertEquals("1", Calc.sheetValue(SheetItem("night_cnt", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("annual_leave", ""), st))
        assertEquals("5000", Calc.sheetValue(SheetItem("base_sal", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("other_adj", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("holidays", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("shift_allowance", ""), st))
        assertEquals("761.49", Calc.sheetValue(SheetItem("overtime", ""), st))
        assertEquals("900", Calc.sheetValue(SheetItem("meal_sub", ""), st))
        assertEquals("7201.49", Calc.sheetValue(SheetItem("income", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("accom", ""), st))
        assertEquals("1220", Calc.sheetValue(SheetItem("social", ""), st))
        assertEquals("0", Calc.sheetValue(SheetItem("borrow", ""), st))
        assertEquals("200", Calc.sheetValue(SheetItem("tax", ""), st))
        assertEquals("5781.49", Calc.sheetValue(SheetItem("net", ""), st))
    }

    @Test
    fun fmtMoneyMatchesJsToFixed() {
        assertEquals("1.00", Fmt.fixed2(1.005))
        assertEquals("0.13", Fmt.fixed2(0.125))
        assertEquals("0.00", Fmt.fixed2(-0.0))
        assertEquals("3730", Fmt.money(3730.0))
        assertEquals("267.96", Fmt.money(267.96))
        assertEquals("3", Fmt.hour(3.0))
        assertEquals("2.5", Fmt.hour(2.5))
    }

    @Test
    fun versionAtPicksLatestNotAfterKey() {
        assertEquals("000000", Calc.versionAt(history, "202610").from)
        assertEquals("202611", Calc.versionAt(history, "202611").from)
        assertEquals("202611", Calc.versionAt(history, "202701").from)
    }

    @Test
    fun upsertCreatesCompleteSnapshotFromThatCycle() {
        val h2 = Calc.upsertVersion(history, "202610") { it.copy(salary = it.salary.copy(baseSalary = "4000")) }
        assertEquals(3, h2.size)
        assertEquals("3730", Calc.versionAt(h2, "202609").salary.baseSalary)
        assertEquals("4000", Calc.versionAt(h2, "202610").salary.baseSalary)
        assertEquals("5000", Calc.versionAt(h2, "202611").salary.baseSalary)
        assertEquals(3, Calc.subsidyAt(h2, "202610").size)
    }

    @Test
    fun baseHoursRules() {
        val wd = listOf("周一", "周二", "周三", "周四", "周五")
        assertEquals("8", Calc.resolveBaseHours("2026-10-05", "夜班", wd, 8))
        assertEquals("0", Calc.resolveBaseHours("2026-10-04", "夜班", wd, 8))
        assertEquals("休", Calc.resolveBaseHours("2026-10-05", "休息", wd, 8))
        assertEquals("0", Calc.resolveBaseHours("2026-10-05", "周末加班", wd, 8))
    }
}
