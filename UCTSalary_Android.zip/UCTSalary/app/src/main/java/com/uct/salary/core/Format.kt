package com.uct.salary.core

import java.math.BigDecimal
import java.math.RoundingMode

/** 与网页版 fmtMoney / formatHourNumber / parseFloat 行为保持一致的格式化与解析工具 */
object Fmt {

    /** JS 的 n.toFixed(2)：按二进制精确值四舍五入（BigDecimal(double) 即精确值，HALF_UP 对应 toFixed 的“取较大者”） */
    fun fixed2(n: Double): String {
        if (n.isNaN() || n.isInfinite()) return "0.00"
        var t = BigDecimal(n).setScale(2, RoundingMode.HALF_UP).toPlainString()
        if (t == "-0.00") t = "0.00"
        return t
    }

    /** 金额：两位小数，整数去掉 .00（267.96、1811.41、3730、0） */
    fun money(n: Double): String {
        val t = fixed2(n)
        return if (t.endsWith(".00")) t.dropLast(3) else t
    }

    /** JS 的 String(number)：整数不带小数点，其余取最短表示，且不使用科学计数法 */
    fun jsNum(d: Double): String {
        if (d.isNaN() || d.isInfinite()) return "0"
        if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
        val s = d.toString()
        return if (s.contains('E') || s.contains('e')) BigDecimal(s).stripTrailingZeros().toPlainString() else s
    }

    /** formatHourNumber(num)：parseFloat(num)||0 后转字符串 */
    fun hour(d: Double): String = jsNum(if (d.isNaN()) 0.0 else d)

    private val PF = Regex("^\\s*[-+]?(\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?")

    /** JS parseFloat：取前缀数字；无法解析返回 NaN */
    fun pf(s: String?): Double {
        if (s == null) return Double.NaN
        val m = PF.find(s) ?: return Double.NaN
        return m.value.trim().toDoubleOrNull() ?: Double.NaN
    }

    /** parseFloat(x) || 0 */
    fun pfz(s: String?): Double {
        val v = pf(s)
        return if (v.isNaN()) 0.0 else v
    }

    /** parseFloat(x) || fallback （NaN 或 0 都回落） */
    fun pfOr(s: String?, fallback: Double): Double {
        val v = pf(s)
        return if (v.isNaN() || v == 0.0) fallback else v
    }
}
