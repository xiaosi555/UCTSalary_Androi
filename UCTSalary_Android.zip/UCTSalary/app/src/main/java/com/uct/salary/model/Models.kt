package com.uct.salary.model

import kotlinx.serialization.Serializable

/* ============================ 常量 ============================ */

val THEME_BGS = listOf(
    "https://fastly.picsum.photos/id/605/536/354.jpg?hmac=UEikA1VtUKhG5RZNv-Bokpe3xjPIdzzW9akGBUFmB5k",
    "https://fastly.picsum.photos/id/537/536/354.jpg?hmac=9w4wLS6h9VtjcXkaIi-w9NDXNEYIpyh8tQc2H7w8Tdw",
    "https://fastly.picsum.photos/id/495/536/354.jpg?hmac=zuvX-7elHGS7AKwiBMaTOxxfSmzdW35fmQT9BVHCojo",
    "https://fastly.picsum.photos/id/932/536/354.jpg?hmac=Rd2DUoI6aXKUNMI4ndHOqQyINA1EJX7U-o3k4q-H95U",
    "https://fastly.picsum.photos/id/221/536/354.jpg?hmac=m5VgvMHD2K_WAvzfoBgV9_lTRZy4Iq6GeJZetCCJSbg",
    "https://fastly.picsum.photos/id/609/536/354.jpg?hmac=tVnz1exGJpbwT-2P8MWOvapIg7nTpSQ5SCeUHyu_7mU"
)

val THEME_COLORS = listOf(
    "#E74C3C", "#F84685", "#FF9500", "#F1C40F", "#E9F4B9", "#22C065", "#24B72F", "#B6D999",
    "#B7E9C8", "#16C3A7", "#99D8E6", "#2A9CDF", "#3498DB", "#537DFC", "#C9E3F7"
)

const val DEFAULT_THEME_COLOR = "#22C065"

/** 考勤周期滚轮：1号-当月30号、2号-下月1号 … 31号-下月30号（共 31 项，默认下标 15 = 16号-下月15号） */
val CYCLE_LIST: List<String> = (1..31).map { if (it == 1) "1号-当月30号" else "${it}号-下月${it - 1}号" }

val WEEK_DAYS = listOf("周一", "周二", "周三", "周四", "周五", "周六", "周日")
val SHIFT_TYPES_FORM = listOf("白班", "夜班", "中班", "休息", "平时加班", "周末加班", "调休加班", "节假日加班")
val SHIFT_TYPES_VALID = listOf("早班", "中班", "晚班", "白班", "夜班", "休息", "平时加班", "周末加班", "调休加班", "节假日加班")
val SHIFT_TYPES_STATS = listOf("早班", "中班", "晚班", "白班", "夜班", "休息")
val OT_RATE_OPTIONS = listOf("1.5", "2.0", "3.0")
val SPLIT_RATE_OPTIONS = listOf("1.5", "2", "3")

/** 补贴设置页默认可见的两项；用户自定义添加的补贴项同样可见 */
val CORE_SUBSIDY_NAMES = listOf("夜班补贴", "伙食补贴")
val DEFAULT_SUBSIDY_NAMES = listOf(
    "白班补贴", "夜班补贴", "中班补贴", "早班补贴", "晚班补贴", "全勤奖", "岗位补贴",
    "伙食补贴", "生活补贴", "高温补贴", "星级补贴", "环境补贴", "交通补贴", "绩效补贴"
)

const val DEFAULT_BASE_SALARY = 3730.0
val DEFAULT_HOUR_SALARY: Double = DEFAULT_BASE_SALARY / 21.75 / 8.0

/* ============================ 用户 ============================ */

@Serializable
data class User(
    val id: String,
    val name: String = "",
    val avatar: String = "",
    val gender: String = "保密",
    val phone: String = "",
    val remark: String = ""
)

/* ============================ 工时记录 ============================ */

@Serializable
data class OtSegment(
    @Serializable(with = FlexDouble::class) val hours: Double = 0.0,
    @Serializable(with = FlexDouble::class) val rate: Double = 1.5
)

@Serializable
data class DailyRecord(
    val shiftType: String = "夜班",
    val dayNight: String = "",
    @Serializable(with = FlexString::class) val hours: String = "0",
    @Serializable(with = FlexString::class) val otHours: String = "0",
    @Serializable(with = FlexString::class) val otRate: String = "1.5",
    val otSegments: List<OtSegment>? = null,
    val remark: String = "",
    val salary: String = ""
)

/* ============================ 设置版本 ============================ */

@Serializable
data class SalaryCfg(
    @Serializable(with = FlexString::class) val baseSalary: String = "3730",
    @Serializable(with = FlexString::class) val hourSalary: String = DEFAULT_HOUR_SALARY.toString(),
    /** 高精度时薪；空串表示无 */
    @Serializable(with = FlexString::class) val hourSalaryExact: String = "",
    @Serializable(with = FlexString::class) val rate1: String = "1.5",
    @Serializable(with = FlexString::class) val rate2: String = "2.0",
    @Serializable(with = FlexString::class) val rate3: String = "3.0"
)

@Serializable
data class Rates(
    @Serializable(with = FlexString::class) val pensionUnitRate: String = "16",
    @Serializable(with = FlexString::class) val pensionPersonalRate: String = "8",
    @Serializable(with = FlexString::class) val medUnitRate: String = "9",
    @Serializable(with = FlexString::class) val medPersonalRate: String = "2",
    @Serializable(with = FlexString::class) val unempUnitRate: String = "0.5",
    @Serializable(with = FlexString::class) val unempPersonalRate: String = "0.5",
    @Serializable(with = FlexString::class) val injuryUnitRate: String = "0.5",
    @Serializable(with = FlexString::class) val injuryPersonalRate: String = "0",
    @Serializable(with = FlexString::class) val maternityUnitRate: String = "0",
    @Serializable(with = FlexString::class) val maternityPersonalRate: String = "0"
) {
    fun personalList(): List<String> =
        listOf(pensionPersonalRate, medPersonalRate, unempPersonalRate, injuryPersonalRate, maternityPersonalRate)

    fun unitList(): List<String> =
        listOf(pensionUnitRate, medUnitRate, unempUnitRate, injuryUnitRate, maternityUnitRate)

    /** 与 CSV「周期设置」中十个比例列的顺序一致 */
    fun csvOrder(): List<String> = listOf(
        pensionUnitRate, pensionPersonalRate, medUnitRate, medPersonalRate, unempUnitRate,
        unempPersonalRate, injuryUnitRate, injuryPersonalRate, maternityUnitRate, maternityPersonalRate
    )

    companion object {
        fun fromCsvOrder(v: List<String>): Rates = Rates(
            v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9]
        )
    }
}

@Serializable
data class DeductionCfg(
    @Serializable(with = FlexString::class) val socialBase: String = "7546",
    @Serializable(with = FlexString::class) val housingBase: String = "2690",
    @Serializable(with = FlexString::class) val housingRate: String = "5",
    @Serializable(with = FlexString::class) val incomeTax: String = "102.16",
    val rates: Rates? = null
)

@Serializable
data class SubsidyItem(
    val name: String = "",
    @Serializable(with = FlexDouble::class) val amount: Double = 0.0,
    val enabled: Boolean = false,
    val mode: String = "monthly",
    @Serializable(with = FlexInt::class) val days: Int = 0
)

@Serializable
data class SettingsVersion(
    val from: String = "000000",
    val salary: SalaryCfg = SalaryCfg(),
    val deduction: DeductionCfg = DeductionCfg(),
    val subsidy: List<SubsidyItem>? = null,
    @Serializable(with = FlexInt::class) val cycle: Int = 15
)

/* ============================ 其他设置 ============================ */

@Serializable
data class QuickRecord(
    val name: String = "",
    val type: String = "blue",
    @Serializable(with = FlexDouble::class) val hours: Double = 3.0,
    @Serializable(with = FlexDouble::class) val rate: Double = 1.5,
    val shiftType: String? = null
)

@Serializable
data class QuickSettings(
    val show: Boolean = true,
    val records: List<QuickRecord> = defaultQuickRecords(),
    val dayNight: String = "夜班"
)

@Serializable
data class SheetItem(val key: String, val label: String, val enabled: Boolean = true)

@Serializable
data class ThemeSettings(val bg: String = THEME_BGS[0], val color: String = DEFAULT_THEME_COLOR)

@Serializable
data class SummaryVisible(
    val night: Boolean = true,
    val meal: Boolean = true,
    val taxable: Boolean = true,
    val social: Boolean = true
)

@Serializable
data class DeductionVisible(
    val social: Boolean = true,
    val housing: Boolean = true,
    val tax: Boolean = true
)

/* ============================ 默认值工厂 ============================ */

fun defaultQuickRecords(): List<QuickRecord> = listOf(
    QuickRecord("夜班11h", "blue", 3.0, 1.5),
    QuickRecord("白班11h", "orange", 3.0, 1.5),
    QuickRecord("周末11h", "orange", 11.0, 2.0)
)

fun defaultSubsidyList(): List<SubsidyItem> = listOf(
    SubsidyItem("白班补贴", 0.0, false, "monthly", 0),
    SubsidyItem("夜班补贴", 5.0, true, "daily", 15),
    SubsidyItem("中班补贴", 0.0, false, "monthly", 0),
    SubsidyItem("早班补贴", 0.0, false, "monthly", 0),
    SubsidyItem("晚班补贴", 0.0, false, "monthly", 0),
    SubsidyItem("全勤奖", 200.0, false, "monthly", 0),
    SubsidyItem("岗位补贴", 0.0, false, "monthly", 0),
    SubsidyItem("伙食补贴", 700.0, true, "monthly", 0),
    SubsidyItem("生活补贴", 0.0, false, "monthly", 0),
    SubsidyItem("高温补贴", 0.0, false, "monthly", 0),
    SubsidyItem("星级补贴", 0.0, false, "monthly", 0),
    SubsidyItem("环境补贴", 0.0, false, "monthly", 0),
    SubsidyItem("交通补贴", 0.0, false, "monthly", 0),
    SubsidyItem("绩效补贴", 0.0, false, "monthly", 0)
)

fun defaultSheetItems(): List<SheetItem> = listOf(
    SheetItem("ym", "年月"),
    SheetItem("std_days", "标准天数"),
    SheetItem("norm_ot", "平时加班小时"),
    SheetItem("dbl_ot", "双休加班小时"),
    SheetItem("mid_cnt", "中班次数"),
    SheetItem("night_cnt", "夜班次数"),
    SheetItem("annual_leave", "年假小时"),
    SheetItem("base_sal", "基本工资"),
    SheetItem("other_adj", "其他调整"),
    SheetItem("holidays", "各类假期"),
    SheetItem("shift_allowance", "翻班津贴"),
    SheetItem("overtime", "加班"),
    SheetItem("meal_sub", "餐费补贴"),
    SheetItem("income", "收入额"),
    SheetItem("accom", "住宿费"),
    SheetItem("social", "9月社保"),
    SheetItem("borrow", "借支"),
    SheetItem("tax", "预扣9月个税"),
    SheetItem("net", "实发工资")
)

fun defaultVersion(): SettingsVersion = SettingsVersion(
    from = "000000",
    salary = SalaryCfg(
        baseSalary = "3730",
        hourSalary = DEFAULT_HOUR_SALARY.toString(),
        hourSalaryExact = DEFAULT_HOUR_SALARY.toString()
    ),
    deduction = DeductionCfg(rates = Rates()),
    subsidy = defaultSubsidyList(),
    cycle = 15
)

/** 一个用户的全部数据（与网页版存储键一一对应） */
data class UserData(
    val records: Map<String, DailyRecord> = emptyMap(),
    val history: List<SettingsVersion> = listOf(defaultVersion()),
    val quick: QuickSettings = QuickSettings(),
    val sheetItems: List<SheetItem> = defaultSheetItems(),
    val theme: ThemeSettings = ThemeSettings(),
    val summaryVisible: SummaryVisible = SummaryVisible(),
    val deductionVisible: DeductionVisible = DeductionVisible(),
    val cycleIndex: Int = 15,
    val workdays: List<String> = listOf("周一", "周二", "周三", "周四", "周五"),
    val normalHours: Int = 8
)
