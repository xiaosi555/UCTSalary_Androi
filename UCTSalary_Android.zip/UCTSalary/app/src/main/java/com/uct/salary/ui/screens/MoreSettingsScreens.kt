package com.uct.salary.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.uct.salary.core.Fmt
import com.uct.salary.model.QuickRecord
import com.uct.salary.model.THEME_BGS
import com.uct.salary.model.THEME_COLORS
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.CardBox
import com.uct.salary.ui.components.LabeledField
import com.uct.salary.ui.components.PillSwitch
import com.uct.salary.ui.components.Segmented
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.Orange500
import com.uct.salary.ui.theme.White
import com.uct.salary.ui.theme.isLightColor
import com.uct.salary.ui.theme.parseHex

/* ============================ 快捷记录设置 ============================ */

@Composable
fun QuickSettingsScreen(vm: AppViewModel) {
    val q = vm.data.quick
    var editIdx by remember { mutableIntStateOf(-2) }   // -2 不编辑；-1 新增；>=0 编辑

    SettingsPage("快捷记录设置", { vm.pop() }, bottom = { PrimaryButton("新增快捷记录") { editIdx = -1 } }) {
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("快捷记录在首页展示", fontSize = 15.sp, color = Gray900, modifier = Modifier.weight(1f))
                PillSwitch(q.show) { vm.setQuickShow(it) }
            }
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("白夜班", fontSize = 15.sp, color = Gray900, modifier = Modifier.weight(1f))
                Segmented(listOf("白班", "夜班"), if (q.dayNight == "白班") 0 else 1, { vm.setDefaultDayNight(if (it == 0) "白班" else "夜班") }, Modifier.width(160.dp))
            }
        }
        Text("${q.records.size}个班次", fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(horizontal = 4.dp))
        q.records.forEachIndexed { i, r ->
            CardBox {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val blue = r.type == "blue"
                    Text(
                        if (blue) "夜班" else "白班", fontSize = 11.sp, fontWeight = FontWeight.Medium,
                        color = if (blue) onPrimary() else White,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(if (blue) primary() else Orange500).padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text(r.name, fontSize = 15.sp, color = Gray900)
                        Text("${Fmt.hour(r.hours)}h / ${Fmt.jsNum(r.rate)}倍", fontSize = 12.sp, color = Gray500)
                    }
                    Icon(AppIcons.Edit, "编辑", tint = Gray400, modifier = Modifier.size(34.dp).clip(CircleShape).clickable { editIdx = i }.padding(7.dp))
                }
            }
        }
    }

    if (editIdx >= -1) {
        val existing = q.records.getOrNull(editIdx)
        var name by remember(editIdx) { mutableStateOf(existing?.name ?: "新班次8h") }
        var blue by remember(editIdx) { mutableStateOf((existing?.type ?: "blue") == "blue") }
        var hours by remember(editIdx) { mutableStateOf(existing?.let { Fmt.hour(it.hours) } ?: "3") }
        var rate by remember(editIdx) { mutableStateOf(existing?.let { Fmt.jsNum(it.rate) } ?: "1.5") }
        FormDialog(
            title = if (existing == null) "新增快捷记录" else "编辑快捷记录",
            onCancel = { editIdx = -2 },
            onConfirm = {
                val h = Fmt.pf(hours).let { if (it.isNaN()) 0.0 else it }
                val rt = Fmt.pf(rate).let { if (it.isNaN() || it == 0.0) 1.0 else it }
                val item = QuickRecord(name.ifBlank { "自定义班次" }, if (blue) "blue" else "orange", h, rt, existing?.shiftType)
                vm.setQuickRecords(if (existing == null) q.records + item else q.records.mapIndexed { i, x -> if (i == editIdx) item else x })
                editIdx = -2
            },
            onDelete = if (existing != null) ({ vm.setQuickRecords(q.records.filterIndexed { i, _ -> i != editIdx }); editIdx = -2 }) else null
        ) {
            LabeledField("班次名称", name, { name = it })
            Text("颜色类型", fontSize = 13.sp, color = Gray500)
            Segmented(listOf("夜班", "白班"), if (blue) 0 else 1, { blue = it == 0 })
            LabeledField("加班小时数", hours, { hours = it }, keyboard = KeyboardType.Decimal)
            LabeledField("加班倍数", rate, { rate = it }, keyboard = KeyboardType.Decimal)
        }
    }
}

/* ============================ 主题 ============================ */

@Composable
fun ThemeSettingsScreen(vm: AppViewModel) {
    val t = vm.data.theme
    SettingsPage("主题", { vm.pop() }) {
        CardBox {
            Text("背景", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                THEME_BGS.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { url ->
                            val on = t.bg == url
                            Box(
                                Modifier.weight(1f).height(92.dp).clip(RoundedCornerShape(10.dp)).background(Gray100)
                                    .then(if (on) Modifier.border(3.dp, primary(), RoundedCornerShape(10.dp)) else Modifier)
                                    .clickable { vm.setTheme(t.copy(bg = url)) }
                            ) {
                                AsyncImage(model = url, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(92.dp))
                                if (on) {
                                    Icon(
                                        AppIcons.Check, null, tint = onPrimary(),
                                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(primary()).padding(3.dp)
                                    )
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
        CardBox {
            Text("主题色", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                THEME_COLORS.chunked(5).forEach { rowColors ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        rowColors.forEach { hex ->
                            val c = parseHex(hex)
                            val on = t.color.equals(hex, ignoreCase = true)
                            Box(
                                Modifier.size(46.dp).clip(CircleShape).background(c).border(1.dp, Gray200, CircleShape).clickable { vm.setTheme(t.copy(color = hex)) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (on) Icon(AppIcons.Check, null, tint = if (isLightColor(c)) Gray800 else White, modifier = Modifier.size(24.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
