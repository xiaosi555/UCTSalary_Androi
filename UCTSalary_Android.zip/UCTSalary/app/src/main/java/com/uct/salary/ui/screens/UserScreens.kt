package com.uct.salary.ui.screens

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.uct.salary.model.User
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.Avatar
import com.uct.salary.ui.components.CardBox
import com.uct.salary.ui.components.LabeledField
import com.uct.salary.ui.components.Segmented
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.Red500
import com.uct.salary.ui.theme.White
import java.io.ByteArrayOutputStream

/** 头像：居中裁剪成正方形 → 160×160 → JPEG 0.85 → data URL（与网页版一致） */
private fun encodeAvatar(ctx: android.content.Context, uri: android.net.Uri): String? = try {
    val bmp = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
    if (bmp == null) null else {
        val side = minOf(bmp.width, bmp.height)
        val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
        val scaled = Bitmap.createScaledBitmap(sq, 160, 160, true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
        "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
} catch (e: Exception) {
    null
}

/** 首页头像 → 切换用户弹窗 */
@Composable
fun UserSwitchDialog(vm: AppViewModel) {
    Dialog(onDismissRequest = { vm.userSwitchOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Column(Modifier.widthIn(max = 384.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(White).padding(20.dp)) {
                Text("切换用户", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Column(Modifier.heightIn(max = 360.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    vm.users.forEach { u ->
                        val cur = u.id == vm.currentUserId
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(if (cur) primary().copy(alpha = 0.16f) else Gray100)
                                .clickable { vm.switchUser(u.id) }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(u, 40.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(u.name, fontSize = 15.sp, color = Gray900, modifier = Modifier.weight(1f))
                            if (cur) Text("当前", fontSize = 12.sp, color = onPrimary(), modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(primary()).padding(horizontal = 8.dp, vertical = 2.dp))
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                Box(
                    Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(8.dp)).background(White)
                        .clickable { vm.userSwitchOpen = false; vm.push(Route.UserManage) },
                    contentAlignment = Alignment.Center
                ) { Text("管理用户", fontSize = 15.sp, color = primary(), fontWeight = FontWeight.Medium) }
            }
        }
    }
}

@Composable
fun UserManageScreen(vm: AppViewModel) {
    SettingsPage("用户管理", { vm.pop() }, bottom = { PrimaryButton("添加用户") { vm.push(Route.UserEdit(null)) } }) {
        CardBox(padding = 0.dp) {
            vm.users.forEach { u ->
                val info = listOf(u.gender, u.phone, u.remark).filter { it.isNotBlank() }.joinToString(" · ").ifEmpty { "暂无信息" }
                Row(Modifier.fillMaxWidth().clickable { vm.push(Route.UserEdit(u.id)) }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(u, 44.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(u.name, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900)
                            if (u.id == vm.currentUserId) {
                                Spacer(Modifier.width(6.dp))
                                Text("当前", fontSize = 11.sp, color = onPrimary(), modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(primary()).padding(horizontal = 6.dp, vertical = 1.dp))
                            }
                        }
                        Text(info, fontSize = 12.sp, color = Gray500, maxLines = 1)
                    }
                    Icon(AppIcons.Right, null, tint = Gray400)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Gray100))
            }
        }
    }
}

@Composable
fun UserEditScreen(vm: AppViewModel, userId: String?) {
    val ctx = LocalContext.current
    val existing = remember(userId) { vm.users.firstOrNull { it.id == userId } }
    var name by remember(userId) { mutableStateOf(existing?.name ?: "") }
    var gender by remember(userId) { mutableStateOf(existing?.gender ?: "保密") }
    var phone by remember(userId) { mutableStateOf(existing?.phone ?: "") }
    var remark by remember(userId) { mutableStateOf(existing?.remark ?: "") }
    var avatar by remember(userId) { mutableStateOf(existing?.avatar ?: "") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            val s = encodeAvatar(ctx, uri)
            if (s != null) avatar = s else vm.alert("提示", "无法读取所选图片")
        }
    }

    fun build(): User = User(
        id = existing?.id ?: ("u" + java.lang.Long.toString(System.currentTimeMillis(), 36)),
        name = name.trim(), avatar = avatar, gender = gender, phone = phone.trim(), remark = remark.trim()
    )

    SettingsPage(if (existing == null) "添加用户" else "编辑用户", { vm.pop() }, bottom = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            PrimaryButton("保存") {
                if (name.isBlank()) vm.alert("提示", "请输入昵称")
                else { vm.saveUser(build(), false); vm.pop() }
            }
            if (existing != null && existing.id != vm.currentUserId) {
                Box(
                    Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(10.dp)).background(primary().copy(alpha = 0.16f))
                        .clickable { if (name.isBlank()) vm.alert("提示", "请输入昵称") else vm.saveUser(build(), true) },
                    contentAlignment = Alignment.Center
                ) { Text("设为当前用户", fontSize = 15.sp, color = Gray900, fontWeight = FontWeight.Medium) }
            }
            if (existing != null && vm.users.size > 1) {
                Box(
                    Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(10.dp)).background(White)
                        .clickable {
                            vm.ask("删除用户", "确定要删除用户「${existing.name}」吗？其全部数据将被清除且无法恢复。", "删除", danger = true) {
                                val wasCurrent = existing.id == vm.currentUserId
                                vm.deleteUser(existing.id)
                                if (!wasCurrent) vm.pop()
                            }
                        },
                    contentAlignment = Alignment.Center
                ) { Text("删除用户", fontSize = 15.sp, color = Red500, fontWeight = FontWeight.Medium) }
            }
        }
    }) {
        CardBox {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Avatar(User("", name.ifBlank { "?" }, avatar), 84.dp, Modifier.clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) })
                Spacer(Modifier.height(8.dp))
                Text("点击更换头像", fontSize = 12.sp, color = Gray500)
            }
            Spacer(Modifier.height(14.dp))
            LabeledField("昵称", name, { name = it }, placeholder = "请输入昵称")
            Spacer(Modifier.height(12.dp))
            Text("性别", fontSize = 13.sp, color = Gray500, modifier = Modifier.padding(bottom = 4.dp))
            Segmented(listOf("男", "女", "保密"), listOf("男", "女", "保密").indexOf(gender).let { if (it < 0) 2 else it }, { gender = listOf("男", "女", "保密")[it] })
            Spacer(Modifier.height(12.dp))
            LabeledField("联系电话", phone, { phone = it }, keyboard = KeyboardType.Phone)
            Spacer(Modifier.height(12.dp))
            LabeledField("备注", remark, { remark = it })
        }
    }
}
