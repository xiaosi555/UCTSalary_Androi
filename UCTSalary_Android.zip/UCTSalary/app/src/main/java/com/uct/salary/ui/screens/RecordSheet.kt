package com.uct.salary.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uct.salary.core.Dates
import com.uct.salary.model.OT_RATE_OPTIONS
import com.uct.salary.model.SHIFT_TYPES_FORM
import com.uct.salary.model.SPLIT_RATE_OPTIONS
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.RecordForm
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.Avatar
import com.uct.salary.ui.components.DropdownField
import com.uct.salary.ui.components.Field
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray600
import com.uct.salary.ui.theme.Gray700
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.Red500
import com.uct.salary.ui.theme.White
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordSheet(vm: AppViewModel, f: RecordForm) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showPicker by remember { mutableStateOf(false) }
    val pri = primary()

    ModalBottomSheet(
        onDismissRequest = { vm.closeRecord() },
        sheetState = sheetState,
        containerColor = White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).navigationBarsPadding().imePadding()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (f.isEdit) "编辑工时记录" else "记工时", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Gray900, modifier = Modifier.weight(1f))
                Icon(AppIcons.Close, "关闭", tint = Gray500, modifier = Modifier.size(24.dp).clickable { vm.closeRecord() })
            }
            Spacer(Modifier.height(14.dp))

            /* 用户（可多选，至少 1 个） */
            Text("记录给", fontSize = 13.sp, color = Gray500)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                vm.users.forEach { u ->
                    val on = f.selectedUsers.contains(u.id)
                    Row(
                        Modifier.clip(RoundedCornerShape(20.dp))
                            .background(if (on) pri.copy(alpha = 0.18f) else Gray100)
                            .border(1.dp, if (on) pri else Color0, RoundedCornerShape(20.dp))
                            .clickable {
                                val cur = f.selectedUsers
                                f.selectedUsers = if (on) (if (cur.size > 1) cur - u.id else cur) else cur + u.id
                            }.padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Avatar(u, 24.dp)
                        Spacer(Modifier.width(6.dp))
                        Text(u.name, fontSize = 13.sp, color = Gray700)
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            /* 日期 + 星期 */
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("日期", fontSize = 13.sp, color = Gray500, modifier = Modifier.width(64.dp))
                Row(
                    Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(Gray100).clickable { showPicker = true }.padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(f.date.ifEmpty { "请选择日期" }, fontSize = 14.sp, color = Gray900, modifier = Modifier.weight(1f))
                    Text(f.week, fontSize = 13.sp, color = Gray500)
                }
            }
            Spacer(Modifier.height(12.dp))

            /* 加班倍数 + 去设置 */
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.width(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("倍数", fontSize = 13.sp, color = Gray500)
                }
                DropdownField(f.otRate, OT_RATE_OPTIONS, { f.onOtRateChanged(it) }, Modifier.weight(1f))
                Spacer(Modifier.width(8.dp))
                Icon(
                    AppIcons.Tune, "去设置工资", tint = Gray500,
                    modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).clickable {
                        vm.cfgTarget = Dates.cycleKeyOfDate(f.date) ?: Dates.realKey()
                        vm.closeRecord()
                        vm.push(Route.SalarySettings)
                    }.padding(6.dp)
                )
            }
            Spacer(Modifier.height(12.dp))

            /* 加班工时 */
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("加班", fontSize = 13.sp, color = Gray500, modifier = Modifier.width(64.dp))
                Field(f.otHours, { f.onOtHoursChanged(it) }, Modifier.weight(1f), "加班小时数", KeyboardType.Decimal, onFocusChange = { f.onOtFocus(it) })
                Spacer(Modifier.width(8.dp))
                Text("小时", fontSize = 13.sp, color = Gray500)
            }
            Spacer(Modifier.height(12.dp))

            /* 拆分加班 */
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Gray100).padding(12.dp)) {
                Row(Modifier.clickable { f.toggleSplit() }, verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("拆分加班", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Gray900)
                        Text(f.segmentSummary(), fontSize = 12.sp, color = Gray500)
                    }
                    Icon(if (f.splitExpanded) AppIcons.ExpandLess else AppIcons.ExpandMore, null, tint = Gray500)
                }
                if (f.splitExpanded) {
                    Spacer(Modifier.height(10.dp))
                    SplitRow("第一段", f.s1h, f.s1r, { f.onSplitEdited(f1h = it) }, { f.onSplitEdited(f1r = it) })
                    Spacer(Modifier.height(8.dp))
                    SplitRow("第二段", f.s2h, f.s2r, { f.onSplitEdited(f2h = it) }, { f.onSplitEdited(f2r = it) })
                }
            }
            Spacer(Modifier.height(14.dp))

            /* 班次类型 */
            Text("班次类型", fontSize = 13.sp, color = Gray500)
            Spacer(Modifier.height(6.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SHIFT_TYPES_FORM.chunked(4).forEach { rowItems ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowItems.forEach { t ->
                            val on = f.shiftType == t
                            Box(
                                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                                    .background(if (on) pri else Gray100).clickable { f.selectShift(t) }.padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) { Text(t, fontSize = 13.sp, color = if (on) onPrimary() else Gray700, fontWeight = if (on) FontWeight.Medium else FontWeight.Normal, textAlign = TextAlign.Center, maxLines = 1) }
                        }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))

            /* 备注 */
            Row(verticalAlignment = Alignment.Top) {
                Text("备注", fontSize = 13.sp, color = Gray500, modifier = Modifier.width(64.dp).padding(top = 10.dp))
                Field(f.remark, { f.remark = it }, Modifier.weight(1f), "备注", singleLine = false, minLines = 2)
            }
            Spacer(Modifier.height(14.dp))

            /* 预计薪资 */
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(pri.copy(alpha = 0.14f)).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("预计薪资", fontSize = 14.sp, color = Gray600, modifier = Modifier.weight(1f))
                Text(f.expected(), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Gray900)
            }
            Spacer(Modifier.height(18.dp))

            /* 按钮 */
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (f.isEdit) {
                    Box(
                        Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(10.dp)).border(1.dp, Red500, RoundedCornerShape(10.dp)).clickable { vm.requestDelete() },
                        contentAlignment = Alignment.Center
                    ) { Text("删除", color = Red500, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                }
                Box(
                    Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(10.dp)).border(1.dp, Gray200, RoundedCornerShape(10.dp)).clickable { vm.closeRecord() },
                    contentAlignment = Alignment.Center
                ) { Text("取消", color = Gray700, fontSize = 15.sp, fontWeight = FontWeight.Medium) }
                Box(
                    Modifier.weight(1.4f).height(46.dp).clip(RoundedCornerShape(10.dp)).background(pri).clickable { vm.saveRecord() },
                    contentAlignment = Alignment.Center
                ) { Text("保存", color = onPrimary(), fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            }
            Spacer(Modifier.height(20.dp))
        }
    }

    if (showPicker) {
        val initial = (Dates.parse(f.date) ?: Dates.today()).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli()
        val state = rememberDatePickerState(initialSelectedDateMillis = initial)
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { ms ->
                        val d: LocalDate = Instant.ofEpochMilli(ms).atZone(ZoneOffset.UTC).toLocalDate()
                        f.onDateChanged(d.toString())
                    }
                    showPicker = false
                }) { Text("确定", color = pri) }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("取消", color = Gray500) } }
        ) { DatePicker(state = state) }
    }
}

private val Color0 = androidx.compose.ui.graphics.Color.Transparent

@Composable
private fun SplitRow(label: String, hours: String, rate: String, onHours: (String) -> Unit, onRate: (String) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = Gray600, modifier = Modifier.width(52.dp))
        Field(hours, onHours, Modifier.weight(1f), "小时", KeyboardType.Decimal)
        Spacer(Modifier.width(8.dp))
        DropdownField(rate, SPLIT_RATE_OPTIONS, onRate, Modifier.width(90.dp))
        Text("倍", fontSize = 13.sp, color = Gray400, modifier = Modifier.padding(start = 4.dp))
    }
}
