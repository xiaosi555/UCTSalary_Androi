package com.uct.salary.data

import android.content.Context
import com.uct.salary.model.User
import kotlinx.serialization.json.Json

/** SharedPreferences 封装：键名与网页版 localStorage 完全一致（u1 无前缀，其他用户为 id__键名） */
class Store(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("uct_salary", Context.MODE_PRIVATE)

    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        coerceInputValues = true
        encodeDefaults = true
    }

    private fun key(userId: String, name: String) = if (userId == "u1") name else "${userId}__$name"

    fun get(userId: String, name: String): String? = sp.getString(key(userId, name), null)

    fun put(userId: String, name: String, value: String) {
        sp.edit().putString(key(userId, name), value).apply()
    }

    fun remove(userId: String, name: String) {
        sp.edit().remove(key(userId, name)).apply()
    }

    /* ---- 全局键 ---- */

    fun loadUsers(): List<User> {
        val raw = sp.getString("app_users_list", null)
        val list = try {
            if (raw == null) emptyList() else json.decodeFromString<List<User>>(raw)
        } catch (e: Exception) {
            emptyList()
        }
        if (list.isNotEmpty()) return list
        val def = listOf(User(id = "u1", name = "我"))
        saveUsers(def)
        return def
    }

    fun saveUsers(users: List<User>) {
        sp.edit().putString("app_users_list", json.encodeToString(kotlinx.serialization.builtins.ListSerializer(User.serializer()), users)).apply()
    }

    fun currentUserId(): String = sp.getString("app_current_user", null) ?: "u1"

    fun setCurrentUserId(id: String) {
        sp.edit().putString("app_current_user", id).apply()
    }

    companion object {
        /** 删除用户时需要清理的全部键 */
        val USER_DATA_KEYS = listOf(
            "settings_history_data", "summary_visibility_data", "deduction_stats_visibility_data", "subsidy_defaults_v2_data",
            "daily_records_map", "salary_settings_data", "subsidy_settings_data", "deduction_settings_data",
            "cycle_settings_data", "workday_settings_data", "normal_hours_data", "quick_settings_data",
            "theme_settings_data", "sheet_items_config", "sheet_custom_details"
        )
    }
}
