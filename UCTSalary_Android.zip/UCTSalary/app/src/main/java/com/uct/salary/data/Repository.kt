package com.uct.salary.data

import com.uct.salary.core.Calc
import com.uct.salary.model.DailyRecord
import com.uct.salary.model.DeductionCfg
import com.uct.salary.model.DeductionVisible
import com.uct.salary.model.QuickSettings
import com.uct.salary.model.Rates
import com.uct.salary.model.SalaryCfg
import com.uct.salary.model.SettingsVersion
import com.uct.salary.model.SheetItem
import com.uct.salary.model.SubsidyItem
import com.uct.salary.model.SummaryVisible
import com.uct.salary.model.ThemeSettings
import com.uct.salary.model.User
import com.uct.salary.model.UserData
import com.uct.salary.model.WEEK_DAYS
import com.uct.salary.model.defaultSheetItems
import com.uct.salary.model.defaultSubsidyList
import com.uct.salary.model.defaultVersion
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.builtins.MapSerializer
import kotlinx.serialization.builtins.serializer

/** 一个用户全部数据的读写；解析失败一律回落默认值，不抛异常 */
class Repository(private val store: Store) {

    private val json get() = store.json

    private inline fun <T> safe(default: T, block: () -> T?): T = try { block() ?: default } catch (e: Exception) { default }

    fun loadUserData(uid: String): UserData {
        val records = safe<Map<String, DailyRecord>>(emptyMap()) {
            store.get(uid, "daily_records_map")?.let {
                json.decodeFromString(MapSerializer(String.serializer(), DailyRecord.serializer()), it)
            }
        }
        val history = loadHistory(uid)
        val quick = safe(QuickSettings()) { store.get(uid, "quick_settings_data")?.let { json.decodeFromString(QuickSettings.serializer(), it) } }
        val sheet = safe(defaultSheetItems()) {
            store.get(uid, "sheet_items_config")?.let { json.decodeFromString(ListSerializer(SheetItem.serializer()), it) }
        }
        val theme = safe(ThemeSettings()) { store.get(uid, "theme_settings_data")?.let { json.decodeFromString(ThemeSettings.serializer(), it) } }
        val sv = safe(SummaryVisible()) { store.get(uid, "summary_visibility_data")?.let { json.decodeFromString(SummaryVisible.serializer(), it) } }
        val dv = safe(DeductionVisible()) { store.get(uid, "deduction_stats_visibility_data")?.let { json.decodeFromString(DeductionVisible.serializer(), it) } }
        val cycle = safe(15) { store.get(uid, "cycle_settings_data")?.trim()?.toDoubleOrNull()?.toInt()?.takeIf { it in 0..30 } }
        val workdays = safe(listOf("周一", "周二", "周三", "周四", "周五")) {
            store.get(uid, "workday_settings_data")?.let { json.decodeFromString(ListSerializer(String.serializer()), it) }
                ?.filter { WEEK_DAYS.contains(it) }
        }
        val nh = safe(8) { store.get(uid, "normal_hours_data")?.trim()?.toIntOrNull()?.takeIf { it in 1..24 } }
        return UserData(records, history, quick, sheet, theme, sv, dv, cycle, workdays, nh)
    }

    /** 读取设置版本；无版本时用旧版“工资/扣除/补贴”存档合成最早版本（P-5），并补全最早版本缺失的补贴与五险比例 */
    private fun loadHistory(uid: String): List<SettingsVersion> {
        var list: List<SettingsVersion> = safe<List<SettingsVersion>>(emptyList()) {
            store.get(uid, "settings_history_data")?.let { json.decodeFromString(ListSerializer(SettingsVersion.serializer()), it) }
        }
        var changed = false
        if (list.isEmpty()) {
            val sal = safe(SalaryCfg()) { store.get(uid, "salary_settings_data")?.let { json.decodeFromString(SalaryCfg.serializer(), it) } }
            val ded = safe(DeductionCfg()) { store.get(uid, "deduction_settings_data")?.let { json.decodeFromString(DeductionCfg.serializer(), it) } }
            val sub = safe(defaultSubsidyList()) {
                store.get(uid, "subsidy_settings_data")?.let { json.decodeFromString(ListSerializer(SubsidyItem.serializer()), it) }
            }
            val d = defaultVersion()
            list = listOf(
                d.copy(
                    salary = sal.copy(hourSalaryExact = sal.hourSalaryExact.ifBlank { sal.hourSalary.ifBlank { Calc.deriveHs(sal.baseSalary).toString() } }),
                    deduction = ded.copy(rates = ded.rates ?: Rates()),
                    subsidy = sub
                )
            )
            changed = true
        }
        val sorted = list.sortedBy { it.from }
        val first = sorted[0]
        if (first.subsidy == null || first.deduction.rates == null) {
            val fixed = first.copy(
                subsidy = first.subsidy ?: defaultSubsidyList(),
                deduction = first.deduction.copy(rates = first.deduction.rates ?: Rates())
            )
            list = listOf(fixed) + sorted.drop(1)
            changed = true
        } else list = sorted
        if (changed) saveHistory(uid, list)
        return list
    }

    /* ---------------- 写入 ---------------- */

    fun saveRecords(uid: String, v: Map<String, DailyRecord>) =
        store.put(uid, "daily_records_map", json.encodeToString(MapSerializer(String.serializer(), DailyRecord.serializer()), v))

    fun saveHistory(uid: String, v: List<SettingsVersion>) =
        store.put(uid, "settings_history_data", json.encodeToString(ListSerializer(SettingsVersion.serializer()), v))

    fun saveQuick(uid: String, v: QuickSettings) =
        store.put(uid, "quick_settings_data", json.encodeToString(QuickSettings.serializer(), v))

    fun saveSheet(uid: String, v: List<SheetItem>) =
        store.put(uid, "sheet_items_config", json.encodeToString(ListSerializer(SheetItem.serializer()), v))

    fun saveTheme(uid: String, v: ThemeSettings) =
        store.put(uid, "theme_settings_data", json.encodeToString(ThemeSettings.serializer(), v))

    fun saveSummaryVisible(uid: String, v: SummaryVisible) =
        store.put(uid, "summary_visibility_data", json.encodeToString(SummaryVisible.serializer(), v))

    fun saveDeductionVisible(uid: String, v: DeductionVisible) =
        store.put(uid, "deduction_stats_visibility_data", json.encodeToString(DeductionVisible.serializer(), v))

    fun saveCycleIndex(uid: String, v: Int) = store.put(uid, "cycle_settings_data", v.toString())

    fun saveWorkdays(uid: String, v: List<String>) =
        store.put(uid, "workday_settings_data", json.encodeToString(ListSerializer(String.serializer()), v))

    fun saveNormalHours(uid: String, v: Int) = store.put(uid, "normal_hours_data", v.toString())

    /** 整体写回（导入完成后调用） */
    fun saveAll(uid: String, d: UserData) {
        saveRecords(uid, d.records)
        saveHistory(uid, d.history)
        saveQuick(uid, d.quick)
        saveSheet(uid, d.sheetItems)
        saveTheme(uid, d.theme)
        saveSummaryVisible(uid, d.summaryVisible)
        saveDeductionVisible(uid, d.deductionVisible)
        saveCycleIndex(uid, d.cycleIndex)
        saveWorkdays(uid, d.workdays)
        saveNormalHours(uid, d.normalHours)
    }

    fun loadRecordsOf(uid: String): Map<String, DailyRecord> = safe<Map<String, DailyRecord>>(emptyMap()) {
        store.get(uid, "daily_records_map")?.let {
            json.decodeFromString(MapSerializer(String.serializer(), DailyRecord.serializer()), it)
        }
    }

    fun deleteUserData(uid: String) {
        Store.USER_DATA_KEYS.forEach { store.remove(uid, it) }
    }

    fun saveUsers(users: List<User>) = store.saveUsers(users)
}
