package com.uct.salary.ui

/** 页面路由；进入时压栈，返回时弹栈（NAV-1） */
sealed interface Route {
    data object Home : Route
    data object Calendar : Route
    data object Stats : Route
    data object Settings : Route
    data object SalaryDetail : Route
    data object SalarySettings : Route
    data object SubsidySettings : Route
    data object DeductionSettings : Route
    data object CycleSettings : Route
    data object WorkdaySettings : Route
    data object QuickSettings : Route
    data object ThemeSettings : Route
    data object UserManage : Route
    data class UserEdit(val userId: String?) : Route
    data object SheetManage : Route
}

/** 统一确认/提示弹窗（样式同“删除工时”确认框）。cancelText 为 null 时只有一个按钮 */
data class ConfirmState(
    val title: String,
    val desc: String,
    val confirmText: String = "确定",
    val cancelText: String? = "取消",
    val danger: Boolean = false,
    val onConfirm: () -> Unit = {}
)
