package com.uct.salary.core

import com.uct.salary.model.DailyRecord
import com.uct.salary.model.OtSegment
import com.uct.salary.model.Rates
import com.uct.salary.model.SalaryCfg
import com.uct.salary.model.SettingsVersion
import com.uct.salary.model.SheetItem
import com.uct.salary.model.SHIFT_TYPES_STATS
import com.uct.salary.model.SubsidyItem
import com.uct.salary.model.defaultSubsidyList
import com.uct.salary.model.defaultVersion
import kotlin.math.abs
import kotlin.math.max

/** 某周期生效的工资参数（已解析为数值） */
data class Cfg(val base: Double, val hs: Double, val social: Double, val housing: Double, val tax: Double)

data class Pay(val base: Double, val ot: Double, val total: Double, val hs: Double)

data class RateRow(val rate: Double, val pay: Double, val hours: Double, val days: Int, val hourly: Double)

data class SubsidyRow(val name: String, val value: Double, val sub: String)

/** 「工资核对」表：倍数 >=2.9 节日、>=1.9 双休、其余平时 */
data class Verify(
    val normalOt: Double,
    val doubleOt: Double,
    val holidayOt: Double,
    val midCount: Int,
    val nightCount: Int
)

/** 日历「收支汇总」六项原始值 */
data class Summary(
    val base: Double,
    val ot: Double,
    val night: Double,
    val meal: Double,
    val taxable: Double,
    val social: Double
)

data class CycleStats(
    val key: String,
    val recordKeys: List<String>,
    val shiftCounts: Map<String, Int>,
    val otDays: Int,
    val otHours: Double,
    val otIncome: Double,
    val rateRows: List<RateRow>,
    val durations: List<Pair<Double, Int>>,
    val dailyOt: List<Pair<String, Double>>,
    val cfg: Cfg,
    val basicTotal: Double,
    val subsidyRows: List<SubsidyRow>,
    val subTotal: Double,
    val totalDeduct: Double,
    val gross: Double,
    val net: Double,
    val verify: Verify,
    /** 工资条明细：倍数 >=1.9 记双休，其余记平时 */
    val sheetNormalOt: Double,
    val sheetDoubleOt: Double,
    val sheetMidCount: Int,
    val sheetNightCount: Int,
    val subAll: Double,
    val mealSub: Double
)

object Calc {

    /* ---------------- 时薪 ---------------- */

    fun deriveHs(base: String?): Double = Fmt.pfz(base) / 21.75 / 8.0

    /** 存档时薪若只是被四舍五入到两位的值，则还原为高精度值 */
    fun hsOf(s: SalaryCfg): Double {
        val d = deriveHs(s.baseSalary)
        val raw = if (s.hourSalaryExact.isNotBlank()) s.hourSalaryExact else s.hourSalary
        val st = Fmt.pf(raw)
        if (!(st > 0)) return d
        if (d > 0 && st != d && abs(st - d) < 0.005 && abs(st - Math.round(st * 100) / 100.0) < 1e-9) return d
        return st
    }

    /* ---------------- 设置版本 ---------------- */

    fun sorted(history: List<SettingsVersion>): List<SettingsVersion> = history.sortedBy { it.from }

    fun versionAt(history: List<SettingsVersion>, key: String): SettingsVersion {
        val list = sorted(history)
        if (list.isEmpty()) return defaultVersion()
        var pick = list[0]
        for (h in list) if (h.from <= key) pick = h
        return pick
    }

    fun subsidyAt(history: List<SettingsVersion>, key: String): List<SubsidyItem> {
        val l = sorted(history).filter { it.from <= key }
        for (i in l.indices.reversed()) {
            val s = l[i].subsidy
            if (s != null) return s
        }
        return defaultSubsidyList()
    }

    fun ratesAt(history: List<SettingsVersion>, key: String): Rates {
        val l = sorted(history).filter { it.from <= key }
        for (i in l.indices.reversed()) {
            val r = l[i].deduction.rates
            if (r != null) return r
        }
        return Rates()
    }

    fun settingsAt(history: List<SettingsVersion>, key: String): Cfg {
        val v = versionAt(history, key)
        val rates = ratesAt(history, key)
        val sum = rates.personalList().sumOf { Fmt.pfz(it) }
        return Cfg(
            base = Fmt.pfz(v.salary.baseSalary),
            hs = hsOf(v.salary),
            social = Fmt.pfz(v.deduction.socialBase) * sum / 100.0,
            housing = Fmt.pfz(v.deduction.housingBase) * (Fmt.pfz(v.deduction.housingRate) / 100.0),
            tax = Fmt.pfz(v.deduction.incomeTax)
        )
    }

    /** 以 key 为 from 写入/覆盖一份完整快照（P-2：从该周期起生效） */
    fun upsertVersion(
        history: List<SettingsVersion>,
        key: String,
        change: (SettingsVersion) -> SettingsVersion
    ): List<SettingsVersion> {
        val base = versionAt(history, key)
        val resolved = base.copy(
            from = key,
            subsidy = base.subsidy ?: subsidyAt(history, key),
            deduction = base.deduction.copy(rates = base.deduction.rates ?: ratesAt(history, key))
        )
        val nv = change(resolved).copy(from = key)
        return (history.filter { it.from != key } + nv).sortedBy { it.from }
    }

    /* ---------------- 基础工时 ---------------- */

    fun resolveBaseHours(dateStr: String, shiftType: String, workdays: List<String>, normalHours: Int): String {
        if (shiftType == "休息") return "休"
        if (shiftType == "周末加班" || shiftType == "节假日加班") return "0"
        val inWork = workdays.contains(Dates.weekDay(dateStr))
        return (if (inWork) normalHours else 0).toString()
    }

    /* ---------------- 单日工资 ---------------- */

    fun recPay(rec: DailyRecord, hs: Double): Pay {
        if (rec.hours == "休") return Pay(0.0, 0.0, 0.0, hs)
        val base = Fmt.pfz(rec.hours) * hs
        val segs = rec.otSegments
        val ot = if (!segs.isNullOrEmpty()) {
            var s = 0.0
            for (seg in segs) s += seg.hours * hs * (if (seg.rate == 0.0 || seg.rate.isNaN()) 1.0 else seg.rate)
            s
        } else {
            Fmt.pfz(rec.otHours) * hs * Fmt.pfOr(rec.otRate, 1.0)
        }
        return Pay(base, ot, base + ot, hs)
    }

    fun recPayAt(history: List<SettingsVersion>, dateKey: String, rec: DailyRecord): Pay {
        val ck = Dates.cycleKeyOfDate(dateKey) ?: Dates.realKey()
        return recPay(rec, settingsAt(history, ck).hs)
    }

    /** 加班分段；无分段时按单一倍数（倍数缺失用 fallback） */
    fun segmentsOf(rec: DailyRecord, otH: Double, fallbackRate: Double): List<OtSegment> {
        val segs = rec.otSegments
        if (!segs.isNullOrEmpty()) {
            return segs.map { OtSegment(it.hours, if (it.rate == 0.0 || it.rate.isNaN()) fallbackRate else it.rate) }
        }
        return listOf(OtSegment(otH, Fmt.pfOr(rec.otRate, fallbackRate)))
    }

    /* ---------------- 补贴 ---------------- */

    fun subsidyDays(item: SubsidyItem, cycleKey: String): Int =
        if (item.mode == "daily") (if (item.days > 0) item.days else Dates.monthDays(cycleKey)) else 0

    fun subsidyValue(item: SubsidyItem?, cycleKey: String): Double {
        if (item == null || !item.enabled) return 0.0
        return if (item.mode == "daily") item.amount * subsidyDays(item, cycleKey) else item.amount
    }

    fun subsidyLabel(item: SubsidyItem): String =
        if (item.mode == "daily") "¥${Fmt.jsNum(item.amount)}/天 × ${if (item.days > 0) "${item.days}天" else "当月天数"}"
        else "¥${Fmt.jsNum(item.amount)}/月"

    fun subsidyByName(list: List<SubsidyItem>, name: String): SubsidyItem? = list.firstOrNull { it.name == name }

    /* ---------------- 周期内记录 ---------------- */

    fun recordKeysInCycle(records: Map<String, DailyRecord>, key: String): List<String> =
        records.keys.filter { k ->
            val d = Dates.parse(k)
            d != null && Dates.inCycle(d, key)
        }.sorted()

    /* ---------------- 日历「收支汇总」 ---------------- */

    fun summary(records: Map<String, DailyRecord>, history: List<SettingsVersion>, key: String): Summary {
        val cfg = settingsAt(history, key)
        var ot = 0.0
        for (k in recordKeysInCycle(records, key)) ot += recPay(records.getValue(k), cfg.hs).ot
        val sub = subsidyAt(history, key)
        return Summary(
            base = cfg.base,
            ot = ot,
            night = subsidyValue(subsidyByName(sub, "夜班补贴"), key),
            meal = subsidyValue(subsidyByName(sub, "伙食补贴"), key),
            taxable = cfg.tax,
            social = cfg.social
        )
    }

    /* ---------------- 统计 / 工资条 ---------------- */

    fun cycleStats(records: Map<String, DailyRecord>, history: List<SettingsVersion>, key: String): CycleStats {
        val keys = recordKeysInCycle(records, key)
        val cfg = settingsAt(history, key)
        val subList = subsidyAt(history, key)

        val counts = LinkedHashMap<String, Int>()
        SHIFT_TYPES_STATS.forEach { counts[it] = 0 }
        var otDays = 0
        var otHoursTotal = 0.0
        var otIncome = 0.0
        val rateMap = java.util.TreeMap<Double, DoubleArray>()
        val durMap = java.util.TreeMap<Double, Int>()
        val dateMap = HashMap<String, Double>()

        var normalOt = 0.0
        var doubleOt = 0.0
        var holidayOt = 0.0
        var midCount = 0
        var nightCount = 0
        var sheetNormal = 0.0
        var sheetDouble = 0.0

        for (k in keys) {
            val rec = records.getValue(k)
            counts[rec.shiftType] = (counts[rec.shiftType] ?: 0) + 1
            val pay = recPay(rec, cfg.hs)
            val otH = Fmt.pfz(rec.otHours)

            if (otH > 0 && pay.ot > 0) {
                otDays++
                otHoursTotal += otH
                otIncome += pay.ot
                for (part in segmentsOf(rec, otH, 1.0)) {
                    val arr = rateMap.getOrPut(part.rate) { DoubleArray(3) }
                    arr[0] += part.hours
                    arr[1] += part.hours * pay.hs * part.rate
                    arr[2] += 1.0
                }
                durMap[otH] = (durMap[otH] ?: 0) + 1
                dateMap[k] = otH
            }

            for (part in segmentsOf(rec, otH, 1.5)) {
                val ph = part.hours
                val rate = part.rate
                if (rate >= 2.9) holidayOt += ph else if (rate >= 1.9) doubleOt += ph else normalOt += ph
                if (rate >= 1.9) sheetDouble += ph else sheetNormal += ph
            }
            if (rec.shiftType == "中班") midCount++
            if (rec.shiftType == "夜班") {
                val w = Dates.weekDay(k)
                if (w != "周六" && w != "周日") nightCount++
            }
        }

        var subTotal = 0.0
        var subAll = 0.0
        val subRows = ArrayList<SubsidyRow>()
        for (item in subList) {
            val v = subsidyValue(item, key)
            subAll += v
            if (item.enabled && v > 0) {
                subTotal += v
                subRows.add(
                    SubsidyRow(
                        item.name, v,
                        if (item.mode == "daily") "${Fmt.jsNum(item.amount)}元/天 × ${subsidyDays(item, key)}天" else "按月"
                    )
                )
            }
        }

        val basicTotal = cfg.base + otIncome
        val gross = basicTotal + subTotal
        val totalDeduct = cfg.social + cfg.housing + cfg.tax
        val net = gross - totalDeduct

        return CycleStats(
            key = key,
            recordKeys = keys,
            shiftCounts = counts,
            otDays = otDays,
            otHours = otHoursTotal,
            otIncome = otIncome,
            rateRows = rateMap.entries.map { RateRow(it.key, it.value[1], it.value[0], it.value[2].toInt(), cfg.hs * it.key) },
            durations = durMap.entries.map { it.key to it.value },
            dailyOt = Dates.daysOf(key).map { d -> Dates.iso(d).let { iso -> iso to (dateMap[iso] ?: 0.0) } },
            cfg = cfg,
            basicTotal = basicTotal,
            subsidyRows = subRows,
            subTotal = subTotal,
            totalDeduct = totalDeduct,
            gross = gross,
            net = net,
            verify = Verify(normalOt, doubleOt, holidayOt, midCount, nightCount),
            sheetNormalOt = sheetNormal,
            sheetDoubleOt = sheetDouble,
            sheetMidCount = midCount,
            sheetNightCount = nightCount,
            subAll = subAll,
            mealSub = subsidyValue(subsidyByName(subList, "伙食补贴"), key)
        )
    }

    /** 工资条「数据明细」取值（见需求说明书 6.8） */
    fun sheetValue(item: SheetItem, st: CycleStats): String {
        val r = Dates.cycleRange(st.key)
        val cfg = st.cfg
        return when (item.key) {
            "ym" -> "${r.startY}.${Dates.p2(r.startM)}-${r.endY}.${Dates.p2(r.endM)}"
            "std_days" -> "22"
            "norm_ot" -> Fmt.hour(st.sheetNormalOt)
            "dbl_ot" -> Fmt.hour(st.sheetDoubleOt)
            "mid_cnt" -> st.sheetMidCount.toString()
            "night_cnt" -> st.sheetNightCount.toString()
            "base_sal" -> Fmt.money(cfg.base)
            "overtime" -> Fmt.money(st.otIncome)
            "meal_sub" -> Fmt.money(st.mealSub)
            "income" -> Fmt.money(cfg.base + st.otIncome + st.subAll)
            "social" -> Fmt.money(cfg.social + cfg.housing)
            "tax" -> Fmt.money(cfg.tax)
            "net" -> Fmt.money(st.net)
            else -> "0"
        }
    }

    /** 明细项标签：「X月社保」「预扣X月个税」中的 X 取所看周期起始月 */
    fun sheetLabel(item: SheetItem, key: String): String {
        val m = Dates.cycleRange(key).startM
        val t = item.label.trim()
        return when {
            Regex("^\\d{1,2}月社保$").matches(t) -> "${m}月社保"
            Regex("^预扣\\d{1,2}月个税$").matches(t) -> "预扣${m}月个税"
            else -> item.label
        }
    }

    /** 日历单元格是否按「夜班」描边：日夜班=夜班（或缺省时班次为夜班）且非休息 */
    fun dayNightOf(rec: DailyRecord): String =
        if (rec.dayNight.isNotEmpty()) rec.dayNight
        else if (rec.shiftType == "白班" || rec.shiftType == "夜班") rec.shiftType else ""

    fun maxOf0(v: Double): Double = max(0.0, v)
}
