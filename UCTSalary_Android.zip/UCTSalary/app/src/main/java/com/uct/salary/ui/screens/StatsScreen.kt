package com.uct.salary.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.uct.salary.core.Calc
import com.uct.salary.core.CycleStats
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.AppTopBar
import com.uct.salary.ui.components.BarsChart
import com.uct.salary.ui.components.CardBox
import com.uct.salary.ui.components.CycleNav
import com.uct.salary.ui.components.DonutChart
import com.uct.salary.ui.components.DonutItem
import com.uct.salary.ui.components.EyeButton
import com.uct.salary.ui.components.Segmented
import com.uct.salary.ui.components.chartColors
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray600
import com.uct.salary.ui.theme.Gray700
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.Red500
import com.uct.salary.ui.theme.White

@Composable
fun StatsScreen(vm: AppViewModel) {
    val key = vm.viewKey
    val r = Dates.cycleRange(key)
    val st = remember(vm.data.records, vm.data.history, key) { Calc.cycleStats(vm.data.records, vm.data.history, key) }
    val pickImport = rememberImportLauncher(vm)

    Column(Modifier.fillMaxSize()) {
        AppTopBar("统计", onBack = { vm.pop() })
        CycleNav(
            "${Dates.prevMonthNumber(r.startM)}月", Dates.title(key), "${Dates.nextMonthNumber(r.endM)}月",
            onPrev = { vm.viewKey = Dates.shiftKey(key, -1) }, onNext = { vm.viewKey = Dates.shiftKey(key, 1) },
            modifier = Modifier.background(White)
        )
        Box(Modifier.fillMaxWidth().background(White).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Segmented(listOf("加班统计", "记月工资", "班次统计", "工资条"), vm.statsTab, { vm.statsTab = it })
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (vm.statsTab) {
                0 -> OvertimeTab(st)
                1 -> SalaryTab(vm, st)
                2 -> ShiftTab(vm, st)
                else -> SheetTab(vm, st, pickImport)
            }
            Spacer(Modifier.height(8.dp))
        }
        if (vm.statsTab == 1) {
            // 底部固定栏：收入 / 扣除 / 本月收入
            Row(Modifier.fillMaxWidth().background(White).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                FooterCell("收入", Fmt.money(st.gross), Gray900, Modifier.weight(1f))
                FooterCell("扣除", "-" + Fmt.money(st.totalDeduct), Red500, Modifier.weight(1f))
                FooterCell("本月收入", Fmt.money(st.net), primary(), Modifier.weight(1.2f))
            }
        } else Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
private fun FooterCell(label: String, value: String, color: androidx.compose.ui.graphics.Color, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 12.sp, color = Gray500)
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

/* ============================ A. 加班统计 ============================ */

@Composable
private fun OvertimeTab(st: CycleStats) {
    val pri = primary()
    CardBox {
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1.3f)) {
                Text("加班收入(元)", fontSize = 12.sp, color = Gray500)
                Text(Fmt.money(st.otIncome), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Gray900)
            }
            Column(Modifier.weight(1f)) {
                Text("已加班(天)", fontSize = 12.sp, color = Gray500)
                Text(st.otDays.toString(), fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Gray900)
            }
            Column(Modifier.weight(1f)) {
                Text("已加班(小时)", fontSize = 12.sp, color = Gray500)
                Text(Fmt.hour(st.otHours), fontSize = 22.sp, fontWeight = FontWeight.Medium, color = Gray900)
            }
        }
    }

    CardBox {
        Text("汇总", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(8.dp))
        if (st.rateRows.isEmpty()) Text("暂无加班数据", fontSize = 13.sp, color = Gray400)
        st.rateRows.forEach { row ->
            val pct = if (st.otIncome > 0) (row.pay / st.otIncome).toFloat().coerceIn(0f, 1f) else 0f
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(pri.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("${Fmt.jsNum(row.rate)}倍", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Gray800)
                        Text("工资", fontSize = 10.sp, color = Gray500)
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${Fmt.fixed2(row.hourly)}元/小时", fontSize = 12.sp, color = Gray500)
                        Text("${Fmt.hour(row.hours)}小时 · ${row.days}天", fontSize = 12.sp, color = Gray500)
                    }
                    Text(Fmt.money(row.pay), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Gray900)
                }
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)).background(Gray100)) {
                        Box(Modifier.fillMaxWidth(pct).height(6.dp).clip(RoundedCornerShape(3.dp)).background(pri))
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("${Fmt.fixed2(pct * 100.0)}%".replace(".00%", "%"), fontSize = 11.sp, color = Gray500)
                }
            }
        }
    }

    CardBox {
        Text("加班收入分析", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(10.dp))
        if (st.rateRows.isEmpty()) {
            Text("暂无加班数据", fontSize = 13.sp, color = Gray400, modifier = Modifier.padding(vertical = 24.dp).fillMaxWidth(), textAlign = TextAlign.Center)
        } else {
            val colors = chartColors(pri, st.rateRows.size)
            DonutChart(
                st.rateRows.mapIndexed { i, rr -> DonutItem("${Fmt.jsNum(rr.rate)}倍", rr.pay, Fmt.money(rr.pay) + "元", colors[i]) },
                Fmt.money(st.otIncome), "加班收入"
            )
        }
    }

    CardBox {
        Text("加班时长统计", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(10.dp))
        if (st.durations.isEmpty()) Text("暂无加班数据", fontSize = 13.sp, color = Gray400)
        else BarsChart(st.durations.map { "${Fmt.hour(it.first)}h" to it.second.toDouble() }, pri)
    }

    CardBox {
        Text("加班日期统计", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(10.dp))
        BarsChart(st.dailyOt.map { it.first.substring(8).trimStart('0').ifEmpty { "0" } to it.second }, pri, barWidth = 12.dp, chartHeight = 120.dp)
    }
}

/* ============================ B. 记月工资 ============================ */

@Composable
private fun SalaryTab(vm: AppViewModel, st: CycleStats) {
    val dv = vm.data.deductionVisible
    var basicOpen by remember { mutableStateOf(true) }
    var subOpen by remember { mutableStateOf(false) }
    var dedOpen by remember { mutableStateOf(false) }

    CardBox {
        Text("本月收入", fontSize = 13.sp, color = Gray500)
        Text(Fmt.money(st.net), fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Gray900)
    }

    Panel("基本项目", Fmt.money(st.basicTotal), basicOpen, { basicOpen = !basicOpen }) {
        ItemRow("基本工资", null, Fmt.money(st.cfg.base)) { vm.jumpSettings(Route.SalarySettings) }
        ItemRow("加班工资", null, Fmt.money(st.otIncome)) { vm.jumpSettings(Route.SalarySettings) }
    }

    Panel("补贴项目", Fmt.money(st.subTotal), subOpen, { subOpen = !subOpen }) {
        if (st.subsidyRows.isEmpty()) {
            Text("暂无补贴项目（点击去设置）", fontSize = 13.sp, color = Gray400, modifier = Modifier.fillMaxWidth().clickable { vm.jumpSettings(Route.SubsidySettings) }.padding(vertical = 12.dp), textAlign = TextAlign.Center)
        }
        st.subsidyRows.forEach { ItemRow(it.name, it.sub, "+" + Fmt.money(it.value)) { vm.jumpSettings(Route.SubsidySettings) } }
    }

    Panel("扣除项目", "-" + Fmt.money(st.totalDeduct), dedOpen, { dedOpen = !dedOpen }) {
        if (!dv.social && !dv.housing && !dv.tax) {
            Text("当前没有启用显示的扣除项目", fontSize = 13.sp, color = Gray400, modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), textAlign = TextAlign.Center)
        }
        if (dv.social) ItemRow("五险（个人）", null, "-" + Fmt.money(st.cfg.social), eye = { vm.setDeductionVisible(dv.copy(social = false)) }) { vm.jumpSettings(Route.DeductionSettings) }
        if (dv.housing) ItemRow("公积金（个人）", null, "-" + Fmt.money(st.cfg.housing), eye = { vm.setDeductionVisible(dv.copy(housing = false)) }) { vm.jumpSettings(Route.DeductionSettings) }
        if (dv.tax) ItemRow("个人所得税", null, "-" + Fmt.money(st.cfg.tax), eye = { vm.setDeductionVisible(dv.copy(tax = false)) }) { vm.jumpSettings(Route.DeductionSettings) }
        if (!dv.social || !dv.housing || !dv.tax) {
            Text(
                "显示全部扣除项", fontSize = 12.sp, color = Gray500,
                modifier = Modifier.fillMaxWidth().clickable { vm.setDeductionVisible(com.uct.salary.model.DeductionVisible()) }.padding(vertical = 10.dp), textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun Panel(title: String, total: String, open: Boolean, onToggle: () -> Unit, content: @Composable () -> Unit) {
    CardBox(padding = 0.dp) {
        Row(Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(primary().copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Icon(AppIcons.Money, null, tint = Gray800, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Text(title, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900, modifier = Modifier.weight(1f))
            Text(total, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.width(6.dp))
            Icon(if (open) AppIcons.ExpandLess else AppIcons.ExpandMore, null, tint = Gray400)
        }
        if (open) {
            Column(Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 8.dp)) { content() }
        }
    }
}

@Composable
private fun ItemRow(name: String, sub: String?, value: String, eye: (() -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, fontSize = 14.sp, color = Gray800)
            if (sub != null) Text(sub, fontSize = 11.sp, color = Gray500)
        }
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (value.startsWith("-")) Red500 else Gray900)
        if (eye != null) {
            Spacer(Modifier.width(8.dp))
            EyeButton(true, eye, size = 18.dp)
        }
        Icon(AppIcons.Right, null, tint = Gray400, modifier = Modifier.size(18.dp))
    }
}

/* ============================ C. 班次统计 ============================ */

@Composable
private fun ShiftTab(vm: AppViewModel, st: CycleStats) {
    val pri = primary()
    val names = listOf("早班", "中班", "晚班", "白班", "夜班", "休息")
    CardBox {
        names.chunked(3).forEach { rowNames ->
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                rowNames.forEach { n ->
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(Gray100).clickable { vm.shiftDetailFor = n }.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(n, fontSize = 13.sp, color = Gray600)
                        Text("${st.shiftCounts[n] ?: 0}天", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Gray900)
                    }
                }
            }
        }
    }
    CardBox {
        Text("班次分布", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(10.dp))
        val present = names.filter { (st.shiftCounts[it] ?: 0) > 0 }
        if (present.isEmpty()) {
            Text("暂无班次数据", fontSize = 13.sp, color = Gray400, modifier = Modifier.padding(vertical = 24.dp).fillMaxWidth(), textAlign = TextAlign.Center)
        } else {
            val colors = chartColors(pri, present.size)
            val total = present.sumOf { st.shiftCounts[it] ?: 0 }
            DonutChart(present.mapIndexed { i, n -> DonutItem(n, (st.shiftCounts[n] ?: 0).toDouble(), "${st.shiftCounts[n]}天", colors[i]) }, "${total}天", "班次天数")
        }
    }
}

/* ============================ D. 工资条 ============================ */

@Composable
private fun SheetTab(vm: AppViewModel, st: CycleStats, pickImport: () -> Unit) {
    Segmented(listOf("工资核对", "数据明细"), vm.sheetSub, { vm.sheetSub = it })
    if (vm.sheetSub == 0) VerifyTable(vm, st) else DetailForm(vm, st, pickImport)
}

@Composable
private fun VerifyTable(vm: AppViewModel, st: CycleStats) {
    val r = Dates.cycleRange(st.key)
    val u = vm.currentUser
    val heads = listOf("员工编号", "中文名", "年月", "公司", "组", "标准天数", "平时加班(h)", "双休加班(h)", "节日加班(h)", "中班次数", "夜班次数", "调休加班")
    val vals = listOf(
        u.id, u.name, "${r.startY}年${Dates.p2(r.startM)}月-${r.endY}年${Dates.p2(r.endM)}月", "默认公司", "默认组", "22",
        Fmt.hour(st.verify.normalOt), Fmt.hour(st.verify.doubleOt), Fmt.hour(st.verify.holidayOt),
        st.verify.midCount.toString(), st.verify.nightCount.toString(), "0"
    )
    CardBox {
        Text("考勤与工时核对表", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(10.dp))
        Column(Modifier.horizontalScroll(rememberScrollState())) {
            TableRow(heads, header = true, widths = listOf(84.dp, 72.dp, 170.dp, 72.dp, 56.dp, 72.dp, 88.dp, 88.dp, 88.dp, 72.dp, 72.dp, 72.dp))
            TableRow(vals, header = false, widths = listOf(84.dp, 72.dp, 170.dp, 72.dp, 56.dp, 72.dp, 88.dp, 88.dp, 88.dp, 72.dp, 72.dp, 72.dp))
        }
    }
}

@Composable
fun TableRow(cells: List<String>, header: Boolean, widths: List<Dp>) {
    Row(Modifier.background(if (header) Gray100 else White)) {
        cells.forEachIndexed { i, c ->
            Text(
                c, fontSize = 12.sp, color = if (header) Gray600 else Gray900, fontWeight = if (header) FontWeight.Medium else FontWeight.Normal,
                modifier = Modifier.width(widths.getOrElse(i) { 80.dp }).padding(horizontal = 6.dp, vertical = 8.dp), maxLines = 2
            )
        }
    }
}

@Composable
private fun DetailForm(vm: AppViewModel, st: CycleStats, pickImport: () -> Unit) {
    CardBox {
        Text("工资明细表单参数", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
        Spacer(Modifier.height(6.dp))
        vm.data.sheetItems.filter { it.enabled }.forEach { item ->
            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(Calc.sheetLabel(item, st.key), fontSize = 14.sp, color = Gray600, modifier = Modifier.weight(1f))
                Text(Calc.sheetValue(item, st), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Gray900)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(Gray100))
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        ActionButton("明细项管理", AppIcons.Edit, Modifier.weight(1f)) { vm.push(Route.SheetManage) }
        ActionButton("导入数据", AppIcons.Upload, Modifier.weight(1f), onClick = pickImport)
        ActionButton("导出数据", AppIcons.Download, Modifier.weight(1f)) { vm.exportOpen = true }
    }
}

@Composable
fun ActionButton(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(10.dp)).background(primary().copy(alpha = 0.16f)).clickable(onClick = onClick).padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Gray800, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 13.sp, color = Gray800, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

/* ============================ 班次明细弹窗 ============================ */

@Composable
fun ShiftDetailDialog(vm: AppViewModel, shift: String) {
    val st = remember(vm.data.records, vm.data.history, vm.viewKey) { Calc.cycleStats(vm.data.records, vm.data.history, vm.viewKey) }
    val keys = st.recordKeys.filter { vm.data.records.getValue(it).shiftType == shift }
    val heads = listOf("序号", "日期", "星期", "工时", "基本工资", "加班工资", "当日合计", "班次", "备注")
    val widths = listOf(48.dp, 96.dp, 56.dp, 56.dp, 80.dp, 80.dp, 80.dp, 80.dp, 160.dp)
    Dialog(onDismissRequest = { vm.shiftDetailFor = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).clip(RoundedCornerShape(16.dp)).background(White).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("$shift - 班次明细记录", fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900, modifier = Modifier.weight(1f))
                    Icon(AppIcons.Close, "关闭", tint = Gray500, modifier = Modifier.size(22.dp).clickable { vm.shiftDetailFor = null })
                }
                Spacer(Modifier.height(10.dp))
                if (keys.isEmpty()) {
                    Text("该周期内暂无【$shift】记录", fontSize = 14.sp, color = Gray400, modifier = Modifier.padding(vertical = 28.dp).fillMaxWidth(), textAlign = TextAlign.Center)
                } else {
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        TableRow(heads, true, widths)
                        Column(Modifier.verticalScroll(rememberScrollState())) {
                            keys.forEachIndexed { i, k ->
                                val rec = vm.data.records.getValue(k)
                                val pay = Calc.recPay(rec, st.cfg.hs)
                                TableRow(
                                    listOf((i + 1).toString(), k, Dates.weekDay(k), rec.hours, Fmt.money(pay.base), Fmt.money(pay.ot), Fmt.money(pay.total), rec.shiftType, rec.remark),
                                    false, widths
                                )
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.fillMaxWidth().height(44.dp).clip(RoundedCornerShape(8.dp)).background(primary()).clickable { vm.shiftDetailFor = null },
                    contentAlignment = Alignment.Center
                ) { Text("关闭", color = onPrimary(), fontSize = 15.sp, fontWeight = FontWeight.Medium) }
            }
        }
    }
}
