package com.uct.salary.core

import java.time.LocalDate

/** 一个工资周期：上月 16 日 ～ 本月 15 日；周期键 = 结束月的 YYYYMM */
data class CycleRange(val startY: Int, val startM: Int, val endY: Int, val endM: Int) {
    val start: LocalDate get() = LocalDate.of(startY, startM, 16)
    val end: LocalDate get() = LocalDate.of(endY, endM, 15)
}

object Dates {
    private val WEEK = listOf("周日", "周一", "周二", "周三", "周四", "周五", "周六")

    fun weekDay(d: LocalDate): String = WEEK[d.dayOfWeek.value % 7]

    fun weekDay(s: String): String = parse(s)?.let { weekDay(it) } ?: "周二"

    fun parse(s: String?): LocalDate? = try {
        if (s == null) null else LocalDate.parse(s.trim())
    } catch (e: Exception) {
        null
    }

    fun today(): LocalDate = LocalDate.now()

    fun iso(d: LocalDate): String = d.toString()

    /** 日期所在周期键：日 >= 16 则归入次月 */
    fun cycleKeyOfDate(d: LocalDate): String {
        var y = d.year
        var m = d.monthValue
        if (d.dayOfMonth >= 16) {
            m++
            if (m > 12) { m = 1; y++ }
        }
        return (y * 100 + m).toString()
    }

    fun cycleKeyOfDate(s: String): String? = parse(s)?.let { cycleKeyOfDate(it) }

    fun realKey(): String = cycleKeyOfDate(today())

    fun keyYear(key: String): Int = key.toInt() / 100
    fun keyMonth(key: String): Int = key.toInt() % 100

    fun cycleRange(key: String): CycleRange {
        val y = keyYear(key)
        val m = keyMonth(key)
        val prevM = if (m == 1) 12 else m - 1
        val prevY = if (m == 1) y - 1 else y
        return CycleRange(prevY, prevM, y, m)
    }

    fun shiftKey(key: String, delta: Int): String {
        var y = keyYear(key)
        var m = keyMonth(key) + delta
        while (m < 1) { m += 12; y-- }
        while (m > 12) { m -= 12; y++ }
        return (y * 100 + m).toString()
    }

    fun p2(n: Int): String = n.toString().padStart(2, '0')

    fun prevMonthNumber(m: Int): Int = if (m == 1) 12 else m - 1
    fun nextMonthNumber(m: Int): Int = if (m == 12) 1 else m + 1

    /** 周期结束月的自然日数（按日补贴未填天数时使用） */
    fun monthDays(key: String): Int = LocalDate.of(keyYear(key), keyMonth(key), 1).lengthOfMonth()

    fun inCycle(d: LocalDate, key: String): Boolean {
        val r = cycleRange(key)
        return !d.isBefore(r.start) && !d.isAfter(r.end)
    }

    /** "MM.16-MM.15" */
    fun title(key: String): String {
        val r = cycleRange(key)
        return "${p2(r.startM)}.16-${p2(r.endM)}.15"
    }

    /** 设置页配置周期条：2026年09.16 - 10.15 */
    fun longLabel(key: String): String {
        val r = cycleRange(key)
        return "${r.startY}年${p2(r.startM)}.16 - ${p2(r.endM)}.15"
    }

    /** 周期内全部日期（含首尾） */
    fun daysOf(key: String): List<LocalDate> {
        val r = cycleRange(key)
        val out = ArrayList<LocalDate>()
        var d = r.start
        while (!d.isAfter(r.end)) { out.add(d); d = d.plusDays(1) }
        return out
    }
}
