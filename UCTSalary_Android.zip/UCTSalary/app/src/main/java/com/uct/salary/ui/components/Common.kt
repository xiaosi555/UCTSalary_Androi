package com.uct.salary.ui.components

import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.input.KeyboardType
import com.uct.salary.model.User
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray50
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray700
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.LocalPrimary
import com.uct.salary.ui.theme.Red500
import com.uct.salary.ui.theme.White
import com.uct.salary.ui.theme.isLightColor

@Composable
fun primary(): Color = LocalPrimary.current

@Composable
fun onPrimary(): Color = if (isLightColor(LocalPrimary.current)) Gray800 else White

@Composable
fun Modifier.plainClickable(onClick: () -> Unit): Modifier =
    this.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onClick)

/* ---------------------------------------------------------------- 顶栏 */

@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)?,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier
            .fillMaxWidth()
            .background(White)
            .statusBarsPadding()
            .height(52.dp)
            .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(AppIcons.Back, contentDescription = "返回", tint = Gray800) }
        } else Spacer(Modifier.width(12.dp))
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = Gray900, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
    }
}

/* ---------------------------------------------------------------- 卡片 / 标题 */

@Composable
fun CardBox(modifier: Modifier = Modifier, padding: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(White)
            .padding(padding),
        content = content
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Row(modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(primary()))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
    }
}

@Composable
fun SettingRow(
    title: String,
    value: String? = null,
    icon: ImageVector? = null,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            Box(Modifier.size(36.dp).clip(RoundedCornerShape(10.dp)).background(primary().copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Gray800, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 15.sp, color = Gray900)
            if (!value.isNullOrEmpty()) Text(value, fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(top = 2.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Icon(AppIcons.Right, null, tint = Gray400)
    }
}

/* ---------------------------------------------------------------- 弹窗（与“删除工时”确认框同一样式） */

@Composable
fun AppDialog(
    title: String,
    desc: String,
    confirmText: String,
    cancelText: String? = "取消",
    danger: Boolean = false,
    onConfirm: () -> Unit,
    onCancel: () -> Unit = {}
) {
    Dialog(
        onDismissRequest = { if (cancelText != null) onCancel() else onConfirm() },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        var shown by remember { mutableStateOf(false) }
        LaunchedEffect(Unit) { shown = true }
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            AnimatedVisibility(shown, enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.92f, animationSpec = tween(220))) {
                Column(
                    Modifier
                        .widthIn(max = 384.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(White)
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        desc, fontSize = 14.sp, color = Gray500, textAlign = TextAlign.Center,
                        modifier = Modifier.heightIn(max = 320.dp).verticalScroll(rememberScrollState())
                    )
                    Spacer(Modifier.height(24.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (cancelText != null) {
                            Box(
                                Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(8.dp)).background(White)
                                    .border(1.dp, Gray200, RoundedCornerShape(8.dp)).clickable(onClick = onCancel),
                                contentAlignment = Alignment.Center
                            ) { Text(cancelText, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray700) }
                        }
                        Box(
                            Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(8.dp))
                                .background(if (danger) Red500 else primary()).clickable(onClick = onConfirm),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(confirmText, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = if (danger) White else onPrimary())
                        }
                    }
                }
            }
        }
    }
}

/* ---------------------------------------------------------------- 输入 */

@Composable
fun Field(
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    keyboard: KeyboardType = KeyboardType.Text,
    singleLine: Boolean = true,
    minLines: Int = 1,
    enabled: Boolean = true,
    textAlign: TextAlign = TextAlign.Start,
    onFocusChange: ((Boolean) -> Unit)? = null
) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        modifier = modifier.onFocusChanged { onFocusChange?.invoke(it.isFocused) },
        enabled = enabled,
        singleLine = singleLine,
        minLines = minLines,
        textStyle = TextStyle(fontSize = 14.sp, color = if (enabled) Gray900 else Gray500, textAlign = textAlign),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        cursorBrush = SolidColor(primary()),
        decorationBox = { inner ->
            Box(
                Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (enabled) Gray50 else Gray100)
                    .border(1.dp, Gray200, RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                if (value.isEmpty()) Text(placeholder, color = Gray400, fontSize = 14.sp)
                inner()
            }
        }
    )
}

@Composable
fun LabeledField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier = Modifier, placeholder: String = "", keyboard: KeyboardType = KeyboardType.Text, enabled: Boolean = true) {
    Column(modifier) {
        Text(label, fontSize = 13.sp, color = Gray500, modifier = Modifier.padding(bottom = 4.dp))
        Field(value, onChange, Modifier.fillMaxWidth(), placeholder, keyboard, enabled = enabled)
    }
}

@Composable
fun PillSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = checked,
        onCheckedChange = onChange,
        colors = SwitchDefaults.colors(checkedTrackColor = primary(), checkedThumbColor = White, uncheckedTrackColor = Gray200, uncheckedThumbColor = White, uncheckedBorderColor = Gray200, checkedBorderColor = primary())
    )
}

@Composable
fun Segmented(options: List<String>, selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.clip(RoundedCornerShape(10.dp)).background(Gray100).padding(3.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                    .background(if (on) primary() else Color.Transparent)
                    .clickable { onSelect(i) }.padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) { Text(label, fontSize = 14.sp, fontWeight = if (on) FontWeight.Medium else FontWeight.Normal, color = if (on) onPrimary() else Gray500) }
        }
    }
}

@Composable
fun DropdownField(value: String, options: List<String>, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(modifier) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Gray50).border(1.dp, Gray200, RoundedCornerShape(8.dp))
                .clickable { open = true }.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(value, fontSize = 14.sp, color = Gray900, modifier = Modifier.weight(1f))
            Icon(AppIcons.Down, null, tint = Gray400, modifier = Modifier.size(18.dp))
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { o -> DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onSelect(o) }) }
        }
    }
}

@Composable
fun EyeButton(visible: Boolean, onClick: () -> Unit, tint: Color = Gray400, size: Dp = 20.dp) {
    Icon(
        if (visible) AppIcons.Eye else AppIcons.EyeOff, null, tint = tint,
        modifier = Modifier.size(size).clip(CircleShape).clickable(onClick = onClick)
    )
}

/* ---------------------------------------------------------------- 周期切换 */

@Composable
fun CycleNav(prevLabel: String, title: String, nextLabel: String, onPrev: () -> Unit, onNext: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("‹ $prevLabel", fontSize = 13.sp, color = Gray500, modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onPrev).padding(8.dp))
        Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
        Text("$nextLabel ›", fontSize = 13.sp, color = Gray500, modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onNext).padding(8.dp))
    }
}

/** 设置页顶部“配置周期”切换条（P-4） */
@Composable
fun CycleConfigBar(label: String, isNow: Boolean, onPrev: () -> Unit, onNext: () -> Unit, modifier: Modifier = Modifier) {
    CardBox(modifier, padding = 8.dp) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("‹", fontSize = 22.sp, color = Gray500, modifier = Modifier.clickable(onClick = onPrev).padding(horizontal = 14.dp, vertical = 2.dp))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(label + if (isNow) "（当前周期）" else "", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = Gray900)
                Text("配置周期 · 保存后从该周期起生效，更早周期不受影响", fontSize = 11.sp, color = Gray400, modifier = Modifier.padding(top = 2.dp), textAlign = TextAlign.Center)
            }
            Text("›", fontSize = 22.sp, color = Gray500, modifier = Modifier.clickable(onClick = onNext).padding(horizontal = 14.dp, vertical = 2.dp))
        }
    }
}

/* ---------------------------------------------------------------- 头像 */

fun decodeAvatar(s: String): ImageBitmap? {
    if (!s.startsWith("data:image")) return null
    return try {
        val b64 = s.substringAfter("base64,", "")
        if (b64.isEmpty()) return null
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()
    } catch (e: Exception) {
        null
    }
}

@Composable
fun Avatar(user: User?, size: Dp, modifier: Modifier = Modifier) {
    val bmp = remember(user?.avatar) { decodeAvatar(user?.avatar ?: "") }
    Box(modifier.size(size).clip(CircleShape).background(primary().copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
        if (bmp != null) {
            Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text((user?.name ?: "").take(1), fontSize = (size.value * 0.42f).sp, color = Gray700, fontWeight = FontWeight.Medium)
        }
    }
}
