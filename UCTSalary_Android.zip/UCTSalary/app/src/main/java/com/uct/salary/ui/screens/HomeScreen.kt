package com.uct.salary.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.uct.salary.core.Calc
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.model.QuickRecord
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.Avatar
import com.uct.salary.ui.components.EyeButton
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray50
import com.uct.salary.ui.theme.Gray600
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.White

@Composable
fun HomeScreen(vm: AppViewModel) {
    val key = Dates.realKey()
    val st = remember(vm.data, key) { Calc.cycleStats(vm.data.records, vm.data.history, key) }
    val r = Dates.cycleRange(key)
    val pri = primary()
    val pop = remember { Animatable(1f) }
    LaunchedEffect(vm.switchTick) {
        if (vm.switchTick > 0) {
            pop.snapTo(0.5f)
            pop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth().height(300.dp)) {
            Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(pri, pri.copy(alpha = 0.72f)))))
            AsyncImage(
                model = vm.data.theme.bg, contentDescription = null, contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(), alpha = 0.55f
            )
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.10f)))
            Column(Modifier.statusBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("UCT salary", color = White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Avatar(
                        vm.currentUser, 36.dp,
                        Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                            .border(2.dp, White.copy(alpha = 0.8f), CircleShape)
                            .clickable { vm.userSwitchOpen = true }
                    )
                    Spacer(Modifier.width(12.dp))
                    Icon(AppIcons.Settings, "设置", tint = White, modifier = Modifier.size(26.dp).clip(CircleShape).clickable { vm.openSettingsPage(Route.Settings) })
                }
                Spacer(Modifier.height(28.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${Dates.p2(r.startM)}.16 - ${Dates.p2(r.endM)}.15收入", color = White.copy(alpha = 0.9f), fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                    EyeButton(vm.homeEye, { vm.homeEye = !vm.homeEye }, tint = White.copy(alpha = 0.9f), size = 22.dp)
                }
                Spacer(Modifier.height(6.dp))
                Text(if (vm.homeEye) Fmt.money(st.net) else "****.**", color = White, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(36.dp)) {
                    Column {
                        Text("加班时长", color = White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text(if (vm.homeEye) Fmt.hour(st.otHours) else "****", color = White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                    Column {
                        Text("加班收入", color = White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text(if (vm.homeEye) Fmt.money(st.otIncome) else "****.**", color = White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

        // 白色功能卡片，向上压住头部
        Column(
            Modifier.padding(horizontal = 16.dp).offset(y = (-72).dp).fillMaxWidth()
                .clip(RoundedCornerShape(16.dp)).background(White).padding(16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround) {
                HomeEntry(AppIcons.Calendar, "日历") { vm.openCalendar() }
                HomeEntry(AppIcons.BarChart, "统计") { vm.openStats(0) }
                HomeEntry(AppIcons.Sign, "签到") { /* 基线版无功能，保留占位 */ }
            }
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(24.dp)).background(pri).clickable { vm.openNewRecordToday() },
                contentAlignment = Alignment.Center
            ) { Text("记加班", color = onPrimary(), fontSize = 16.sp, fontWeight = FontWeight.Medium) }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    when {
                        !vm.data.quick.show -> Text("快捷记录展示已关闭", fontSize = 12.sp, color = Gray400)
                        vm.data.quick.records.isEmpty() -> Text("暂无快捷记录", fontSize = 12.sp, color = Gray400)
                        else -> vm.data.quick.records.forEach { q -> QuickTag(q) { vm.quickRecord(q) } }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.clip(RoundedCornerShape(6.dp)).dashedBorder(Gray400).clickable { vm.push(Route.QuickSettings) }.padding(horizontal = 8.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(AppIcons.Bolt, null, tint = Gray600, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(2.dp))
                    Text("设置", fontSize = 12.sp, color = Gray600)
                }
            }
        }
    }
}

@Composable
private fun HomeEntry(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(primary().copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Gray800, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text(label, fontSize = 13.sp, color = Gray800)
    }
}

@Composable
private fun QuickTag(q: QuickRecord, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(6.dp)).background(Gray50).border(1.dp, Gray200, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(q.name, fontSize = 12.sp, color = Gray600, maxLines = 1)
        Text("•", fontSize = 12.sp, color = Gray400, modifier = Modifier.padding(horizontal = 3.dp))
        Text("${Fmt.hour(q.hours)}h", fontSize = 12.sp, color = Gray600, maxLines = 1)
    }
}

fun Modifier.dashedBorder(color: Color): Modifier = this.drawBehind {
    drawRoundRect(
        color = color,
        cornerRadius = CornerRadius(6.dp.toPx()),
        style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
    )
}
