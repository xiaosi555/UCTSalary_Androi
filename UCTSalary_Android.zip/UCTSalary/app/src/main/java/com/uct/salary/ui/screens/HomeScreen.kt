package com.uct.salary.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.uct.salary.core.Calc
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.model.QuickRecord
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.Avatar
import com.uct.salary.ui.components.EyeButton
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray50
import com.uct.salary.ui.theme.Gray600
import com.uct.salary.ui.theme.Gray700
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.White

@Composable
fun HomeScreen(vm: AppViewModel) {
    val key = Dates.realKey()
    val st = remember(vm.data, key) { Calc.cycleStats(vm.data.records, vm.data.history, key) }
    val r = Dates.cycleRange(key)
    val pri = primary()
    val pop = remember { Animatable(1f) }
    LaunchedEffect(vm.switchTick) {
        if (vm.switchTick > 0) {
            pop.snapTo(0.5f)
            pop.animateTo(1f, spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessMedium))
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box(Modifier.fillMaxWidth()) {
            AsyncImage(model = vm.data.theme.bg, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.matchParentSize())
            Box(Modifier.matchParentSize().background(Color.Black.copy(alpha = 0.48f)))
            Column(Modifier.statusBarsPadding().padding(horizontal = 20.dp).padding(top = 20.dp, bottom = 128.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("UCT salary", color = White, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                    Avatar(vm.currentUser, 28.dp, Modifier.graphicsLayer { scaleX = pop.value; scaleY = pop.value }
                        .border(1.dp, White.copy(alpha = 0.8f), CircleShape).clickable { vm.userSwitchOpen = true })
                    Spacer(Modifier.width(20.dp))
                    Icon(AppIcons.Settings, "设置", tint = White, modifier = Modifier.size(20.dp).clickable { vm.openSettingsPage(Route.Settings) })
                }
                Spacer(Modifier.height(40.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${Dates.p2(r.startM)}.16 - ${Dates.p2(r.endM)}.15收入", color = White.copy(alpha = 0.9f), fontSize = 14.sp)
                    Spacer(Modifier.width(8.dp))
                    EyeButton(vm.homeEye, { vm.homeEye = !vm.homeEye }, tint = White.copy(alpha = 0.9f), size = 20.dp)
                }
                Spacer(Modifier.height(8.dp))
                Text(if (vm.homeEye) Fmt.money(st.net) else "****.**", color = White, fontSize = 48.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("加班时长 ${if (vm.homeEye) Fmt.hour(st.otHours) else "****"}", color = White.copy(alpha = 0.95f), fontSize = 14.sp)
                    Text("加班收入 ${if (vm.homeEye) Fmt.money(st.otIncome) else "****.**"}", color = White.copy(alpha = 0.95f), fontSize = 14.sp)
                }
            }
        }
        Column(Modifier.padding(horizontal = 16.dp).offset(y = (-96).dp).fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(12.dp)).clip(RoundedCornerShape(12.dp)).background(White).padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                HomeEntry(AppIcons.Calendar, "日历", Modifier.weight(1f)) { vm.openCalendar() }
                HomeEntry(AppIcons.BarChart, "统计", Modifier.weight(1f)) { vm.openStats(0) }
                HomeEntry(AppIcons.Sign, "签到", Modifier.weight(1f)) { /* 原版此项仅展示 */ }
            }
            Spacer(Modifier.height(20.dp))
            Box(Modifier.fillMaxWidth().height(48.dp).shadow(1.dp, RoundedCornerShape(8.dp)).clip(RoundedCornerShape(8.dp)).background(pri).clickable { vm.openNewRecordToday() }, contentAlignment = Alignment.Center) {
                Text("记加班", color = onPrimary(), fontSize = 16.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(16.dp))
            Box(Modifier.fillMaxWidth().height(32.dp)) {
                Row(Modifier.fillMaxSize().horizontalScroll(rememberScrollState()).padding(end = 64.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    when {
                        !vm.data.quick.show -> Text("快捷记录展示已关闭", fontSize = 12.sp, color = Gray400)
                        vm.data.quick.records.isEmpty() -> Text("暂无快捷记录", fontSize = 12.sp, color = Gray400)
                        else -> vm.data.quick.records.forEach { q -> QuickTag(q) { vm.quickRecord(q) } }
                    }
                }
                Row(Modifier.align(Alignment.CenterEnd).background(Brush.horizontalGradient(listOf(Color.Transparent, White, White))).padding(start = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.clip(RoundedCornerShape(6.dp)).background(White).shadow(1.dp, RoundedCornerShape(6.dp)).dashedBorder(pri)
                        .clickable { vm.push(Route.QuickSettings) }.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(AppIcons.Bolt, null, tint = pri, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("设置", fontSize = 12.sp, color = pri)
                    }
                }
            }
        }
        Spacer(Modifier.height(404.dp))
    }
}
@Composable
private fun HomeEntry(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(48.dp), contentAlignment = Alignment.Center) { Icon(icon, null, tint = Gray700, modifier = Modifier.size(28.dp)) }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 14.sp, color = Gray700)
    }
}
@Composable
private fun QuickTag(q: QuickRecord, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(6.dp)).background(White).border(1.dp, Gray200, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(q.name, fontSize = 12.sp, color = Gray600, maxLines = 1)
        Text("•", fontSize = 12.sp, color = Gray400, modifier = Modifier.padding(horizontal = 3.dp))
        Text("${Fmt.hour(q.hours)}h", fontSize = 12.sp, color = Gray600, maxLines = 1)
    }
}

fun Modifier.dashedBorder(color: Color): Modifier = this.drawBehind {
    drawRoundRect(
        color = color,
        cornerRadius = CornerRadius(6.dp.toPx()),
        style = Stroke(width = 1.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
    )
}
