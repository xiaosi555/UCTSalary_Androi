package com.uct.salary.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.uct.salary.core.Calc
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.model.DailyRecord
import com.uct.salary.model.OtSegment
import kotlin.math.abs
import kotlin.math.max

/**
 * 工时记录表单状态与联动规则（FR-REC：R-1 … R-12），逐条对应网页版弹窗的事件处理。
 */
class RecordForm(
    private val vm: AppViewModel,
    val isEdit: Boolean,
    initialDate: String,
    rec: DailyRecord?
) {
    var date by mutableStateOf(initialDate)
    var shiftType by mutableStateOf("夜班")
    var dayNight by mutableStateOf(vm.data.quick.dayNight)
    var baseHours by mutableStateOf("8")
    var otHours by mutableStateOf("3")
    var otRate by mutableStateOf("1.5")
    var splitExpanded by mutableStateOf(false)
    var s1h by mutableStateOf("")
    var s1r by mutableStateOf("1.5")
    var s2h by mutableStateOf("")
    var s2r by mutableStateOf("1.5")
    var remark by mutableStateOf("")
    var selectedUsers by mutableStateOf(vm.users.map { it.id }.toSet())

    val week: String get() = Dates.weekDay(date)

    init {
        if (rec == null) {
            shiftType = "夜班"
            baseHours = resolve()
            otHours = "3"
            otRate = "1.5"
            if (isNightFriday()) otRate = "2.0"
            if (isNightSunday()) otHours = "11"
            applyNightDefaults(false)
            updateRemark()
        } else {
            shiftType = rec.shiftType
            baseHours = resolve()
            otHours = Fmt.hour(Fmt.pfz(rec.otHours))
            otRate = normRate(rec.otRate)
            remark = rec.remark
            dayNight = rec.dayNight.ifEmpty { if (rec.shiftType == "白班" || rec.shiftType == "夜班") rec.shiftType else vm.data.quick.dayNight }
            val segs = rec.otSegments
            if (!segs.isNullOrEmpty()) {
                splitExpanded = true
                s1h = Fmt.jsNum(segs[0].hours); s1r = segRate(segs[0].rate)
                if (segs.size > 1) { s2h = Fmt.jsNum(segs[1].hours); s2r = segRate(segs[1].rate) }
            }
        }
    }

    /* ---------------- 工具 ---------------- */

    private fun resolve(): String = Calc.resolveBaseHours(date, shiftType, vm.data.workdays, vm.data.normalHours)

    private fun isSpecial(t: String) = t == "周末加班" || t == "节假日加班"

    private fun normRate(s: String): String {
        val v = Fmt.pf(s)
        return when (v) {
            1.5 -> "1.5"
            2.0 -> "2.0"
            3.0 -> "3.0"
            else -> if (s.isBlank()) "1.5" else s
        }
    }

    /** 分段倍数下拉只有 1.5 / 2 / 3 三个选项 */
    private fun segRate(v: Double): String = when (v) {
        1.5 -> "1.5"
        2.0 -> "2"
        3.0 -> "3"
        else -> "1.5"
    }

    private fun segRateStr(s: String): String = segRate(Fmt.pfOr(s, 1.5))

    fun isNightFriday() = date.isNotEmpty() && shiftType == "夜班" && week == "周五"
    fun isNightSunday() = date.isNotEmpty() && shiftType == "夜班" && week == "周日"

    private fun fmtHour(d: Double) = Fmt.hour(d)

    private fun presetSunday() {
        otHours = "11"; s1h = "5"; s1r = "2"; s2h = "6"; s2r = "1.5"
    }

    /* ---------------- 夜班特例（R-6） ---------------- */

    fun applyNightDefaults(presetSegments: Boolean) {
        val total = max(0.0, Fmt.pfz(otHours))
        if (isNightFriday()) {
            otRate = "2.0"
            if (splitExpanded && presetSegments && s1h.isBlank() && s2h.isBlank()) {
                s1h = Fmt.jsNum(if (total > 0) total else 3.0); s1r = "2"; s2h = ""; s2r = "1.5"
            }
        } else if (isNightSunday() && presetSegments) {
            if (s1h.isBlank() && s2h.isBlank()) presetSunday()
        }
    }

    /* ---------------- 事件 ---------------- */

    fun onDateChanged(newDate: String) {
        date = newDate
        baseHours = resolve()
        if (isNightFriday()) otRate = "2.0"
        if (isNightSunday()) {
            if (!splitExpanded) otHours = "11"
            else if (s1h.isBlank() && s2h.isBlank()) presetSunday()
        }
        updateRemark()
    }

    fun selectShift(type: String) {
        val prev = shiftType
        shiftType = type
        baseHours = resolve()
        if (type == "休息") otHours = "0"
        else if (isSpecial(type)) { otHours = "11"; otRate = "2.0" }
        else { otHours = "3"; if (isSpecial(prev)) otRate = "1.5" }
        if (isNightFriday()) otRate = "2.0"
        if (isNightSunday()) {
            otHours = "11"
            if (splitExpanded) { s1h = "5"; s1r = "2"; s2h = "6"; s2r = "1.5" }
        } else if (splitExpanded && s1h.isBlank() && s2h.isBlank()) {
            s1h = otHours; s1r = segRateStr(otRate)
        }
        updateRemark()
    }

    fun onOtHoursChanged(text: String) {
        otHours = text
        if (splitExpanded) syncSplitFromTotal()
        updateRemark()
    }

    fun onOtRateChanged(r: String) {
        otRate = r
    }

    private fun syncSplitFromTotal() {
        val total = max(0.0, Fmt.pfz(otHours))
        var first = max(0.0, Fmt.pfz(s1h))
        if (first > total) { first = total; s1h = fmtHour(first) }
        s2h = if (total > first) fmtHour(total - first) else ""
    }

    fun onSplitEdited(f1h: String? = null, f1r: String? = null, f2h: String? = null, f2r: String? = null) {
        f1h?.let { s1h = it }
        f1r?.let { s1r = it }
        f2h?.let { s2h = it }
        f2r?.let { s2r = it }
        val a = max(0.0, Fmt.pfz(s1h))
        val b = max(0.0, Fmt.pfz(s2h))
        otHours = fmtHour(a + b)
        updateRemark()
    }

    fun toggleSplit() {
        splitExpanded = !splitExpanded
        if (splitExpanded && s1h.isBlank() && s2h.isBlank()) {
            val total = max(0.0, Fmt.pfz(otHours))
            if (isNightSunday()) presetSunday()
            else if (isNightFriday()) {
                otRate = "2.0"
                s1h = Fmt.jsNum(if (total > 0) total else 3.0); s1r = "2"; s2h = ""; s2r = "1.5"
            } else {
                s1h = Fmt.jsNum(total); s1r = segRateStr(otRate); s2h = ""; s2r = "1.5"
            }
        }
        updateRemark()
    }

    fun onOtFocus(focused: Boolean) {
        val t = otHours.trim()
        if (focused && (t == "3" || t == "3.0")) otHours = ""
        if (!focused && otHours.isBlank()) { otHours = "3"; if (splitExpanded) syncSplitFromTotal(); updateRemark() }
    }

    fun updateRemark() {
        val ot = Fmt.pf(otHours)
        remark = if (ot.isNaN() || ot <= 0) "未加班"
        else (if (isSpecial(shiftType)) shiftType else "加班") + Fmt.hour(ot) + "小时"
    }

    /* ---------------- 派生 ---------------- */

    /** 有效分段：面板展开、至少一段 > 0、两段之和 = 总工时（容差 1e-6） */
    fun segments(): List<OtSegment>? {
        if (!splitExpanded) return null
        val a = max(0.0, Fmt.pfz(s1h))
        val b = max(0.0, Fmt.pfz(s2h))
        val total = max(0.0, Fmt.pfz(otHours))
        if (!(a > 0 || b > 0)) return null
        if (abs(a + b - total) > 1e-6) return null
        val list = listOf(OtSegment(a, Fmt.pfOr(s1r, 1.5)), OtSegment(b, Fmt.pfOr(s2r, 1.5))).filter { it.hours > 0 }
        return list.ifEmpty { null }
    }

    fun segmentSummary(): String {
        if (!splitExpanded) return "默认按单一倍数计算"
        val a = max(0.0, Fmt.pfz(s1h))
        val b = max(0.0, Fmt.pfz(s2h))
        val parts = ArrayList<String>()
        if (a > 0) parts.add("${Fmt.hour(a)}h×${s1r}倍")
        if (b > 0) parts.add("${Fmt.hour(b)}h×${s2r}倍")
        return if (parts.isEmpty()) "请填写分段工时" else parts.joinToString(" + ")
    }

    fun segmentRemark(segs: List<OtSegment>): String =
        segs.joinToString("，") { "${Fmt.jsNum(it.hours)}h为${Fmt.jsNum(it.rate)}倍" }

    /** 预计薪资（R-8） */
    fun expected(): String {
        val ck = Dates.cycleKeyOfDate(date) ?: Dates.realKey()
        val hs = Calc.settingsAt(vm.data.history, ck).hs
        if (baseHours == "休") return "¥0.00"
        val base = Fmt.pfz(baseHours) * hs
        val segs = segments()
        val ot = if (segs != null) segs.sumOf { it.hours * hs * it.rate } else Fmt.pfz(otHours) * hs * Fmt.pfOr(otRate, 1.5)
        return "¥" + Fmt.money(base + ot)
    }

    /** 构造最终保存的记录（调用前需已通过 vm 的校验） */
    fun build(segs: List<OtSegment>?): DailyRecord = DailyRecord(
        shiftType = shiftType,
        dayNight = if (shiftType == "白班" || shiftType == "夜班") shiftType else dayNight,
        hours = baseHours,
        otHours = otHours,
        otRate = otRate,
        otSegments = segs,
        remark = if (segs != null) segmentRemark(segs) else remark,
        salary = expected()
    )
}
