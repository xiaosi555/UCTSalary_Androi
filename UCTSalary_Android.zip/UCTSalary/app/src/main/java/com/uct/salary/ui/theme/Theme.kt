package com.uct.salary.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color

val Gray50 = Color(0xFFF9FAFB)
val Gray100 = Color(0xFFF3F4F6)
val Gray200 = Color(0xFFE5E7EB)
val Gray300 = Color(0xFFD1D5DB)
val Gray400 = Color(0xFF9CA3AF)
val Gray500 = Color(0xFF6B7280)
val Gray600 = Color(0xFF4B5563)
val Gray700 = Color(0xFF374151)
val Gray800 = Color(0xFF1F2937)
val Gray900 = Color(0xFF111827)
val Orange500 = Color(0xFFF97316)
val Red500 = Color(0xFFEF4444)
val Red50 = Color(0xFFFEF2F2)
val White = Color(0xFFFFFFFF)

const val DEFAULT_PRIMARY_HEX = "#22C065"

val LocalPrimary = compositionLocalOf { Color(0xFF22C065) }

fun parseHex(hex: String): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (e: Exception) {
    Color(0xFF22C065)
}

/** 与网页版一致：亮度 > 170 视为浅色，浅色上的对勾/文字改用深灰 */
fun isLightColor(c: Color): Boolean = (0.299 * c.red * 255 + 0.587 * c.green * 255 + 0.114 * c.blue * 255) > 170

@Composable
fun UctTheme(primaryHex: String, content: @Composable () -> Unit) {
    val primary = parseHex(primaryHex)
    val scheme = lightColorScheme(
        primary = primary,
        onPrimary = if (isLightColor(primary)) Gray800 else White,
        background = Gray50,
        surface = White
    )
    CompositionLocalProvider(LocalPrimary provides primary) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
