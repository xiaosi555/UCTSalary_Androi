package com.uct.salary.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.uct.salary.core.Calc
import com.uct.salary.core.CsvIo
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.core.ImportPlan
import com.uct.salary.core.Section
import com.uct.salary.data.Repository
import com.uct.salary.data.Store
import com.uct.salary.model.DailyRecord
import com.uct.salary.model.DeductionCfg
import com.uct.salary.model.DeductionVisible
import com.uct.salary.model.OtSegment
import com.uct.salary.model.QuickRecord
import com.uct.salary.model.Rates
import com.uct.salary.model.SalaryCfg
import com.uct.salary.model.SettingsVersion
import com.uct.salary.model.SheetItem
import com.uct.salary.model.SubsidyItem
import com.uct.salary.model.SummaryVisible
import com.uct.salary.model.ThemeSettings
import com.uct.salary.model.User
import com.uct.salary.model.UserData
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlin.math.min

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = Store(app)
    private val repo = Repository(store)

    /* ============================ 全局状态 ============================ */

    var users by mutableStateOf(store.loadUsers()); private set
    var currentUserId by mutableStateOf("u1"); private set
    var data by mutableStateOf(UserData()); private set

    val currentUser: User get() = users.firstOrNull { it.id == currentUserId } ?: users.first()

    /** 页面栈、方向 */
    val nav = mutableStateListOf<Route>(Route.Home)
    var navForward by mutableStateOf(true); private set

    /** 日历/统计正在查看的周期键；导入后聚焦的周期 */
    var viewKey by mutableStateOf(Dates.realKey())
    private var importFocusKey: String? = null

    var statsTab by mutableIntStateOf(0)
    var sheetSub by mutableIntStateOf(0)
    var calendarDetail by mutableStateOf(false)
    var homeEye by mutableStateOf(true)

    /** 设置页正在配置的周期；null = 今天所在周期 */
    var cfgTarget by mutableStateOf<String?>(null)
    val cfgKey: String get() = cfgTarget ?: Dates.realKey()

    /* ---- 弹窗状态 ---- */
    var recordForm by mutableStateOf<RecordForm?>(null)
    var confirm by mutableStateOf<ConfirmState?>(null)
    var userSwitchOpen by mutableStateOf(false)
    var exportOpen by mutableStateOf(false)
    var shiftDetailFor by mutableStateOf<String?>(null)

    /* ---- 用户切换动效 ---- */
    var switching by mutableStateOf(false); private set
    var toastUser by mutableStateOf<User?>(null); private set
    var switchTick by mutableIntStateOf(0); private set

    init {
        val saved = store.currentUserId()
        currentUserId = if (users.any { it.id == saved }) saved else users.first().id
        data = repo.loadUserData(currentUserId)
    }

    /* ============================ 提示框 ============================ */

    fun alert(title: String, desc: String) {
        confirm = ConfirmState(title, desc, "知道了", null, false)
    }

    fun ask(title: String, desc: String, confirmText: String, danger: Boolean = false, onOk: () -> Unit) {
        confirm = ConfirmState(title, desc, confirmText, "取消", danger, onOk)
    }

    fun dismissConfirm() { confirm = null }

    /* ============================ 导航 ============================ */

    fun push(r: Route) {
        if (nav.lastOrNull() == r) return
        navForward = true
        nav.add(r)
    }

    fun pop() {
        if (nav.size <= 1) return
        navForward = false
        val left = nav.removeAt(nav.lastIndex)
        when (left) {
            Route.SalarySettings, Route.SubsidySettings, Route.DeductionSettings -> cfgTarget = null
            Route.Stats, Route.Calendar -> if (nav.lastOrNull() == Route.Home) resetViewCycle()
            else -> {}
        }
    }

    fun resetViewCycle() { viewKey = importFocusKey ?: Dates.realKey() }

    fun openCalendar() { resetViewCycle(); push(Route.Calendar) }

    fun openStats(tab: Int = 0, keepCycle: Boolean = false) {
        if (!keepCycle) resetViewCycle()
        statsTab = tab
        push(Route.Stats)
    }

    fun openSettingsPage(r: Route) { cfgTarget = null; push(r) }

    /** 统计页 → 设置页：配置周期取当前所看周期（NAV-4） */
    fun jumpSettings(r: Route) { cfgTarget = viewKey; push(r) }

    fun shiftCfg(delta: Int) { cfgTarget = Dates.shiftKey(cfgKey, delta) }

    /* ============================ 工时记录 ============================ */

    fun openRecord(date: String) {
        val rec = data.records[date]
        recordForm = RecordForm(this, rec != null, date, rec)
    }

    fun openNewRecordToday() {
        recordForm = RecordForm(this, false, Dates.iso(Dates.today()), null)
    }

    fun closeRecord() { recordForm = null }

    fun saveRecord() {
        val f = recordForm ?: return
        if (f.date.isEmpty()) { alert("提示", "请选择日期"); return }
        val segs = f.segments()
        if (f.splitExpanded && segs == null && Fmt.pfz(f.otHours) > 0) {
            alert("无法保存", "展开分段后，请填写分段工时，并确保分段工时合计等于原加班工时。")
            return
        }
        val rec = f.build(segs)
        val ids = if (f.selectedUsers.isEmpty()) setOf(currentUserId) else f.selectedUsers
        for (id in ids) {
            if (id == currentUserId) {
                val m = data.records.toMutableMap(); m[f.date] = rec
                data = data.copy(records = m); repo.saveRecords(id, m)
            } else {
                val m = repo.loadRecordsOf(id).toMutableMap(); m[f.date] = rec
                repo.saveRecords(id, m)
            }
        }
        recordForm = null
    }

    /** 点击“删除”：先关闭编辑弹窗，再弹出确认框（R-10） */
    fun requestDelete() {
        val date = recordForm?.date ?: return
        recordForm = null
        ask("确认删除", "确定要删除该日期的工时记录吗？删除后无法恢复。", "删除", danger = true) {
            val m = data.records.toMutableMap(); m.remove(date)
            data = data.copy(records = m); repo.saveRecords(currentUserId, m)
        }
    }

    /** 快捷标签：记录今天（Q-2 … Q-4） */
    fun quickRecord(q: QuickRecord) {
        val date = Dates.iso(Dates.today())
        if (data.records.containsKey(date)) {
            ask("当天已有工时记录", "$date 已存在记录。是否用【${q.name}】覆盖当天原有工时数据？", "覆盖记录", danger = true) { performQuickSave(q, date) }
        } else performQuickSave(q, date)
    }

    private fun performQuickSave(q: QuickRecord, date: String) {
        val inferred = q.shiftType ?: if (q.name.contains("周末")) "周末加班" else if (q.type == "blue") "夜班" else "白班"
        val otH = Math.max(0.0, q.hours)
        val isNight = inferred == "夜班" || (inferred != "白班" && q.type == "blue")
        val week = Dates.weekDay(date)
        var rate = Fmt.jsNum(if (q.rate == 0.0) 1.5 else q.rate)
        var segs: List<OtSegment>? = null
        if (isNight && week == "周五") rate = "2.0"
        if (isNight && week == "周日" && otH > 0) {
            val first = min(5.0, otH)
            val rest = Math.max(0.0, otH - first)
            segs = if (rest > 0) listOf(OtSegment(first, 2.0), OtSegment(rest, 1.5)) else listOf(OtSegment(first, 2.0))
        }
        val remark = segs?.joinToString("，") { "${Fmt.jsNum(it.hours)}h为${Fmt.jsNum(it.rate)}倍" } ?: "加班${Fmt.jsNum(otH)}小时"
        var rec = DailyRecord(
            shiftType = inferred,
            dayNight = if (isNight) "夜班" else if (inferred == "白班") "白班" else data.quick.dayNight,
            hours = Calc.resolveBaseHours(date, inferred, data.workdays, data.normalHours),
            otHours = Fmt.jsNum(otH),
            otRate = rate,
            otSegments = segs,
            remark = remark,
            salary = "¥0.00"
        )
        rec = rec.copy(salary = "¥" + Fmt.money(Calc.recPayAt(data.history, date, rec).total))
        val m = data.records.toMutableMap(); m[date] = rec
        data = data.copy(records = m); repo.saveRecords(currentUserId, m)
        alert("记录成功", "已将【${q.name}】记录到 $date，工时及工资已更新。")
    }

    /* ============================ 按周期配置（P-1 … P-5） ============================ */

    private fun mutateVersion(key: String, f: (SettingsVersion) -> SettingsVersion) {
        val list = Calc.upsertVersion(data.history, key, f)
        data = data.copy(history = list)
        repo.saveHistory(currentUserId, list)
    }

    fun saveSalary(cfg: SalaryCfg) = mutateVersion(cfgKey) { it.copy(salary = cfg) }

    fun saveDeduction(cfg: DeductionCfg) {
        val list = Calc.upsertVersion(data.history, cfgKey) { it.copy(deduction = cfg) }
        val currentRates = cfg.rates ?: Calc.ratesAt(data.history, cfgKey)
        val synced = list.map { it.copy(deduction = it.deduction.copy(rates = currentRates)) }
        data = data.copy(history = synced)
        repo.saveHistory(currentUserId, synced)
    }

    fun saveSubsidy(list: List<SubsidyItem>) = mutateVersion(cfgKey) { it.copy(subsidy = list) }

    fun confirmCycleIndex(idx: Int) {
        data = data.copy(cycleIndex = idx)
        repo.saveCycleIndex(currentUserId, idx)
        mutateVersion(Dates.realKey()) { it.copy(cycle = idx) }
    }

    fun setWorkdays(days: List<String>) {
        data = data.copy(workdays = days); repo.saveWorkdays(currentUserId, days)
    }

    fun setNormalHours(h: Int) {
        data = data.copy(normalHours = h); repo.saveNormalHours(currentUserId, h)
    }

    /* ============================ 其他设置 ============================ */

    fun setQuickShow(v: Boolean) { data = data.copy(quick = data.quick.copy(show = v)); repo.saveQuick(currentUserId, data.quick) }
    fun setDefaultDayNight(v: String) { data = data.copy(quick = data.quick.copy(dayNight = v)); repo.saveQuick(currentUserId, data.quick) }
    fun setQuickRecords(list: List<QuickRecord>) { data = data.copy(quick = data.quick.copy(records = list)); repo.saveQuick(currentUserId, data.quick) }

    fun setSheetItems(list: List<SheetItem>) { data = data.copy(sheetItems = list); repo.saveSheet(currentUserId, list) }

    fun setTheme(t: ThemeSettings) { data = data.copy(theme = t); repo.saveTheme(currentUserId, t) }

    fun setSummaryVisible(v: SummaryVisible) { data = data.copy(summaryVisible = v); repo.saveSummaryVisible(currentUserId, v) }

    fun setDeductionVisible(v: DeductionVisible) { data = data.copy(deductionVisible = v); repo.saveDeductionVisible(currentUserId, v) }

    /* ============================ 用户 ============================ */

    fun saveUser(user: User, makeCurrent: Boolean) {
        val exists = users.any { it.id == user.id }
        users = if (exists) users.map { if (it.id == user.id) user else it } else users + user
        repo.saveUsers(users)
        if (makeCurrent && user.id != currentUserId) switchUser(user.id)
    }

    fun deleteUser(id: String) {
        if (users.size <= 1) return
        users = users.filter { it.id != id }
        repo.saveUsers(users)
        repo.deleteUserData(id)
        if (id == currentUserId) switchUser(users.first().id)
    }

    /** 原地切换（不重启）：当前页淡出 → 换数据 → 新用户首页滑入 + 头像弹跳 + 顶部提示（U-7） */
    fun switchUser(id: String) {
        userSwitchOpen = false
        if (switching || id == currentUserId) return
        val u = users.firstOrNull { it.id == id } ?: return
        switching = true
        viewModelScope.launch {
            delay(160)
            store.setCurrentUserId(id)
            currentUserId = id
            data = repo.loadUserData(id)
            nav.clear(); nav.add(Route.Home); navForward = true
            importFocusKey = null; viewKey = Dates.realKey(); cfgTarget = null
            recordForm = null; statsTab = 0; sheetSub = 0; calendarDetail = false; homeEye = true
            switchTick++
            toastUser = u
            switching = false
            delay(1700)
            if (toastUser?.id == u.id) toastUser = null
        }
    }

    /* ============================ 导入 / 导出 ============================ */

    fun exportSections(): List<Section> =
        CsvIo.collectSections(currentUser, data, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy/M/d HH:mm:ss")))

    fun exportCsv(): String = CsvIo.buildCsv(exportSections())

    fun exportFileName(): String =
        "工资APP备份_${currentUser.name.replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_")}_${LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmm"))}.csv"

    /** 读取并解析 CSV 文本，弹出确认框；确认后写入当前用户并刷新 */
    fun importText(text: String) {
        val plan: ImportPlan = try {
            CsvIo.buildPlan(text, data)
        } catch (e: Exception) {
            alert("导入失败", "文件解析出错，请使用本应用导出的 CSV 文件。"); return
        }
        if (!plan.hasAny) {
            alert("导入失败", if (plan.recordRowTotal > 0) "未识别到有效数据（共 ${plan.recordRowTotal} 行）。请确认含“日期”列且日期格式为 2026-10-01。" else "文件内容为空或格式不正确。")
            return
        }
        ask("确认导入", CsvIo.planSummary(plan, data, currentUser), "确认导入", danger = true) { applyImport(plan) }
    }

    private fun applyImport(plan: ImportPlan) {
        try {
            val newData = CsvIo.applyPlan(plan, data)
            repo.saveAll(currentUserId, newData)
            data = newData
            val latest = plan.records.maxByOrNull { it.first }?.first
            importFocusKey = latest?.let { Dates.cycleKeyOfDate(it) }
            resetViewCycle()
            exportOpen = false
            alert("导入完成", "数据已导入并同步到日历、统计、工资条和设置。" + if (plan.skippedTotal > 0) "\n已跳过 ${plan.skippedTotal} 行无法识别的数据。" else "")
        } catch (e: Exception) {
            alert("导入失败", "写入数据时出错：${e.message ?: e}")
        }
    }
}
