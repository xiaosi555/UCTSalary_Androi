package com.uct.salary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uct.salary.model.User
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.components.AppDialog
import com.uct.salary.ui.components.Avatar
import com.uct.salary.ui.screens.CalendarScreen
import com.uct.salary.ui.screens.CycleSettingsScreen
import com.uct.salary.ui.screens.DeductionSettingsScreen
import com.uct.salary.ui.screens.ExportDialog
import com.uct.salary.ui.screens.HomeScreen
import com.uct.salary.ui.screens.QuickSettingsScreen
import com.uct.salary.ui.screens.RecordSheet
import com.uct.salary.ui.screens.SalaryDetailScreen
import com.uct.salary.ui.screens.SalarySettingsScreen
import com.uct.salary.ui.screens.SettingsHomeScreen
import com.uct.salary.ui.screens.SheetManageScreen
import com.uct.salary.ui.screens.ShiftDetailDialog
import com.uct.salary.ui.screens.StatsScreen
import com.uct.salary.ui.screens.SubsidySettingsScreen
import com.uct.salary.ui.screens.ThemeSettingsScreen
import com.uct.salary.ui.screens.UserEditScreen
import com.uct.salary.ui.screens.UserManageScreen
import com.uct.salary.ui.screens.UserSwitchDialog
import com.uct.salary.ui.screens.WorkdaySettingsScreen
import com.uct.salary.ui.theme.Gray50
import com.uct.salary.ui.theme.White
import com.uct.salary.ui.theme.UctTheme

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            UctTheme(vm.data.theme.color) { AppRoot(vm) }
        }
    }
}

@Composable
fun AppRoot(vm: AppViewModel) {
    val route = vm.nav.lastOrNull() ?: Route.Home

    val anyOverlay = vm.confirm != null || vm.recordForm != null || vm.userSwitchOpen || vm.exportOpen || vm.shiftDetailFor != null
    BackHandler(enabled = anyOverlay || vm.nav.size > 1) {
        val c = vm.confirm
        when {
            c != null -> vm.dismissConfirm()
            vm.recordForm != null -> vm.closeRecord()
            vm.shiftDetailFor != null -> vm.shiftDetailFor = null
            vm.exportOpen -> vm.exportOpen = false
            vm.userSwitchOpen -> vm.userSwitchOpen = false
            else -> vm.pop()
        }
    }

    // 用户切换动效：旧页面左滑淡出 → 换数据 → 新首页自右滑入
    val alphaA = remember { Animatable(1f) }
    val txA = remember { Animatable(0f) }
    LaunchedEffect(vm.switching) {
        if (vm.switching) {
            alphaA.animateTo(0f, tween(150, easing = FastOutSlowInEasing))
        }
    }
    LaunchedEffect(vm.switching) {
        if (vm.switching) txA.animateTo(-18f, tween(150, easing = FastOutSlowInEasing))
    }
    LaunchedEffect(vm.switchTick) {
        if (vm.switchTick > 0) {
            alphaA.snapTo(0f); txA.snapTo(22f)
            alphaA.animateTo(1f, tween(300, easing = FastOutSlowInEasing))
        }
    }
    LaunchedEffect(vm.switchTick) {
        if (vm.switchTick > 0) txA.animateTo(0f, tween(300, easing = FastOutSlowInEasing))
    }
    val density = LocalDensity.current

    Box(Modifier.fillMaxSize().background(Gray50)) {
        Box(
            Modifier.fillMaxSize().graphicsLayer {
                alpha = alphaA.value
                translationX = txA.value * density.density
            }
        ) {
            AnimatedContent(
                targetState = route,
                transitionSpec = {
                    if (vm.navForward) {
                        (slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 4 } + fadeIn(tween(280))) togetherWith
                                (slideOutHorizontally(tween(280, easing = FastOutSlowInEasing)) { -it / 8 } + fadeOut(tween(200)))
                    } else {
                        (slideInHorizontally(tween(280, easing = FastOutSlowInEasing)) { -it / 4 } + fadeIn(tween(280))) togetherWith
                                (slideOutHorizontally(tween(280, easing = FastOutSlowInEasing)) { it / 4 } + fadeOut(tween(200)))
                    }
                },
                label = "nav"
            ) { r -> RouteContent(r, vm) }
        }

        DialogHost(vm)
        SwitchToast(vm)
    }
}

@Composable
fun RouteContent(r: Route, vm: AppViewModel) {
    Box(Modifier.fillMaxSize().background(Gray50)) {
        when (r) {
            Route.Home -> HomeScreen(vm)
            Route.Calendar -> CalendarScreen(vm)
            Route.Stats -> StatsScreen(vm)
            Route.Settings -> SettingsHomeScreen(vm)
            Route.SalaryDetail -> SalaryDetailScreen(vm)
            Route.SalarySettings -> SalarySettingsScreen(vm)
            Route.SubsidySettings -> SubsidySettingsScreen(vm)
            Route.DeductionSettings -> DeductionSettingsScreen(vm)
            Route.CycleSettings -> CycleSettingsScreen(vm)
            Route.WorkdaySettings -> WorkdaySettingsScreen(vm)
            Route.QuickSettings -> QuickSettingsScreen(vm)
            Route.ThemeSettings -> ThemeSettingsScreen(vm)
            Route.UserManage -> UserManageScreen(vm)
            is Route.UserEdit -> UserEditScreen(vm, r.userId)
            Route.SheetManage -> SheetManageScreen(vm)
        }
    }
}

@Composable
fun DialogHost(vm: AppViewModel) {
    vm.confirm?.let { c ->
        AppDialog(
            title = c.title, desc = c.desc, confirmText = c.confirmText, cancelText = c.cancelText, danger = c.danger,
            onConfirm = { vm.dismissConfirm(); c.onConfirm() },
            onCancel = { vm.dismissConfirm() }
        )
    }
    vm.recordForm?.let { RecordSheet(vm, it) }
    if (vm.userSwitchOpen) UserSwitchDialog(vm)
    if (vm.exportOpen) ExportDialog(vm)
    vm.shiftDetailFor?.let { ShiftDetailDialog(vm, it) }
}

/** 顶部“已切换到「昵称」”提示 */
@Composable
fun SwitchToast(vm: AppViewModel) {
    var shown by remember { mutableStateOf<User?>(null) }
    LaunchedEffect(vm.toastUser) { vm.toastUser?.let { shown = it } }
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 8.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = vm.toastUser != null,
            enter = fadeIn(tween(220)) + slideInVertically(tween(260)) { -it },
            exit = fadeOut(tween(220)) + slideOutVertically(tween(220)) { -it / 2 }
        ) {
            shown?.let { u ->
                Row(
                    Modifier.clip(RoundedCornerShape(50)).background(com.uct.salary.ui.theme.Gray900.copy(alpha = 0.92f)).padding(start = 6.dp, end = 16.dp, top = 6.dp, bottom = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(u, 28.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("已切换到「${u.name}」", color = White, fontSize = 14.sp)
                }
            }
        }
    }
}
