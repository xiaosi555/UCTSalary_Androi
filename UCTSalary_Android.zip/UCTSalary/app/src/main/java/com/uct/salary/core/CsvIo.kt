package com.uct.salary.core

import com.uct.salary.model.CYCLE_LIST
import com.uct.salary.model.DailyRecord
import com.uct.salary.model.DeductionCfg
import com.uct.salary.model.OtSegment
import com.uct.salary.model.QuickRecord
import com.uct.salary.model.QuickSettings
import com.uct.salary.model.Rates
import com.uct.salary.model.SHIFT_TYPES_VALID
import com.uct.salary.model.SalaryCfg
import com.uct.salary.model.SettingsVersion
import com.uct.salary.model.SheetItem
import com.uct.salary.model.SubsidyItem
import com.uct.salary.model.THEME_BGS
import com.uct.salary.model.THEME_COLORS
import com.uct.salary.model.User
import com.uct.salary.model.UserData
import com.uct.salary.model.WEEK_DAYS
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import java.time.LocalDate

/** 逻辑分段（只在内存里使用；最终写成「一个文件、一行表头」的单表） */
data class Section(val name: String, val headers: List<String>, val rows: List<List<String>>)

data class OtherSettings(
    val cycleIndex: Int? = null,
    val workdays: List<String>? = null,
    val normalHours: Int? = null,
    val dayNight: String? = null,
    val showQuick: Boolean? = null,
    val summary: Map<String, Boolean>? = null,
    val deductionVisible: Map<String, Boolean>? = null,
    val themeBg: String? = null,
    val themeColor: String? = null
) {
    fun count(): Int = listOfNotNull(
        cycleIndex, workdays, normalHours, dayNight, showQuick, summary, deductionVisible, themeBg, themeColor
    ).size
}

class ImportPlan(
    val legacy: Boolean,
    val meta: Map<String, String>,
    val records: List<Pair<String, DailyRecord>>,
    val skippedRecords: Int,
    val recordRowTotal: Int,
    val history: List<SettingsVersion>?,
    val subsidyCycles: Int,
    val subsidyCount: Int,
    val quick: List<QuickRecord>?,
    val sheet: List<SheetItem>?,
    val other: OtherSettings,
    val skippedOther: Int
) {
    val hasAny: Boolean
        get() = records.isNotEmpty() || history != null || quick != null || sheet != null || other.count() > 0
    val skippedTotal: Int get() = skippedRecords + skippedOther
}

object CsvIo {

    /* ============================ 列定义 ============================ */

    val RATE_COLS = listOf(
        "养老单位%", "养老个人%", "医疗单位%", "医疗个人%", "失业单位%",
        "失业个人%", "工伤单位%", "工伤个人%", "生育单位%", "生育个人%"
    )

    val REC_HEADERS = listOf("日期", "星期", "班次", "日夜班", "基础工时", "加班小时", "加班倍数", "备注", "当日工资", "分段倍数")

    private fun same(vararg names: String): List<Pair<String, String>> = names.map { it to it }

    val FLAT_ORDER = listOf("元信息", "其他设置", "周期设置", "周期补贴", "快捷记录", "明细项", "周期汇总", "工时记录")

    /** 逻辑表头 → 单表列名 */
    val FLAT_MAP: Map<String, List<Pair<String, String>>> = mapOf(
        "元信息" to listOf("项目" to "名称", "值" to "值"),
        "其他设置" to listOf("项目" to "名称", "值" to "值"),
        "周期设置" to (listOf("生效周期" to "周期/日期") +
                same("周期范围", "月基本工资", "小时工资", "平时加班倍数", "周末加班倍数", "节假日加班倍数", "社保基数") +
                same(*RATE_COLS.toTypedArray()) +
                same("公积金基数", "公积金比例%", "个税(月)", "考勤周期", "个人五险合计(自动计算)", "单位五险合计(自动计算)", "公积金个人(自动计算)")),
        "周期补贴" to listOf(
            "生效周期" to "周期/日期", "序号" to "序号", "补贴名称" to "名称", "金额" to "金额",
            "计算方式" to "计算方式", "补贴天数" to "天数", "启用" to "启用/显示"
        ),
        "快捷记录" to listOf("名称" to "名称", "类型" to "标识/类型", "加班小时" to "加班小时", "加班倍数" to "加班倍数"),
        "明细项" to listOf("顺序" to "序号", "标识" to "标识/类型", "名称" to "名称", "显示" to "启用/显示"),
        "周期汇总" to (listOf("周期" to "周期/日期", "周期范围" to "周期范围") +
                same("记录天数", "平时加班小时", "双休加班小时", "基本工资", "加班工资", "补贴合计", "个人五险", "公积金", "个税(月)", "实发工资")),
        "工时记录" to (listOf("日期" to "周期/日期") +
                same("星期", "班次", "日夜班", "基础工时", "加班小时", "加班倍数", "备注", "当日工资", "分段倍数"))
    )

    val FLAT_COLS: List<String> = run {
        val cols = arrayListOf(
            "类型", "周期/日期", "周期范围", "序号", "名称", "值", "标识/类型", "星期", "班次", "日夜班",
            "基础工时", "加班小时", "加班倍数", "备注", "当日工资", "金额", "计算方式", "天数", "启用/显示", "分段倍数"
        )
        FLAT_ORDER.forEach { n -> FLAT_MAP.getValue(n).forEach { p -> if (!cols.contains(p.second)) cols.add(p.second) } }
        cols
    }

    private val ALIASES = mapOf(
        "date" to listOf("日期", "date", "时间"),
        "shiftType" to listOf("班次", "班次类型", "shifttype", "shift"),
        "dayNight" to listOf("日夜班", "白夜班", "daynight"),
        "hours" to listOf("基础工时", "工时", "基本工时", "正常工时", "hours"),
        "otHours" to listOf("加班小时", "加班时长", "加班工时", "加班", "othours"),
        "otRate" to listOf("加班倍数", "倍数", "加班倍率", "otrate", "rate"),
        "otSegments" to listOf("分段倍数", "加班分段", "otsegments"),
        "remark" to listOf("备注", "remark", "说明"),
        "salary" to listOf("当日工资", "工资", "日薪", "合计", "salary")
    )

    /* ============================ 基础解析 ============================ */

    private val DATE_RE = Regex("""^(\d{4})\s*[-/.年]\s*(\d{1,2})\s*[-/.月]\s*(\d{1,2})\s*日?""")
    private val DATE8_RE = Regex("""^(\d{4})(\d{2})(\d{2})$""")

    fun normDate(raw: String?): String? {
        val s = (raw ?: "").trim()
        if (s.isEmpty()) return null
        val m = DATE_RE.find(s) ?: DATE8_RE.find(s) ?: return null
        return try {
            LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()).toString()
        } catch (e: Exception) {
            null
        }
    }

    fun parseCsv(input: String): List<List<String>> {
        val text = input.removePrefix("\uFEFF")
        val delim = detectDelimiter(text)
        val rows = ArrayList<List<String>>()
        var row = ArrayList<String>()
        val cell = StringBuilder()
        var inQ = false
        var i = 0
        while (i < text.length) {
            val ch = text[i]
            if (inQ) {
                if (ch == '"') {
                    if (i + 1 < text.length && text[i + 1] == '"') { cell.append('"'); i++ } else inQ = false
                } else cell.append(ch)
            } else if (ch == '"' && cell.isEmpty()) {
                inQ = true
            } else if (ch == delim) {
                row.add(cell.toString()); cell.setLength(0)
            } else if (ch == '\n' || ch == '\r') {
                if (ch == '\r' && i + 1 < text.length && text[i + 1] == '\n') i++
                row.add(cell.toString()); cell.setLength(0)
                rows.add(row); row = ArrayList()
            } else cell.append(ch)
            i++
        }
        if (cell.isNotEmpty() || row.isNotEmpty()) { row.add(cell.toString()); rows.add(row) }
        return rows.filter { r -> r.any { it.trim().isNotEmpty() } }
    }

    private fun detectDelimiter(text: String): Char {
        if (text.startsWith("#工资APP")) return ','
        val first = text.split(Regex("\r?\n")).firstOrNull { it.trim().isNotEmpty() } ?: ""
        var best = ','
        var bestN = -1
        for (c in listOf(',', '\t', ';', '，')) {
            val n = first.count { it == c }
            if (n > bestN) { bestN = n; best = c }
        }
        return best
    }

    fun esc(v: String): String =
        if (v.any { it == '"' || it == ',' || it == '\r' || it == '\n' }) "\"" + v.replace("\"", "\"\"") + "\"" else v

    /** JS 版 numStr：去掉 % ¥ 逗号空白后必须是纯数字，否则取默认值（保留原文本，如 "2.0"） */
    private val NUM_RE = Regex("""^-?\d+(\.\d+)?$""")
    fun numStr(v: String?, def: String): String {
        val t = (v ?: "").trim().replace(Regex("[%¥￥,\\s]"), "")
        return if (NUM_RE.matches(t)) t else def
    }

    private fun yes(v: String?): Boolean =
        Regex("^(是|true|1|启用|开|显示|y|yes)$", RegexOption.IGNORE_CASE).matches((v ?: "").trim())

    fun keyText(key: String) = if (key == "000000") "起始" else key

    fun keyRange(key: String): String {
        if (key == "000000") return "最早（起始版本）"
        val r = Dates.cycleRange(key)
        return "${r.startY}.${Dates.p2(r.startM)}.16-${r.endY}.${Dates.p2(r.endM)}.15"
    }

    private val KEY_RE = Regex("""^(\d{4})\s*[-/.年]?\s*(\d{1,2})\s*月?$""")
    fun parseKey(s: String?): String? {
        val t = (s ?: "").trim()
        if (t.isEmpty()) return null
        if (Regex("^(起始|最早|0+)$").matches(t)) return "000000"
        val m = KEY_RE.find(t) ?: return null
        val mo = m.groupValues[2].toInt()
        if (mo < 1 || mo > 12) return null
        return (m.groupValues[1].toInt() * 100 + mo).toString()
    }

    /* ============================ 导出 ============================ */

    private fun segJson(segs: List<OtSegment>?): String =
        if (segs.isNullOrEmpty()) "[]"
        else segs.joinToString(",", "[", "]") { "{\"hours\":${Fmt.jsNum(it.hours)},\"rate\":${Fmt.jsNum(it.rate)}}" }

    private fun yn(b: Boolean) = if (b) "是" else "否"

    fun collectSections(user: User, data: UserData, nowText: String): List<Section> {
        val hist = Calc.sorted(data.history)
        val dkeys = data.records.keys.filter { normDate(it) != null }.sorted()

        val recRows = dkeys.map { k ->
            val rec = data.records.getValue(k)
            val pay = Calc.recPayAt(data.history, k, rec)
            listOf(
                k, Dates.weekDay(k), rec.shiftType, rec.dayNight, rec.hours, rec.otHours.ifEmpty { "0" }, rec.otRate,
                rec.remark, Fmt.fixed2(pay.total), segJson(rec.otSegments)
            )
        }

        val cycHeaders = listOf("生效周期", "周期范围", "月基本工资", "小时工资", "平时加班倍数", "周末加班倍数", "节假日加班倍数", "社保基数") +
                RATE_COLS + listOf("公积金基数", "公积金比例%", "个税(月)", "考勤周期", "个人五险合计(自动计算)", "单位五险合计(自动计算)", "公积金个人(自动计算)")
        val cycRows = hist.map { h ->
            val sal = h.salary
            val ded = h.deduction
            val rates = Calc.ratesAt(data.history, h.from)
            val sb = Fmt.pfz(ded.socialBase)
            val ps = rates.personalList().sumOf { Fmt.pfz(it) }
            val us = rates.unitList().sumOf { Fmt.pfz(it) }
            listOf(
                keyText(h.from), keyRange(h.from), sal.baseSalary,
                if (sal.hourSalaryExact.isNotBlank()) sal.hourSalaryExact else sal.hourSalary,
                sal.rate1, sal.rate2, sal.rate3, ded.socialBase
            ) + rates.csvOrder() + listOf(
                ded.housingBase, ded.housingRate, ded.incomeTax, h.cycle.toString(),
                Fmt.fixed2(sb * ps / 100), Fmt.fixed2(sb * us / 100),
                Fmt.fixed2(Fmt.pfz(ded.housingBase) * Fmt.pfz(ded.housingRate) / 100)
            )
        }

        val subRows = ArrayList<List<String>>()
        hist.forEach { h ->
            Calc.subsidyAt(data.history, h.from).forEachIndexed { i, it ->
                subRows.add(listOf(keyText(h.from), (i + 1).toString(), it.name, Fmt.jsNum(it.amount),
                    if (it.mode == "daily") "按日" else "按月", it.days.toString(), yn(it.enabled)))
            }
        }

        val quickRows = data.quick.records.map { listOf(it.name, it.type, Fmt.jsNum(it.hours), Fmt.jsNum(it.rate)) }
        val sheetRows = data.sheetItems.mapIndexed { i, it -> listOf((i + 1).toString(), it.key, it.label, yn(it.enabled)) }

        val otherRows = listOf(
            listOf("考勤周期", data.cycleIndex.toString()),
            listOf("考勤周期说明(自动)", CYCLE_LIST.getOrElse(data.cycleIndex) { "" }),
            listOf("工作日", data.workdays.joinToString("|")),
            listOf("正常工时", data.normalHours.toString()),
            listOf("默认白夜班", data.quick.dayNight),
            listOf("首页展示快捷记录", yn(data.quick.show)),
            listOf("汇总显示-夜班补贴", yn(data.summaryVisible.night)),
            listOf("汇总显示-伙食补贴", yn(data.summaryVisible.meal)),
            listOf("汇总显示-应纳税所得额", yn(data.summaryVisible.taxable)),
            listOf("汇总显示-个人五险", yn(data.summaryVisible.social)),
            listOf("统计显示-五险", yn(data.deductionVisible.social)),
            listOf("统计显示-公积金", yn(data.deductionVisible.housing)),
            listOf("统计显示-个税", yn(data.deductionVisible.tax)),
            listOf("主题背景", data.theme.bg),
            listOf("主题色", data.theme.color)
        )

        val metaRows = listOf(
            listOf("应用", "工资APP"), listOf("格式版本", "2"), listOf("导出时间", nowText),
            listOf("用户ID", user.id), listOf("用户名", user.name), listOf("性别", user.gender),
            listOf("手机", user.phone), listOf("备注", user.remark),
            listOf("工时记录数", recRows.size.toString()), listOf("周期设置数", cycRows.size.toString()),
            listOf("周期补贴项数", subRows.size.toString())
        )

        return listOf(
            Section("元信息", listOf("项目", "值"), metaRows),
            Section("工时记录", REC_HEADERS, recRows),
            Section("周期设置", cycHeaders, cycRows),
            Section("周期补贴", listOf("生效周期", "序号", "补贴名称", "金额", "计算方式", "补贴天数", "启用"), subRows),
            Section("快捷记录", listOf("名称", "类型", "加班小时", "加班倍数"), quickRows),
            Section("明细项", listOf("顺序", "标识", "名称", "显示"), sheetRows),
            Section("其他设置", listOf("项目", "值"), otherRows),
            Section(
                "周期汇总",
                listOf("周期", "周期范围", "记录天数", "平时加班小时", "双休加班小时", "基本工资", "加班工资", "补贴合计", "个人五险", "公积金", "个税(月)", "实发工资"),
                cycleSummaryRows(data)
            )
        )
    }

    private fun cycleSummaryRows(data: UserData): List<List<String>> {
        val keys = data.records.keys.mapNotNull { Dates.cycleKeyOfDate(it) }.distinct().sorted()
        return keys.map { ck ->
            val cfg = Calc.settingsAt(data.history, ck)
            val ks = Calc.recordKeysInCycle(data.records, ck)
            var ot = 0.0
            var nOt = 0.0
            var dOt = 0.0
            for (k in ks) {
                val rec = data.records.getValue(k)
                ot += Calc.recPay(rec, cfg.hs).ot
                val h = Fmt.pfz(rec.otHours)
                for (p in Calc.segmentsOf(rec, h, 1.5)) {
                    if (p.hours > 0) { if (p.rate >= 1.9) dOt += p.hours else nOt += p.hours }
                }
            }
            var sub = 0.0
            Calc.subsidyAt(data.history, ck).forEach { sub += Calc.subsidyValue(it, ck) }
            val net = cfg.base + ot + sub - cfg.social - cfg.housing - cfg.tax
            listOf(
                ck, keyRange(ck), ks.size.toString(), Fmt.hour(nOt), Fmt.hour(dOt), Fmt.fixed2(cfg.base), Fmt.fixed2(ot),
                Fmt.fixed2(sub), Fmt.fixed2(cfg.social), Fmt.fixed2(cfg.housing), Fmt.fixed2(cfg.tax), Fmt.fixed2(net)
            )
        }
    }

    fun toFlat(sections: List<Section>): List<List<String>> {
        val by = sections.associateBy { it.name }
        val rows = ArrayList<List<String>>()
        for (name in FLAT_ORDER) {
            val s = by[name] ?: continue
            val hidx = HashMap<String, Int>()
            s.headers.forEachIndexed { i, h -> hidx[h] = i }
            for (r in s.rows) {
                val o = HashMap<String, String>()
                o["类型"] = name
                for ((old, flat) in FLAT_MAP.getValue(name)) o[flat] = r.getOrElse(hidx[old] ?: -1) { "" }
                rows.add(FLAT_COLS.map { o[it] ?: "" })
            }
        }
        return rows
    }

    /** 一个文件、一行表头、52 列 */
    fun buildCsv(sections: List<Section>): String {
        val sb = StringBuilder()
        sb.append(FLAT_COLS.joinToString(",") { esc(it) })
        for (r in toFlat(sections)) { sb.append("\r\n"); sb.append(r.joinToString(",") { esc(it) }) }
        return sb.toString()
    }

    /* ============================ 导入 ============================ */

    private class Sec(val rows: MutableList<List<String>>)

    private val LEGACY_SEC_NAMES = listOf("元信息", "工时记录", "周期设置", "周期补贴", "快捷记录", "明细项", "其他设置", "周期汇总")

    /** 旧版「#工资APP数据导出 + #章节」分段格式 */
    private fun splitSections(rows: List<List<String>>): Map<String, Sec>? {
        val first = rows.firstOrNull()?.firstOrNull()?.trim() ?: ""
        if (!first.startsWith("#工资APP")) return null
        val secs = LinkedHashMap<String, Sec>()
        var cur: Sec? = null
        for (r in rows) {
            val c0 = r.firstOrNull()?.trim() ?: ""
            val rest = r.drop(1).all { it.trim().isEmpty() }
            if (c0.startsWith("#") && rest) {
                val name = c0.substring(1)
                if (name == "工资APP数据导出") { cur = null; continue }
                if (LEGACY_SEC_NAMES.contains(name)) { cur = Sec(ArrayList()); secs[name] = cur; continue }
            }
            cur?.rows?.add(r)
        }
        return secs
    }

    /** 单表格式：按「类型」列还原为逻辑分段 */
    private fun flatToSections(rows: List<List<String>>): Map<String, Sec>? {
        if (rows.isEmpty()) return null
        val head = rows[0].map { it.trim() }
        if (head.firstOrNull() != "类型" || !head.contains("周期/日期")) return null
        val idx = HashMap<String, Int>()
        head.forEachIndexed { i, h -> idx[h] = i }
        val secs = LinkedHashMap<String, Sec>()
        for (r in rows.drop(1)) {
            val t = r.getOrElse(idx.getValue("类型")) { "" }.trim()
            val map = FLAT_MAP[t] ?: continue
            val sec = secs.getOrPut(t) { Sec(arrayListOf(map.map { it.first })) }
            sec.rows.add(map.map { p -> val i = idx[p.second]; if (i == null) "" else r.getOrElse(i) { "" } })
        }
        return secs
    }

    private fun objs(sec: Sec?): List<Map<String, String>> {
        if (sec == null || sec.rows.size < 2) return emptyList()
        val head = sec.rows[0].map { it.trim() }
        return sec.rows.drop(1).map { r ->
            val o = HashMap<String, String>()
            head.forEachIndexed { i, h -> o[h] = r.getOrElse(i) { "" }.trim() }
            o
        }
    }

    private fun kv(sec: Sec?): Map<String, String> {
        val o = HashMap<String, String>()
        objs(sec).forEach { o[it["项目"] ?: ""] = it["值"] ?: "" }
        return o
    }

    private fun buildRecord(map: Map<String, Int>, cells: List<String>, data: UserData): Pair<String, DailyRecord>? {
        fun get(key: String): String {
            val i = map[key] ?: return ""
            return cells.getOrElse(i) { "" }.trim()
        }
        val date = normDate(get("date")) ?: return null
        var shiftType = get("shiftType")
        val hoursRaw = get("hours")
        if (shiftType.isEmpty()) shiftType = if (hoursRaw == "休") "休息" else "夜班"
        if (!SHIFT_TYPES_VALID.contains(shiftType)) return null

        val hours: String = if (shiftType == "休息" || hoursRaw == "休") "休" else {
            val hn = Fmt.pf(hoursRaw.replace(Regex("[^\\d.\\-]"), ""))
            if (hn.isNaN()) Calc.resolveBaseHours(date, shiftType, data.workdays, data.normalHours) else Fmt.hour(hn)
        }
        val otHN = Fmt.pf(get("otHours").replace(Regex("[^\\d.\\-]"), ""))
        val otHours = if (hours == "休" || otHN.isNaN() || otHN < 0) 0.0 else otHN
        val rN = Fmt.pf(get("otRate").replace(Regex("[^\\d.\\-]"), ""))
        val otRate = if (rN.isNaN() || rN <= 0) {
            if (shiftType == "周末加班" || shiftType == "节假日加班") "2.0" else "1.5"
        } else if (rN == 1.5 || rN == 2.0 || rN == 3.0) "%.1f".format(java.util.Locale.US, rN) else Fmt.jsNum(rN)

        var dayNight = get("dayNight")
        if (dayNight != "白班" && dayNight != "夜班") {
            dayNight = if (shiftType == "白班" || shiftType == "夜班") shiftType else data.quick.dayNight
        }
        var remark = get("remark")
        if (remark.isEmpty()) {
            remark = if (!(otHours > 0)) "未加班"
            else (if (shiftType == "周末加班" || shiftType == "节假日加班") shiftType else "加班") + Fmt.hour(otHours) + "小时"
        }

        var segs: List<OtSegment>? = null
        val segRaw = get("otSegments")
        if (segRaw.isNotEmpty()) {
            try {
                val arr = Json.parseToJsonElement(segRaw) as? JsonArray
                val list = arr?.mapNotNull { e ->
                    val o = e as? JsonObject ?: return@mapNotNull null
                    val h = (o["hours"] as? JsonPrimitive)?.content?.toDoubleOrNull() ?: 0.0
                    val r = (o["rate"] as? JsonPrimitive)?.content?.toDoubleOrNull() ?: 0.0
                    if (h > 0 && r > 0) OtSegment(h, r) else null
                }
                if (!list.isNullOrEmpty()) segs = list
            } catch (e: Exception) { /* 忽略损坏的分段 JSON */ }
        }
        return date to DailyRecord(shiftType, dayNight, hours, Fmt.hour(otHours), otRate, segs, remark, "")
    }

    private fun parseRecordRows(rows: List<List<String>>, data: UserData): Triple<List<Pair<String, DailyRecord>>, Int, Int> {
        if (rows.isEmpty()) return Triple(emptyList(), 0, 0)
        val head = rows[0].map { it.trim().lowercase() }
        var map = HashMap<String, Int>()
        for ((k, aliases) in ALIASES) {
            val i = head.indexOfFirst { aliases.contains(it) }
            if (i >= 0) map[k] = i
        }
        val start: Int
        if (map.containsKey("date")) start = 1 else {
            start = 0
            map = hashMapOf("date" to 0, "shiftType" to 2, "dayNight" to 3, "hours" to 4, "otHours" to 5,
                "otRate" to 6, "remark" to 7, "salary" to 8, "otSegments" to 9)
        }
        val out = ArrayList<Pair<String, DailyRecord>>()
        var skipped = 0
        var total = 0
        for (i in start until rows.size) {
            total++
            val r = buildRecord(map, rows[i], data)
            if (r != null) out.add(r) else skipped++
        }
        return Triple(out, skipped, total)
    }

    fun buildPlan(text: String, data: UserData): ImportPlan {
        val rows = parseCsv(text)
        val secs = splitSections(rows) ?: flatToSections(rows)
        if (secs == null) {
            val (recs, skipped, total) = parseRecordRows(rows, data)
            return ImportPlan(true, emptyMap(), recs, skipped, total, null, 0, 0, null, null, OtherSettings(), 0)
        }
        val meta = kv(secs["元信息"])
        val (recs, skippedRecs, recTotal) = parseRecordRows(secs["工时记录"]?.rows ?: emptyList(), data)
        var skippedOther = 0

        /* 周期设置 */
        val defRates = Rates()
        val hmap = LinkedHashMap<String, SettingsVersion>()
        for (o in objs(secs["周期设置"])) {
            val key = parseKey(o["生效周期"])
            if (key == null) { skippedOther++; continue }
            val rv = RATE_COLS.mapIndexed { i, c -> numStr(o[c], defRates.csvOrder()[i]) }
            val base = numStr(o["月基本工资"], "3730")
            val hsDefault = Calc.deriveHs(base).toString()
            val hs = numStr(o["小时工资"], hsDefault)
            val cyc = (o["考勤周期"] ?: "").trim().toDoubleOrNull()?.toInt() ?: data.cycleIndex
            hmap[key] = SettingsVersion(
                from = key,
                salary = SalaryCfg(
                    baseSalary = base, hourSalary = hs, hourSalaryExact = hs,
                    rate1 = numStr(o["平时加班倍数"], "1.5"), rate2 = numStr(o["周末加班倍数"], "2.0"), rate3 = numStr(o["节假日加班倍数"], "3.0")
                ),
                deduction = DeductionCfg(
                    socialBase = numStr(o["社保基数"], "7546"), housingBase = numStr(o["公积金基数"], "2690"),
                    housingRate = numStr(o["公积金比例%"], "5"), incomeTax = numStr(o["个税(月)"], "102.16"),
                    rates = Rates.fromCsvOrder(rv)
                ),
                subsidy = null,
                cycle = cyc
            )
        }

        /* 周期补贴 */
        val groups = LinkedHashMap<String, MutableList<Pair<Int, SubsidyItem>>>()
        for (o in objs(secs["周期补贴"])) {
            val key = parseKey(o["生效周期"])
            val name = o["补贴名称"] ?: ""
            if (key == null || name.isEmpty() || !hmap.containsKey(key)) { skippedOther++; continue }
            val amt = Fmt.pf((o["金额"] ?: "").replace(Regex("[^\\d.\\-]"), ""))
            if (amt.isNaN() || amt < 0) { skippedOther++; continue }
            val days = (o["补贴天数"] ?: "").trim().toDoubleOrNull()?.toInt() ?: 0
            groups.getOrPut(key) { ArrayList() }.add(
                ((o["序号"] ?: "").trim().toDoubleOrNull()?.toInt() ?: 0) to
                        SubsidyItem(name, amt, yes(o["启用"]), if ((o["计算方式"] ?: "").contains("日")) "daily" else "monthly", if (days < 0) 0 else days)
            )
        }
        var subCount = 0
        for ((key, list) in groups) {
            val items = list.sortedBy { it.first }.map { it.second }
            hmap[key] = hmap.getValue(key).copy(subsidy = items)
            subCount += items.size
        }
        val history = if (hmap.isEmpty()) null else hmap.values.sortedBy { it.from }

        /* 快捷记录 */
        var quick: List<QuickRecord>? = null
        if (secs.containsKey("快捷记录")) {
            val q = ArrayList<QuickRecord>()
            for (o in objs(secs["快捷记录"])) {
                val h = Fmt.pf((o["加班小时"] ?: "").replace(Regex("[^\\d.\\-]"), ""))
                val r = Fmt.pf((o["加班倍数"] ?: "").replace(Regex("[^\\d.\\-]"), ""))
                if ((o["名称"] ?: "").isEmpty() || h.isNaN() || r.isNaN()) { skippedOther++; continue }
                q.add(QuickRecord(o["名称"] ?: "", (o["类型"] ?: "").ifEmpty { "blue" }, h, r))
            }
            quick = q
        }

        /* 明细项 */
        var sheet: List<SheetItem>? = null
        if (secs.containsKey("明细项")) {
            val sh = ArrayList<SheetItem>()
            val seen = HashSet<String>()
            val sortedObjs = objs(secs["明细项"]).sortedBy { (it["顺序"] ?: "").toDoubleOrNull()?.toInt() ?: 0 }
            for (o in sortedObjs) {
                val k = o["标识"] ?: ""
                if (k.isEmpty() || !seen.add(k)) { skippedOther++; continue }
                sh.add(SheetItem(k, (o["名称"] ?: "").ifEmpty { k }, yes(o["显示"])))
            }
            if (sh.isNotEmpty()) sheet = sh
        }

        /* 其他设置 */
        val o = kv(secs["其他设置"])
        val ci = o["考勤周期"]?.trim()?.toDoubleOrNull()?.toInt()
        val workdays = o["工作日"]?.split(Regex("[|、,，]"))?.map { it.trim() }?.filter { WEEK_DAYS.contains(it) }
        val nh = o["正常工时"]?.trim()?.toDoubleOrNull()?.toInt()
        val sv = HashMap<String, Boolean>()
        listOf("night" to "汇总显示-夜班补贴", "meal" to "汇总显示-伙食补贴", "taxable" to "汇总显示-应纳税所得额", "social" to "汇总显示-个人五险")
            .forEach { (k, n) -> if (o.containsKey(n)) sv[k] = yes(o[n]) }
        val dv = HashMap<String, Boolean>()
        listOf("social" to "统计显示-五险", "housing" to "统计显示-公积金", "tax" to "统计显示-个税")
            .forEach { (k, n) -> if (o.containsKey(n)) dv[k] = yes(o[n]) }
        val other = OtherSettings(
            cycleIndex = if (ci != null && ci >= 0 && ci < CYCLE_LIST.size) ci else null,
            workdays = workdays,
            normalHours = if (nh != null && nh in 1..24) nh else null,
            dayNight = o["默认白夜班"]?.takeIf { it == "白班" || it == "夜班" },
            showQuick = if (o.containsKey("首页展示快捷记录")) yes(o["首页展示快捷记录"]) else null,
            summary = if (sv.isEmpty()) null else sv,
            deductionVisible = if (dv.isEmpty()) null else dv,
            themeBg = o["主题背景"]?.takeIf { THEME_BGS.contains(it) },
            themeColor = o["主题色"]?.takeIf { THEME_COLORS.contains(it) }
        )

        return ImportPlan(false, meta, recs, skippedRecs, recTotal, history, groups.size, subCount, quick, sheet, other, skippedOther)
    }

    /** 导入确认框摘要 */
    fun planSummary(plan: ImportPlan, data: UserData, current: User): String {
        val overwrite = plan.records.count { data.records.containsKey(it.first) }
        val lines = ArrayList<String>()
        val fromName = plan.meta["用户名"]
        val fromId = plan.meta["用户ID"]
        if (!fromName.isNullOrEmpty() && (fromName != current.name || (!fromId.isNullOrEmpty() && fromId != current.id))) {
            lines.add("⚠ 文件导出自用户「$fromName」，与当前用户「${current.name}」不同。")
        }
        lines.add("将导入到当前用户「${current.name}」：")
        if (plan.records.isNotEmpty()) lines.add("· 工时记录 ${plan.records.size} 条（新增 ${plan.records.size - overwrite}，覆盖 $overwrite）")
        plan.history?.let { lines.add("· 周期设置 ${it.size} 个周期（含基本工资、社保、公积金、个税）") }
        if (plan.subsidyCycles > 0) lines.add("· 周期补贴 ${plan.subsidyCycles} 个周期，共 ${plan.subsidyCount} 项")
        plan.quick?.let { lines.add("· 快捷记录 ${it.size} 条") }
        plan.sheet?.let { lines.add("· 工资条明细项 ${it.size} 项") }
        if (plan.other.count() > 0) lines.add("· 其他设置 ${plan.other.count()} 项")
        if (plan.skippedTotal > 0) lines.add("· 跳过无法识别的 ${plan.skippedTotal} 行")
        lines.add("")
        lines.add(if (plan.legacy) "同日期的工时记录将被覆盖。" else "工时记录按日期合并，其余设置将替换为文件内容，无法撤销。")
        return lines.joinToString("\n")
    }

    /** 把导入计划合并进用户数据，返回新数据（当日工资字符串按导入后的各周期设置重算） */
    fun applyPlan(plan: ImportPlan, data: UserData): UserData {
        var history = data.history
        plan.history?.let { list ->
            history = list.map { v -> if (v.subsidy == null) v.copy(subsidy = Calc.subsidyAt(data.history, v.from)) else v }
        }
        val records = data.records.toMutableMap()
        for ((date, rec) in plan.records) {
            records[date] = rec.copy(salary = "¥" + Fmt.money(Calc.recPayAt(history, date, rec).total))
        }
        val o = plan.other
        var quick: QuickSettings = data.quick
        plan.quick?.let { quick = quick.copy(records = it) }
        o.showQuick?.let { quick = quick.copy(show = it) }
        o.dayNight?.let { quick = quick.copy(dayNight = it) }
        var sv = data.summaryVisible
        o.summary?.let { m ->
            sv = sv.copy(night = m["night"] ?: sv.night, meal = m["meal"] ?: sv.meal, taxable = m["taxable"] ?: sv.taxable, social = m["social"] ?: sv.social)
        }
        var dv = data.deductionVisible
        o.deductionVisible?.let { m ->
            dv = dv.copy(social = m["social"] ?: dv.social, housing = m["housing"] ?: dv.housing, tax = m["tax"] ?: dv.tax)
        }
        return data.copy(
            records = records,
            history = history,
            quick = quick,
            sheetItems = plan.sheet ?: data.sheetItems,
            theme = data.theme.copy(bg = o.themeBg ?: data.theme.bg, color = o.themeColor ?: data.theme.color),
            summaryVisible = sv,
            deductionVisible = dv,
            cycleIndex = o.cycleIndex ?: data.cycleIndex,
            workdays = o.workdays ?: data.workdays,
            normalHours = o.normalHours ?: data.normalHours
        )
    }
}
