package com.uct.salary.model

import kotlinx.serialization.KSerializer
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import kotlinx.serialization.json.JsonDecoder
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonPrimitive

/**
 * 网页版 localStorage 里同一个字段可能是数字也可能是字符串（例如 baseSalary 既可能是 "3730" 也可能是 3730），
 * 这里用宽松序列化器统一读成 String / Double / Int，写出时保持类型稳定。
 */
object FlexString : KSerializer<String> {
    override val descriptor: SerialDescriptor = PrimitiveSerialDescriptor("FlexString", PrimitiveKind.STRING)

    override fun deserialize(decoder: Decoder): String {
        val jd = decoder as? JsonDecoder ?: return decoder.decodeString()
        val el = jd.decodeJsonElement()
        return when (el) {
            is JsonNull -> ""
            is JsonPrimitive -> el.content
            else -> el.toString()
        }
    }

    override fun serialize(encoder: Encoder, value: String) = encoder.encodeString(value)
}

object FlexDouble : KSerializer<Double> {
    override val descriptor: SerialDescriptor = PrimitiveSerialDescriptor("FlexDouble", PrimitiveKind.DOUBLE)

    override fun deserialize(decoder: Decoder): Double {
        val jd = decoder as? JsonDecoder ?: return decoder.decodeDouble()
        val el = jd.decodeJsonElement()
        return if (el is JsonPrimitive && el !is JsonNull) el.content.trim().toDoubleOrNull() ?: 0.0 else 0.0
    }

    override fun serialize(encoder: Encoder, value: Double) = encoder.encodeDouble(value)
}

object FlexInt : KSerializer<Int> {
    override val descriptor: SerialDescriptor = PrimitiveSerialDescriptor("FlexInt", PrimitiveKind.INT)

    override fun deserialize(decoder: Decoder): Int {
        val jd = decoder as? JsonDecoder ?: return decoder.decodeInt()
        val el = jd.decodeJsonElement()
        return if (el is JsonPrimitive && el !is JsonNull) el.content.trim().toDoubleOrNull()?.toInt() ?: 0 else 0
    }

    override fun serialize(encoder: Encoder, value: Int) = encoder.encodeInt(value)
}
