package com.uct.salary.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uct.salary.core.Calc
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.model.CYCLE_LIST
import com.uct.salary.model.CORE_SUBSIDY_NAMES
import com.uct.salary.model.DEFAULT_SUBSIDY_NAMES
import com.uct.salary.model.DeductionCfg
import com.uct.salary.model.Rates
import com.uct.salary.model.SalaryCfg
import com.uct.salary.model.SubsidyItem
import com.uct.salary.model.WEEK_DAYS
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.Route
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.AppTopBar
import com.uct.salary.ui.components.Avatar
import com.uct.salary.ui.components.CardBox
import com.uct.salary.ui.components.CycleConfigBar
import com.uct.salary.ui.components.Field
import com.uct.salary.ui.components.LabeledField
import com.uct.salary.ui.components.PillSwitch
import com.uct.salary.ui.components.Segmented
import com.uct.salary.ui.components.SettingRow
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray600
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.Red500
import com.uct.salary.ui.theme.White
import kotlinx.coroutines.launch

/* ============================ 通用页面骨架 ============================ */

@Composable
fun SettingsPage(
    title: String,
    onBack: () -> Unit,
    bottom: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        AppTopBar(title, onBack = onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            content = content
        )
        if (bottom != null) Box(Modifier.fillMaxWidth().background(White).navigationBarsPadding().padding(12.dp)) { bottom() }
        else Spacer(Modifier.navigationBarsPadding())
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(10.dp)).background(primary()).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(text, color = onPrimary(), fontSize = 15.sp, fontWeight = FontWeight.Medium) }
}

/** 通用表单弹窗（样式同删除确认框：白色圆角卡片，左白底描边“取消”，右主色确认） */
@Composable
fun FormDialog(
    title: String,
    onCancel: () -> Unit,
    onConfirm: () -> Unit,
    onDelete: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    androidx.compose.ui.window.Dialog(onDismissRequest = onCancel, properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
            Column(
                Modifier.widthIn(max = 384.dp).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(White).padding(20.dp)
            ) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
                Spacer(Modifier.height(14.dp))
                Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp), content = content)
                Spacer(Modifier.height(20.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (onDelete != null) {
                        Box(
                            Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(8.dp)).background(White)
                                .clickable(onClick = onDelete).border(1.dp, Red500, RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) { Text("删除", fontSize = 15.sp, color = Red500, fontWeight = FontWeight.Medium) }
                    }
                    Box(
                        Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(8.dp)).background(White)
                            .clickable(onClick = onCancel).border(1.dp, Gray200, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) { Text("取消", fontSize = 15.sp, color = com.uct.salary.ui.theme.Gray700, fontWeight = FontWeight.Medium) }
                    Box(
                        Modifier.weight(1f).height(44.dp).clip(RoundedCornerShape(8.dp)).background(primary()).clickable(onClick = onConfirm),
                        contentAlignment = Alignment.Center
                    ) { Text("保存", fontSize = 15.sp, color = onPrimary(), fontWeight = FontWeight.Medium) }
                }
            }
        }
    }
}

/* ============================ 设置首页 / 工资页 ============================ */

@Composable
fun SettingsHomeScreen(vm: AppViewModel) {
    val real = Dates.realKey()
    val enabledCount = Calc.subsidyAt(vm.data.history, real).count { it.enabled }
    SettingsPage("设置", { vm.pop() }) {
        CardBox(padding = 0.dp) {
            Row(
                Modifier.fillMaxWidth().clickable { vm.push(Route.UserManage) }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Avatar(vm.currentUser, 44.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(vm.currentUser.name, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Gray900)
                    Text("用户", fontSize = 12.sp, color = Gray500)
                }
                Icon(AppIcons.Right, null, tint = Gray400)
            }
        }
        CardBox(padding = 0.dp) {
            SettingRow("工资", "工资、周期、工作日、快捷记录", AppIcons.Money) { vm.openSettingsPage(Route.SalaryDetail) }
            SettingRow("补贴", "已启用 $enabledCount 项", AppIcons.Wallet) { vm.openSettingsPage(Route.SubsidySettings) }
            SettingRow("扣除", "五险一金、个税", AppIcons.Tune) { vm.openSettingsPage(Route.DeductionSettings) }
            SettingRow("主题", "背景、主题色", AppIcons.Palette) { vm.push(Route.ThemeSettings) }
        }
    }
}

fun workdaySummary(days: List<String>): String = when {
    days.size == 7 -> "每天"
    days.isEmpty() -> "未选择"
    days == listOf("周一", "周二", "周三", "周四", "周五") -> "周一、周二、周三、周四、周五"
    else -> WEEK_DAYS.filter { days.contains(it) }.joinToString("、")
}

@Composable
fun SalaryDetailScreen(vm: AppViewModel) {
    val cfg = Calc.settingsAt(vm.data.history, Dates.realKey())
    SettingsPage("工资", { vm.pop() }) {
        CardBox(padding = 0.dp) {
            SettingRow("工资设定", "月基本工资 ¥${Fmt.money(cfg.base)} · 小时工资 ¥${Fmt.fixed2(cfg.hs)}") { vm.openSettingsPage(Route.SalarySettings) }
            SettingRow("考勤周期", CYCLE_LIST.getOrElse(vm.data.cycleIndex) { "" }) { vm.push(Route.CycleSettings) }
            SettingRow("工作日设定", workdaySummary(vm.data.workdays)) { vm.push(Route.WorkdaySettings) }
            SettingRow("快捷记录设置", "${vm.data.quick.records.size}个班次") { vm.push(Route.QuickSettings) }
        }
    }
}

/* ============================ 工资设定（按周期） ============================ */

@Composable
fun SalarySettingsScreen(vm: AppViewModel) {
    val key = vm.cfgKey
    val ver = remember(key) { Calc.versionAt(vm.data.history, key) }
    var base by remember(key) { mutableStateOf(ver.salary.baseSalary) }
    var hsText by remember(key) { mutableStateOf(Fmt.jsNum(Calc.hsOf(ver.salary))) }
    var r1 by remember(key) { mutableStateOf(ver.salary.rate1) }
    var r2 by remember(key) { mutableStateOf(ver.salary.rate2) }
    var r3 by remember(key) { mutableStateOf(ver.salary.rate3) }

    fun save() = vm.saveSalary(SalaryCfg(base, hsText, hsText, r1, r2, r3))
    val hs = Fmt.pfz(hsText)

    SettingsPage("工资设定", { save(); vm.pop() }, bottom = { PrimaryButton("保存") { save(); vm.pop() } }) {
        CycleConfigBar(Dates.longLabel(key), key == Dates.realKey(), { vm.shiftCfg(-1) }, { vm.shiftCfg(1) })
        CardBox {
            LabeledField("月基本工资（元）", base, { base = it; hsText = Fmt.jsNum(Calc.deriveHs(it)) }, keyboard = KeyboardType.Decimal)
            Spacer(Modifier.height(12.dp))
            LabeledField("小时工资（元，默认 = 基本工资 ÷ 21.75 ÷ 8，可手动修改）", hsText, { hsText = it }, keyboard = KeyboardType.Decimal)
        }
        CardBox {
            Text("加班倍数", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.height(8.dp))
            RateRow("平时加班", r1, { r1 = it }, hs)
            RateRow("周末加班", r2, { r2 = it }, hs)
            RateRow("节假日加班", r3, { r3 = it }, hs)
        }
    }
}

@Composable
private fun RateRow(label: String, rate: String, onRate: (String) -> Unit, hs: Double) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 14.sp, color = Gray600, modifier = Modifier.width(84.dp))
        Field(rate, onRate, Modifier.width(80.dp), keyboard = KeyboardType.Decimal)
        Text("  倍", fontSize = 13.sp, color = Gray500)
        Spacer(Modifier.weight(1f))
        Text("${Fmt.fixed2(hs * Fmt.pfz(rate))} 元/小时", fontSize = 13.sp, color = Gray900, fontWeight = FontWeight.Medium)
    }
}

/* ============================ 补贴设置（按周期） ============================ */

@Composable
fun SubsidySettingsScreen(vm: AppViewModel) {
    val key = vm.cfgKey
    val list = Calc.subsidyAt(vm.data.history, key)
    var editIdx by remember { mutableIntStateOf(-2) }   // -2 不编辑；-1 新增；>=0 编辑
    val visible = list.withIndex().filter { (_, sub) -> CORE_SUBSIDY_NAMES.contains(sub.name) || !DEFAULT_SUBSIDY_NAMES.contains(sub.name) }

    SettingsPage("奖金/补贴项", { vm.pop() }, bottom = {
        PrimaryButton("自定义添加一项") { editIdx = -1 }
    }) {
        CycleConfigBar(Dates.longLabel(key), key == Dates.realKey(), { vm.shiftCfg(-1) }, { vm.shiftCfg(1) })
        Text("已启用 ${list.count { it.enabled }} 项", fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(horizontal = 4.dp))
        CardBox(padding = 0.dp) {
            visible.forEach { (idx, item) ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { editIdx = idx }) {
                        Text(item.name, fontSize = 15.sp, color = Gray900)
                        Text(Calc.subsidyLabel(item), fontSize = 12.sp, color = Gray500)
                    }
                    Icon(AppIcons.Edit, "编辑", tint = Gray400, modifier = Modifier.size(20.dp).clickable { editIdx = idx })
                    Spacer(Modifier.width(10.dp))
                    PillSwitch(item.enabled) { on -> vm.saveSubsidy(list.mapIndexed { i, s -> if (i == idx) s.copy(enabled = on) else s }) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Gray100))
            }
        }
    }

    if (editIdx >= -1) {
        val existing = list.getOrNull(editIdx)
        var name by remember(editIdx) { mutableStateOf(existing?.name ?: "自定义补贴") }
        var amount by remember(editIdx) { mutableStateOf(existing?.let { Fmt.jsNum(it.amount) } ?: "100") }
        var daily by remember(editIdx) { mutableStateOf(existing?.mode == "daily") }
        var days by remember(editIdx) { mutableStateOf(existing?.days?.takeIf { it > 0 }?.toString() ?: "") }
        FormDialog(
            title = if (existing == null) "添加补贴" else "编辑补贴",
            onCancel = { editIdx = -2 },
            onConfirm = {
                val item = SubsidyItem(
                    name = name.ifBlank { "自定义补贴" }, amount = Fmt.pfz(amount), enabled = existing?.enabled ?: true,
                    mode = if (daily) "daily" else "monthly", days = if (daily) (days.trim().toDoubleOrNull()?.toInt() ?: 0).coerceAtLeast(0) else 0
                )
                vm.saveSubsidy(if (existing == null) list + item else list.mapIndexed { i, s -> if (i == editIdx) item else s })
                editIdx = -2
            },
            onDelete = if (existing != null) ({ vm.saveSubsidy(list.filterIndexed { i, _ -> i != editIdx }); editIdx = -2 }) else null
        ) {
            LabeledField("补贴名称", name, { name = it })
            LabeledField("金额（元）", amount, { amount = it }, keyboard = KeyboardType.Decimal)
            Text("计算方式", fontSize = 13.sp, color = Gray500)
            Segmented(listOf("按月", "按日"), if (daily) 1 else 0, { daily = it == 1 })
            if (daily) LabeledField("补贴天数（不填取当月全部天数）", days, { days = it }, keyboard = KeyboardType.Number, placeholder = "当月天数")
        }
    }
}

/* ============================ 扣除设置（按周期） ============================ */

@Composable
fun DeductionSettingsScreen(vm: AppViewModel) {
    val key = vm.cfgKey
    val ver = remember(key) { Calc.versionAt(vm.data.history, key) }
    val rates0 = remember(key) { Calc.ratesAt(vm.data.history, key) }
    var sb by remember(key) { mutableStateOf(ver.deduction.socialBase) }
    var hb by remember(key) { mutableStateOf(ver.deduction.housingBase) }
    var hr by remember(key) { mutableStateOf(ver.deduction.housingRate) }
    var tax by remember(key) { mutableStateOf(ver.deduction.incomeTax) }
    val rv = remember(key) { mutableStateOf(rates0.csvOrder()) }   // 顺序：养老单/个、医疗单/个、失业单/个、工伤单/个、生育单/个

    fun save() = vm.saveDeduction(DeductionCfg(sb, hb, hr, tax, Rates.fromCsvOrder(rv.value)))
    val names = listOf("养老保险", "医疗保险", "失业保险", "工伤保险", "生育保险")
    val base = Fmt.pfz(sb)
    var unitSum = 0.0
    var personSum = 0.0
    for (i in 0 until 5) { unitSum += Fmt.pfz(rv.value[i * 2]); personSum += Fmt.pfz(rv.value[i * 2 + 1]) }

    SettingsPage("扣除设置", { save(); vm.pop() }, bottom = { PrimaryButton("保存") { save(); vm.pop() } }) {
        CycleConfigBar(Dates.longLabel(key), key == Dates.realKey(), { vm.shiftCfg(-1) }, { vm.shiftCfg(1) })
        CardBox {
            Text("五险", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.height(8.dp))
            LabeledField("缴费基数（元）", sb, { sb = it }, keyboard = KeyboardType.Decimal)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth()) {
                Spacer(Modifier.width(76.dp))
                Text("单位%", Modifier.weight(1f), fontSize = 12.sp, color = Gray500, textAlign = TextAlign.Center)
                Text("个人%", Modifier.weight(1f), fontSize = 12.sp, color = Gray500, textAlign = TextAlign.Center)
                Text("个人金额", Modifier.width(80.dp), fontSize = 12.sp, color = Gray500, textAlign = TextAlign.End)
            }
            for (i in 0 until 5) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(names[i], Modifier.width(76.dp), fontSize = 13.sp, color = Gray600)
                    Field(rv.value[i * 2], { v -> rv.value = rv.value.toMutableList().also { it[i * 2] = v } }, Modifier.weight(1f).padding(end = 6.dp), keyboard = KeyboardType.Decimal, textAlign = TextAlign.Center)
                    Field(rv.value[i * 2 + 1], { v -> rv.value = rv.value.toMutableList().also { it[i * 2 + 1] = v } }, Modifier.weight(1f).padding(end = 6.dp), keyboard = KeyboardType.Decimal, textAlign = TextAlign.Center)
                    Text(Fmt.fixed2(base * Fmt.pfz(rv.value[i * 2 + 1]) / 100), Modifier.width(80.dp), fontSize = 13.sp, color = Gray900, textAlign = TextAlign.End)
                }
            }
            Spacer(Modifier.height(8.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Gray200))
            Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text("单位合计 ${Fmt.fixed2(base * unitSum / 100)}", Modifier.weight(1f), fontSize = 13.sp, color = Gray600)
                Text("个人合计 ${Fmt.fixed2(base * personSum / 100)}", fontSize = 13.sp, color = Gray900, fontWeight = FontWeight.Medium)
            }
        }
        CardBox {
            Text("公积金", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LabeledField("缴费基数（元）", hb, { hb = it }, Modifier.weight(1f), keyboard = KeyboardType.Decimal)
                LabeledField("缴存比例（%）", hr, { hr = it }, Modifier.weight(1f), keyboard = KeyboardType.Decimal)
            }
            Spacer(Modifier.height(8.dp))
            val hAmt = Fmt.fixed2(Fmt.pfz(hb) * Fmt.pfz(hr) / 100)
            Text("单位 $hAmt　·　个人 $hAmt", fontSize = 13.sp, color = Gray600)
        }
        CardBox {
            Text("个人所得税（月）", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            Spacer(Modifier.height(8.dp))
            Field(tax, { tax = it }, Modifier.fillMaxWidth(), keyboard = KeyboardType.Decimal)
            Text("正值输入，计算时自动取负；收支汇总的“应纳税所得额”取此值", fontSize = 11.sp, color = Gray400, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

/* ============================ 考勤周期（滚轮） ============================ */

@Composable
fun CycleSettingsScreen(vm: AppViewModel) {
    val itemH = 40.dp
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = vm.data.cycleIndex)
    val fling = rememberSnapFlingBehavior(listState)
    val itemPx = with(LocalDensity.current) { itemH.toPx() }
    val selected by remember {
        derivedStateOf {
            val extra = if (listState.firstVisibleItemScrollOffset > itemPx / 2) 1 else 0
            (listState.firstVisibleItemIndex + extra).coerceIn(0, CYCLE_LIST.size - 1)
        }
    }
    val scope = rememberCoroutineScope()

    SettingsPage("考勤周期", { vm.pop() }, bottom = {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(10.dp)).background(White).clickable { vm.pop() },
                contentAlignment = Alignment.Center
            ) { Text("取消", fontSize = 15.sp, color = Gray600, fontWeight = FontWeight.Medium) }
            PrimaryButton("确定", Modifier.weight(1f)) { vm.confirmCycleIndex(selected); vm.pop() }
        }
    }) {
        CardBox {
            Box(Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.fillMaxWidth().height(itemH).clip(RoundedCornerShape(8.dp)).background(primary().copy(alpha = 0.16f)))
                LazyColumn(state = listState, flingBehavior = fling, contentPadding = PaddingValues(vertical = 80.dp), modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(CYCLE_LIST) { i, label ->
                        Box(Modifier.fillMaxWidth().height(itemH).clickable { scope.launch { listState.animateScrollToItem(i) } }, contentAlignment = Alignment.Center) {
                            Text(label, fontSize = if (i == selected) 18.sp else 15.sp, fontWeight = if (i == selected) FontWeight.Medium else FontWeight.Normal, color = if (i == selected) Gray900 else Gray400)
                        }
                    }
                }
            }
        }
        Text("提示：日历与统计的工资周期固定为“上月16日 ～ 本月15日”，此处选择仅作记录与展示。", fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

/* ============================ 工作日设定 ============================ */

@Composable
fun WorkdaySettingsScreen(vm: AppViewModel) {
    var hours by remember { mutableStateOf(vm.data.normalHours.toFloat()) }
    var sel by remember { mutableStateOf(vm.data.workdays.toSet()) }
    SettingsPage("工作日设定", { vm.pop() }, bottom = {
        PrimaryButton("修改") { vm.setWorkdays(WEEK_DAYS.filter { sel.contains(it) }); vm.pop() }
    }) {
        CardBox {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("正常工时", fontSize = 15.sp, color = Gray900, modifier = Modifier.weight(1f))
                Text("${hours.toInt()} 小时", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900)
            }
            Slider(
                value = hours, onValueChange = { hours = it; vm.setNormalHours(it.toInt()) }, valueRange = 1f..24f, steps = 22,
                colors = SliderDefaults.colors(thumbColor = primary(), activeTrackColor = primary())
            )
        }
        CardBox(padding = 0.dp) {
            WEEK_DAYS.forEach { d ->
                val on = sel.contains(d)
                Row(
                    Modifier.fillMaxWidth().clickable { sel = if (on) sel - d else sel + d }.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(d, fontSize = 15.sp, color = Gray900, modifier = Modifier.weight(1f))
                    Icon(if (on) AppIcons.CheckCircle else AppIcons.Unchecked, null, tint = if (on) primary() else Gray200, modifier = Modifier.size(24.dp))
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(Gray100))
            }
        }
    }
}
