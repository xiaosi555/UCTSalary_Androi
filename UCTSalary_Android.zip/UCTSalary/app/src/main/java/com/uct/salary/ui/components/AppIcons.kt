package com.uct.salary.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.AccountBalanceWallet

/** 统一引用图标，避免各处散落 import */
object AppIcons {
    val Back = Icons.AutoMirrored.Filled.ArrowBack
    val Right = Icons.AutoMirrored.Filled.KeyboardArrowRight
    val Add = Icons.Filled.Add
    val BarChart = Icons.Filled.BarChart
    val Bolt = Icons.Filled.Bolt
    val Calendar = Icons.Filled.CalendarMonth
    val Check = Icons.Filled.Check
    val CheckCircle = Icons.Filled.CheckCircle
    val Unchecked = Icons.Filled.RadioButtonUnchecked
    val Close = Icons.Filled.Close
    val Copy = Icons.Filled.ContentCopy
    val Delete = Icons.Filled.Delete
    val Edit = Icons.Filled.Edit
    val Sign = Icons.Filled.EventAvailable
    val ExpandLess = Icons.Filled.ExpandLess
    val ExpandMore = Icons.Filled.ExpandMore
    val Download = Icons.Filled.FileDownload
    val Upload = Icons.Filled.FileUpload
    val Down = Icons.Filled.KeyboardArrowDown
    val Up = Icons.Filled.KeyboardArrowUp
    val Palette = Icons.Filled.Palette
    val Money = Icons.Filled.Paid
    val Person = Icons.Filled.Person
    val Settings = Icons.Filled.Settings
    val Tune = Icons.Filled.Tune
    val Eye = Icons.Filled.Visibility
    val EyeOff = Icons.Filled.VisibilityOff
    val Wallet = Icons.Filled.AccountBalanceWallet
}
