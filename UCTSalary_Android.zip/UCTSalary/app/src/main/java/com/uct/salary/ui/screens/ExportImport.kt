package com.uct.salary.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.uct.salary.core.CsvIo
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray600
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.White
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** UTF-8 解码失败时回退 GBK（Excel 另存的 CSV 常见） */
fun decodeBytes(b: ByteArray): String = try {
    Charsets.UTF_8.newDecoder()
        .onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT)
        .decode(ByteBuffer.wrap(b)).toString()
} catch (e: CharacterCodingException) {
    try { String(b, Charset.forName("GBK")) } catch (e2: Exception) { String(b, Charsets.UTF_8) }
}

private fun readUri(ctx: Context, uri: Uri): ByteArray? =
    ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }

/** 返回一个“选择 CSV 并导入”的触发函数（系统文件选择器，无需存储权限） */
@Composable
fun rememberImportLauncher(vm: AppViewModel): () -> Unit {
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val bytes = try { readUri(ctx, uri) } catch (e: Exception) { null }
            if (bytes == null) vm.alert("导入失败", "文件读取失败，请重试。") else vm.importText(decodeBytes(bytes))
        }
    }
    return { launcher.launch(arrayOf("*/*")) }
}

@Composable
fun ExportDialog(vm: AppViewModel) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val pickImport = rememberImportLauncher(vm)
    val sections = remember { vm.exportSections() }
    val flat = remember(sections) { CsvIo.toFlat(sections) }
    val keep = remember(flat) { CsvIo.FLAT_COLS.indices.map { i -> flat.any { it[i].isNotEmpty() } } }
    val heads = remember(keep) { CsvIo.FLAT_COLS.filterIndexed { i, _ -> keep[i] } }
    val rows = remember(flat) { flat.take(400).map { r -> r.filterIndexed { i, _ -> keep[i] } } }
    val by = sections.associate { it.name to it.rows.size }
    val colW = 96.dp

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        if (uri != null) {
            try {
                val text = "\uFEFF" + vm.exportCsv()
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                vm.alert("导出完成", "已保存 CSV 文件（一个文件，包含全部数据）。")
            } catch (e: Exception) {
                vm.alert("下载失败", "无法写入所选位置，请换一个位置重试，或改用“复制全部内容”。")
            }
        }
    }

    Dialog(onDismissRequest = { vm.exportOpen = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 640.dp).clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                    .background(White).navigationBarsPadding().padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("导出数据", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Gray900, modifier = Modifier.weight(1f))
                    Icon(AppIcons.Close, "关闭", tint = Gray500, modifier = Modifier.size(24.dp).clickable { vm.exportOpen = false })
                }
                Spacer(Modifier.height(6.dp))
                Text(
                    "用户：${vm.currentUser.name} · 单个CSV共 ${sections.sumOf { it.rows.size }} 行 · 工时 ${by["工时记录"]} · 周期设置 ${by["周期设置"]} · 补贴 ${by["周期补贴"]} · 快捷 ${by["快捷记录"]} · 明细项 ${by["明细项"]}",
                    fontSize = 12.sp, color = Gray500
                )
                Spacer(Modifier.height(10.dp))

                // 单张预览表（隐藏全空列，最多预览 400 行）
                Box(Modifier.fillMaxWidth().weight(1f, fill = false).clip(RoundedCornerShape(8.dp)).background(Gray100).horizontalScroll(rememberScrollState())) {
                    Column(Modifier.width(colW * heads.size)) {
                        Row(Modifier.background(Gray200)) {
                            heads.forEach { Text(it, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = Gray600, modifier = Modifier.width(colW).padding(horizontal = 6.dp, vertical = 8.dp), maxLines = 1) }
                        }
                        LazyColumn(Modifier.height(300.dp)) {
                            itemsIndexed(rows) { idx, r ->
                                Row(Modifier.background(if (idx % 2 == 0) White else Gray100)) {
                                    r.forEach { Text(it, fontSize = 11.sp, color = Gray800, modifier = Modifier.width(colW).padding(horizontal = 6.dp, vertical = 7.dp), maxLines = 1) }
                                }
                            }
                        }
                    }
                }
                if (flat.size > 400) Text("仅预览前 400 行，导出文件包含全部", fontSize = 11.sp, color = Gray400, modifier = Modifier.padding(top = 6.dp))
                Spacer(Modifier.height(14.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionButton("下载CSV", AppIcons.Download, Modifier.weight(1f)) { saver.launch(vm.exportFileName()) }
                    ActionButton("复制全部内容", AppIcons.Copy, Modifier.weight(1.3f)) {
                        clipboard.setText(AnnotatedString(vm.exportCsv()))
                        vm.alert("复制成功", "已复制全部内容，可粘贴到表格或保存为 .csv 文件。")
                    }
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(primary()).clickable(onClick = pickImport).padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(AppIcons.Upload, null, tint = onPrimary(), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("导入数据", fontSize = 13.sp, color = onPrimary(), fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
            }
        }
    }
}
