package com.uct.salary.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uct.salary.model.SheetItem
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.components.AppIcons
import com.uct.salary.ui.components.CardBox
import com.uct.salary.ui.components.Field
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Red500

/** 明细项管理（S-14）：勾选启用、改名、上移/下移、删除、新增；“保存并返回”才写入 */
@Composable
fun SheetManageScreen(vm: AppViewModel) {
    val items = remember { mutableStateListOf<SheetItem>().apply { addAll(vm.data.sheetItems) } }

    SettingsPage("明细项管理", { vm.pop() }, bottom = {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(46.dp).clip(RoundedCornerShape(10.dp)).background(primary().copy(alpha = 0.16f))
                    .clickable { items.add(SheetItem("custom_" + System.currentTimeMillis(), "自定义明细项", true)) },
                contentAlignment = Alignment.Center
            ) { Text("新增明细项", fontSize = 15.sp, color = com.uct.salary.ui.theme.Gray900, fontWeight = FontWeight.Medium) }
            PrimaryButton("保存并返回", Modifier.weight(1f)) { vm.setSheetItems(items.toList()); vm.pop() }
        }
    }) {
        Text("勾选的项目会显示在“数据明细”中；名称可直接修改。", fontSize = 12.sp, color = Gray500, modifier = Modifier.padding(horizontal = 4.dp))
        CardBox(padding = 8.dp) {
            items.forEachIndexed { i, it0 ->
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (it0.enabled) AppIcons.CheckCircle else AppIcons.Unchecked, null,
                        tint = if (it0.enabled) primary() else Gray200,
                        modifier = Modifier.size(28.dp).clip(CircleShape).clickable { items[i] = it0.copy(enabled = !it0.enabled) }
                    )
                    Spacer(Modifier.width(8.dp))
                    Field(it0.label, { v -> items[i] = it0.copy(label = v) }, Modifier.weight(1f))
                    Icon(AppIcons.Up, "上移", tint = if (i > 0) Gray500 else Gray200, modifier = Modifier.size(32.dp).clip(CircleShape).clickable(enabled = i > 0) {
                        val t = items[i]; items[i] = items[i - 1]; items[i - 1] = t
                    }.padding(4.dp))
                    Icon(AppIcons.Down, "下移", tint = if (i < items.size - 1) Gray500 else Gray200, modifier = Modifier.size(32.dp).clip(CircleShape).clickable(enabled = i < items.size - 1) {
                        val t = items[i]; items[i] = items[i + 1]; items[i + 1] = t
                    }.padding(4.dp))
                    Icon(AppIcons.Delete, "删除", tint = Red500.copy(alpha = 0.8f), modifier = Modifier.size(32.dp).clip(CircleShape).clickable { items.removeAt(i) }.padding(5.dp))
                }
            }
        }
    }
}
