package com.uct.salary.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.uct.salary.core.Calc
import com.uct.salary.core.Dates
import com.uct.salary.core.Fmt
import com.uct.salary.model.DailyRecord
import com.uct.salary.ui.AppViewModel
import com.uct.salary.ui.components.AppTopBar
import com.uct.salary.ui.components.CardBox
import com.uct.salary.ui.components.CycleNav
import com.uct.salary.ui.components.EyeButton
import com.uct.salary.ui.components.onPrimary
import com.uct.salary.ui.components.primary
import com.uct.salary.ui.theme.Gray100
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import com.uct.salary.ui.theme.Orange500
import com.uct.salary.ui.theme.Red500
import com.uct.salary.ui.theme.White
import java.time.LocalDate

private val WEEK_HEAD = listOf("日", "一", "二", "三", "四", "五", "六")

@Composable
fun CalendarScreen(vm: AppViewModel) {
    val key = vm.viewKey
    val r = Dates.cycleRange(key)
    val cfg = remember(vm.data.history, key) { Calc.settingsAt(vm.data.history, key) }
    val today = Dates.today()

    Column(Modifier.fillMaxSize()) {
        AppTopBar("日历", onBack = { vm.pop() }) {
            Text(
                if (vm.calendarDetail) "细" else "总", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = onPrimary(),
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(primary())
                    .clickable { vm.calendarDetail = !vm.calendarDetail }.padding(horizontal = 14.dp, vertical = 5.dp)
            )
            Spacer(Modifier.width(12.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).navigationBarsPadding()) {
            CycleNav(
                "${Dates.prevMonthNumber(r.startM)}月", Dates.title(key), "${Dates.nextMonthNumber(r.endM)}月",
                onPrev = { vm.viewKey = Dates.shiftKey(key, -1) }, onNext = { vm.viewKey = Dates.shiftKey(key, 1) }
            )
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
                WEEK_HEAD.forEach {
                    Text(it, Modifier.weight(1f), fontSize = 12.sp, color = Gray500, textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(6.dp))

            val days = remember(key) { Dates.daysOf(key) }
            val lead = r.start.dayOfWeek.value % 7
            val cells: List<LocalDate?> = List(lead) { null } + days
            Column(Modifier.padding(horizontal = 8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                cells.chunked(7).forEach { week ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        for (i in 0 until 7) {
                            val d = week.getOrNull(i)
                            Box(Modifier.weight(1f)) {
                                if (d != null) {
                                    val iso = Dates.iso(d)
                                    DayCell(d, vm.data.records[iso], cfg.hs, d == today, vm.calendarDetail) { vm.openRecord(iso) }
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            SummaryBox(vm, key, Modifier.padding(horizontal = 12.dp))
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DayCell(d: LocalDate, rec: DailyRecord?, hs: Double, isToday: Boolean, detail: Boolean, onClick: () -> Unit) {
    val pri = primary()
    val isRest = rec != null && (rec.shiftType == "休息" || rec.hours == "休")
    val isNight = rec != null && !isRest && Calc.dayNightOf(rec) == "夜班"
    val shape = RoundedCornerShape(8.dp)
    val badgeBg = when {
        rec == null -> pri
        isRest -> Gray400
        rec.shiftType == "周末加班" -> Orange500
        rec.shiftType == "节假日加班" -> Red500
        else -> pri
    }
    val amountColor = when {
        rec == null -> Gray800
        isRest -> Gray500
        rec.shiftType == "周末加班" -> Orange500
        rec.shiftType == "节假日加班" -> Red500
        else -> Gray800
    }
    var modifier = Modifier.fillMaxWidth().height(56.dp).clip(shape)
    modifier = when {
        isToday -> modifier.background(pri.copy(alpha = 0.2f)).border(2.dp, pri, shape)
        isNight -> modifier.background(Gray100.copy(alpha = 0.6f)).border(1.dp, pri, shape)
        else -> modifier.background(Gray100.copy(alpha = 0.6f))
    }
    Box(modifier.clickable(onClick = onClick).padding(3.dp)) {
        Text(d.dayOfMonth.toString(), fontSize = 11.sp, color = Gray900, modifier = Modifier.align(Alignment.TopStart))
        if (rec != null) {
            val pay = Calc.recPay(rec, hs)
            if (!isRest) {
                val segs = rec.otSegments
                if (!segs.isNullOrEmpty()) {
                    Row(Modifier.align(Alignment.TopEnd), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                        segs.forEach { s -> Badge(Fmt.hour(s.hours), badgeBg, if (s.rate == 2.0) Gray900 else White) }
                    }
                } else {
                    val h = Fmt.pfz(rec.otHours)
                    if (h > 0) Badge(Fmt.hour(h), badgeBg, if (Fmt.pfOr(rec.otRate, 1.5) == 2.0) Gray900 else White, Modifier.align(Alignment.TopEnd))
                }
            }
            if (detail && !isRest) {
                Text(Fmt.money(pay.base), fontSize = 9.sp, color = Gray400, modifier = Modifier.align(Alignment.Center))
            }
            Text(
                if (isRest) "休" else Fmt.money(pay.total), fontSize = 10.sp, fontWeight = FontWeight.Medium, color = amountColor,
                modifier = Modifier.align(Alignment.BottomEnd), maxLines = 1
            )
        }
    }
}

@Composable
private fun Badge(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier) {
    Text(
        text, fontSize = 9.sp, color = fg, fontWeight = FontWeight.Medium,
        modifier = modifier.clip(RoundedCornerShape(8.dp)).background(bg).padding(horizontal = 4.dp, vertical = 1.dp)
    )
}

/** 收支汇总（C-5） */
@Composable
private fun SummaryBox(vm: AppViewModel, key: String, modifier: Modifier = Modifier) {
    val s = remember(vm.data.records, vm.data.history, key) { Calc.summary(vm.data.records, vm.data.history, key) }
    val v = vm.data.summaryVisible
    data class Item(val label: String, val value: Double, val sign: Int, val visible: Boolean?, val toggle: () -> Unit)

    val items = listOf(
        Item("基本工资", s.base, 1, null) {},
        Item("加班工资", s.ot, 1, null) {},
        Item("夜班补贴", s.night, 1, v.night) { vm.setSummaryVisible(v.copy(night = !v.night)) },
        Item("餐补", s.meal, 1, v.meal) { vm.setSummaryVisible(v.copy(meal = !v.meal)) },
        Item("应纳税所得额", s.taxable, -1, v.taxable) { vm.setSummaryVisible(v.copy(taxable = !v.taxable)) },
        Item("个人五险", s.social, -1, v.social) { vm.setSummaryVisible(v.copy(social = !v.social)) }
    )
    var total = 0.0
    items.forEach { if (it.visible != false) total += it.sign * it.value }

    CardBox(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("收支汇总", fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Gray900, modifier = Modifier.weight(1f))
            Text(
                "查看统计 ›", fontSize = 13.sp, color = Gray500,
                modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable { vm.openStats(0, keepCycle = true) }.padding(6.dp)
            )
        }
        Spacer(Modifier.height(8.dp))
        items.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                pair.forEach { it0 ->
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(it0.label, fontSize = 12.sp, color = Gray500)
                            if (it0.visible != null) {
                                Spacer(Modifier.width(4.dp))
                                EyeButton(it0.visible, it0.toggle, size = 16.dp)
                            }
                        }
                        val shown = it0.visible != false
                        Text(
                            (if (it0.sign < 0) "-" else "") + Fmt.money(it0.value),
                            fontSize = 16.sp, fontWeight = FontWeight.Medium,
                            color = if (shown) (if (it0.sign < 0) Red500 else Gray900) else Gray400,
                            textDecoration = if (shown) null else TextDecoration.LineThrough
                        )
                    }
                }
            }
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Gray200))
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("合计", fontSize = 14.sp, color = Gray500, modifier = Modifier.weight(1f))
            Text("¥" + Fmt.money(total), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gray900)
        }
    }
}
