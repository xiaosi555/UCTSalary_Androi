package com.uct.salary.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max as maxDp
import androidx.compose.ui.unit.sp
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class DonutItem(val label: String, val value: Double, val valueText: String, val color: Color)

/** 以主题色为首色、依次旋转色相生成 n 个图表配色 */
fun chartColors(primary: Color, n: Int): List<Color> {
    if (n <= 0) return emptyList()
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (primary.red * 255).toInt(), (primary.green * 255).toInt(), (primary.blue * 255).toInt()), hsv)
    return (0 until n).map { i ->
        if (i == 0) primary else {
            val h = (hsv[0] + 47f * i) % 360f
            val s = min(0.85f, max(0.45f, hsv[1]))
            val v = min(0.95f, max(0.72f, hsv[2]))
            Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
        }
    }
}

@Composable
fun DonutChart(
    items: List<DonutItem>,
    centerTop: String,
    centerBottom: String,
    modifier: Modifier = Modifier,
    diameter: Dp = 190.dp
) {
    val total = items.sumOf { max(0.0, it.value) }
    val prog = remember { Animatable(0f) }
    LaunchedEffect(items) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
    }
    Column(modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(diameter)) {
                val stroke = 30.dp.toPx()
                val inset = stroke / 2
                val arcSize = Size(size.width - stroke, size.height - stroke)
                if (total <= 0.0) {
                    drawArc(Gray200, 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke))
                } else {
                    var start = -90f
                    val gap = if (items.count { it.value > 0 } > 1) 2f else 0f
                    items.forEach { it0 ->
                        if (it0.value > 0) {
                            val sweepFull = (it0.value / total * 360.0).toFloat()
                            val sweep = max(0f, (sweepFull - gap) * prog.value)
                            drawArc(it0.color, start + gap / 2, sweep, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Butt))
                            start += sweepFull
                        }
                    }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(centerTop, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gray900)
                Text(centerBottom, fontSize = 12.sp, color = Gray500)
            }
        }
        Spacer(Modifier.height(12.dp))
        items.forEach { it0 ->
            Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(it0.color))
                Spacer(Modifier.width(8.dp))
                Text(it0.label, fontSize = 13.sp, color = Gray800, modifier = Modifier.weight(1f))
                Text(it0.valueText, fontSize = 13.sp, color = Gray500)
            }
        }
    }
}

/** 竖向柱状图：values 为（横轴文字, 数值）；数值为 0 的柱显示灰色低柱 */
@Composable
fun BarsChart(
    values: List<Pair<String, Double>>,
    barColor: Color,
    modifier: Modifier = Modifier,
    chartHeight: Dp = 140.dp,
    barWidth: Dp = 18.dp,
    valueText: (Double) -> String = { if (it == Math.rint(it)) it.toLong().toString() else it.toString() }
) {
    val maxV = max(1.0, values.maxOfOrNull { abs(it.second) } ?: 1.0)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(values) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
    }
    Row(modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        values.forEach { (label, v) ->
            Column(Modifier.width(barWidth + 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (v > 0) Text(valueText(v), fontSize = 9.sp, color = Gray500, textAlign = TextAlign.Center, maxLines = 1)
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier.width(barWidth)
                        .height(maxDp(3.dp, chartHeight * ((v / maxV).toFloat() * prog.value)))
                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                        .background(if (v > 0) barColor else Gray200)
                )
                Text(label, fontSize = 9.sp, color = Gray400, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
            }
        }
    }
}
