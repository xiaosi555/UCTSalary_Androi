package com.uct.salary.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.max as maxDp
import androidx.compose.ui.unit.sp
import com.uct.salary.ui.theme.Gray200
import com.uct.salary.ui.theme.Gray400
import com.uct.salary.ui.theme.Gray500
import com.uct.salary.ui.theme.Gray800
import com.uct.salary.ui.theme.Gray900
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.max
import kotlin.math.min

data class DonutItem(val label: String, val value: Double, val valueText: String, val color: Color)

/** 以主题色为首色、依次旋转色相生成 n 个图表配色 */
fun chartColors(primary: Color, n: Int): List<Color> {
    if (n <= 0) return emptyList()
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (primary.red * 255).toInt(), (primary.green * 255).toInt(), (primary.blue * 255).toInt()), hsv)
    return (0 until n).map { i ->
        if (i == 0) primary else {
            val h = (hsv[0] + 47f * i) % 360f
            val s = min(0.85f, max(0.45f, hsv[1]))
            val v = min(0.95f, max(0.72f, hsv[2]))
            Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))
        }
    }
}

@Composable
fun DonutChart(
    items: List<DonutItem>,
    centerTop: String,
    centerBottom: String,
    modifier: Modifier = Modifier,
    diameter: Dp = 190.dp
) {
    val total = items.sumOf { max(0.0, it.value) }
    val prog = remember { Animatable(0f) }
    LaunchedEffect(items) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
    }
    Box(modifier.fillMaxWidth().height(270.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxWidth().height(270.dp)) {
            val stroke = 28.dp.toPx()
            val radius = min(min(size.width * 0.21f, size.height * 0.275f), diameter.toPx() / 2f)
            val cx = size.width / 2f
            val cy = size.height / 2f
            val arcTopLeft = Offset(cx - radius, cy - radius)
            val arcSize = Size(radius * 2f, radius * 2f)
            if (total <= 0.0) {
                drawArc(Gray200, 0f, 360f, false, arcTopLeft, arcSize, style = Stroke(stroke))
            } else {
                var start = -90f
                val gap = if (items.count { it.value > 0 } > 1) 2f else 0f
                val labels = ArrayList<Triple<Int, Float, Float>>()
                items.forEachIndexed { index, item ->
                    if (item.value > 0) {
                        val sweepFull = (item.value / total * 360.0).toFloat()
                        drawArc(item.color, start + gap / 2f, max(0f, (sweepFull - gap) * prog.value), false, arcTopLeft, arcSize, style = Stroke(stroke, cap = StrokeCap.Butt))
                        val middle = Math.toRadians((start + sweepFull / 2f).toDouble())
                        labels.add(Triple(index, cy + sin(middle).toFloat() * (radius + 28.dp.toPx()), cos(middle).toFloat()))
                        start += sweepFull
                    }
                }
                val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.2.dp.toPx() }
                val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    textSize = 11.sp.toPx()
                    typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
                }
                val minGap = 22.dp.toPx()
                val topLimit = 14.dp.toPx()
                val bottomLimit = size.height - topLimit
                for (rightSide in listOf(false, true)) {
                    val side = labels.filter { (it.third >= 0f) == rightSide }.sortedBy { it.second }
                    val ys = side.map { it.second.coerceIn(topLimit, bottomLimit) }.toMutableList()
                    for (i in 1 until ys.size) if (ys[i] - ys[i - 1] < minGap) ys[i] = ys[i - 1] + minGap
                    if (ys.isNotEmpty() && ys.last() > bottomLimit) {
                        ys[ys.lastIndex] = bottomLimit
                        for (i in ys.lastIndex - 1 downTo 0) if (ys[i + 1] - ys[i] < minGap) ys[i] = ys[i + 1] - minGap
                    }
                    side.forEachIndexed { i, entry ->
                        val item = items[entry.first]
                        val before = items.take(entry.first).filter { it.value > 0 }.sumOf { it.value }
                        val midAngle = Math.toRadians(-90.0 + before / total * 360.0 + item.value / total * 180.0)
                        val sx = cx + cos(midAngle).toFloat() * (radius + stroke / 2f)
                        val sy = cy + sin(midAngle).toFloat() * (radius + stroke / 2f)
                        val mx = cx + cos(midAngle).toFloat() * (radius + 18.dp.toPx())
                        val my = ys[i]
                        val label = "${item.label}  ${item.valueText}"
                        val textWidth = textPaint.measureText(label)
                        val ex = if (rightSide) size.width - textWidth - 10.dp.toPx() else textWidth + 10.dp.toPx()
                        linePaint.color = item.color.toArgb()
                        drawContext.canvas.nativeCanvas.drawLine(sx, sy, mx, my, linePaint)
                        drawContext.canvas.nativeCanvas.drawLine(mx, my, ex, my, linePaint)
                        textPaint.color = item.color.toArgb()
                        textPaint.textAlign = if (rightSide) Paint.Align.LEFT else Paint.Align.RIGHT
                        val tx = if (rightSide) ex + 4.dp.toPx() else ex - 4.dp.toPx()
                        drawContext.canvas.nativeCanvas.drawText(label, tx, my + textPaint.textSize * 0.35f, textPaint)
                    }
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(centerTop, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gray900)
            Text(centerBottom, fontSize = 12.sp, color = Gray500)
        }
    }
}
/** 竖向柱状图：values 为（横轴文字, 数值）；数值为 0 的柱显示灰色低柱 */
@Composable
fun BarsChart(
    values: List<Pair<String, Double>>,
    barColor: Color,
    modifier: Modifier = Modifier,
    chartHeight: Dp = 140.dp,
    barWidth: Dp = 18.dp,
    valueText: (Double) -> String = { if (it == Math.rint(it)) it.toLong().toString() else it.toString() }
) {
    val maxV = max(1.0, values.maxOfOrNull { abs(it.second) } ?: 1.0)
    val prog = remember { Animatable(0f) }
    LaunchedEffect(values) {
        prog.snapTo(0f)
        prog.animateTo(1f, tween(500, easing = FastOutSlowInEasing))
    }
    Row(modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.Bottom) {
        values.forEach { (label, v) ->
            Column(Modifier.width(barWidth + 6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                if (v > 0) Text(valueText(v), fontSize = 9.sp, color = Gray500, textAlign = TextAlign.Center, maxLines = 1)
                Spacer(Modifier.height(2.dp))
                Box(
                    Modifier.width(barWidth)
                        .height(maxDp(3.dp, chartHeight * ((v / maxV).toFloat() * prog.value)))
                        .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                        .background(if (v > 0) barColor else Gray200)
                )
                Text(label, fontSize = 9.sp, color = Gray400, modifier = Modifier.padding(top = 4.dp), maxLines = 1)
            }
        }
    }
}
