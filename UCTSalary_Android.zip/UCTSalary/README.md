# UCT salary（工资APP）— Android 原生版

工时记录 · 工资核算 · 多用户 · 按周期配置 · 单文件 CSV 备份。
功能基线：`工资APP_日历颜色修正版.html`；完整需求见 [`docs/需求说明书_工资APP.html`](docs/需求说明书_工资APP.html)（用浏览器打开）。

- 技术栈：Kotlin 2.0 · Jetpack Compose (Material 3) · 单 Activity · minSdk 26 / targetSdk 34
- 存储：SharedPreferences + kotlinx.serialization，**键名与 JSON 结构与网页版 localStorage 一致**
- 图片：Coil（背景图，离线时回退主题色渐变）；图表：Compose Canvas 自绘，无第三方图表库
- 文件：系统文件选择器（SAF）导入/导出 CSV，无需任何存储权限；仅声明 INTERNET（加载背景图）

## 构建与运行

1. 用 **Android Studio Koala (2024.1) 或更新版本**、**JDK 17** 打开本目录（`UCTSalary/`）。
2. 等待 Gradle 同步（首次会按 `gradle/wrapper/gradle-wrapper.properties` 下载 Gradle 8.9）。
3. 选择 `app` 配置，运行到 Android 8.0+ 设备/模拟器。

命令行（需先在 Android Studio 同步一次，或本机安装 Gradle 8.9 后执行 `gradle wrapper` 生成 wrapper）：

```
./gradlew assembleDebug          # 构建 Debug APK
./gradlew testDebugUnitTest      # 运行单元测试
```

> 说明：本压缩包不含 `gradle-wrapper.jar` / `gradlew`（二进制文件），请按上面方式生成或直接用 Android Studio。

## 目录结构

```
app/src/main/java/com/uct/salary/
├─ MainActivity.kt            页面宿主：页面栈转场、用户切换动效、弹窗层、切换提示
├─ model/                     数据模型（Models.kt）、宽松 JSON 序列化（Serializers.kt）
├─ core/                      纯函数计算层（无 Android 依赖，可 JVM 单测）
│   ├─ Calc.kt                设置版本解析、单日工资、补贴、周期统计、工资条取值
│   ├─ CsvIo.kt               单表 CSV 导出/导入（兼容旧版分段格式、最早仅工时格式）
│   ├─ Dates.kt / Format.kt   周期键/周期范围、fmtMoney（对齐 JS toFixed）等
├─ data/                      Store（SharedPreferences）、Repository（读写、旧数据兼容）
└─ ui/
    ├─ AppViewModel.kt        全局状态、导航栈、用户、记录、按周期配置、导入导出
    ├─ RecordForm.kt          工时表单联动规则（班次联动、夜班周五/周日、分段加班）
    ├─ components/            通用组件（顶栏/卡片/统一弹窗/输入框）、图表
    └─ screens/               首页、日历、统计(4 标签)、设置各页、用户、明细项管理、导入导出
app/src/test/                 CalcTest（网页版实测黄金值）、CsvTest（往返/兼容）
docs/                         需求说明书 HTML、golden_cases.json（黄金用例原始数据）
```

## 功能清单（与需求说明书一一对应）

| 模块 | 内容 |
|---|---|
| 多用户 | 增/改/删、头像（裁剪 160×160 JPEG → data URL）、数据隔离、**原地切换 + 动效** |
| 首页 | 动态周期收入、眼睛开关、加班时长/收入、日历/统计/签到入口、记加班、快捷标签 |
| 工时记录 | 8 种班次联动、夜班周五 2 倍、夜班周日 11h、**分段加班**、自动备注、预计薪资、多用户同步保存、删除确认 |
| 快捷记录 | 一键记录今天、同日覆盖确认、夜班周五/周日规则、设置页（增删改、白夜班、首页显示） |
| 日历 | 周期网格、总/细模式、颜色规则、收支汇总（可隐藏项、合计）、前后周期 |
| 统计 | 加班统计（汇总/环形图/时长柱/日期柱）、记月工资（3 面板 + 底栏）、班次统计（+明细弹窗）、工资条（核对表/数据明细/明细项管理） |
| 设置 | 工资/补贴/扣除（**按周期版本化**，设置页顶部“配置周期”切换条）、考勤周期滚轮、工作日、主题 |
| 导入导出 | **一个 CSV、一行表头、52 列**；旧版格式兼容；统一风格的确认/提示弹窗；用户不一致警告 |

## 与网页版的有意差异

1. 首页收入标题随今天所在周期动态显示（网页版为静态文本）。
2. 补贴设置页除“夜班补贴/伙食补贴”外，用户自定义添加的补贴项也可见、可编辑（网页版新增后会被隐藏却仍参与计算）。
3. 拆分加班面板中，分段倍数下拉只有 1.5 / 2 / 3；由 “2.0” 带入时自动规范为 “2”（网页版此时会出现空选项）。
4. 日期、相册、文件读写使用 Android 原生控件。
5. 加班统计“汇总”里的“元/小时”显示为两位小数。

## 已知限制（与基线一致）

- “考勤周期”滚轮仅保存与展示，日历/统计的周期固定为上月 16 日～本月 15 日。
- “签到”入口无功能；工资条中的标准天数(22)、年假、其他调整、假期、翻班津贴、住宿费、借支为固定值/占位 0。
- 个税为手工输入；收支汇总里“应纳税所得额”即个税设置值，并按减项计入合计。

## 测试说明

`CalcTest` 的预期值全部来自基线网页版在同一份数据上的实测（见 `docs/golden_cases.json`）：每条记录的基本/加班/合计、两个周期的统计、收支汇总、工资核对表、工资条各项。
`CsvTest` 校验“一个文件/一行表头/52 列”、导出→导入往返（设置、补贴、分段、快捷记录）、旧版格式兼容与日期/班次校验。

> 注意：本工程在无 Android SDK 的环境中编写，已用词法扫描检查括号平衡与符号引用，并对计算层数值与网页版逐项比对生成测试；
> 首次在 Android Studio 编译时如遇个别 API 版本差异（Compose BOM / AGP 版本），按 IDE 提示升级依赖即可。
